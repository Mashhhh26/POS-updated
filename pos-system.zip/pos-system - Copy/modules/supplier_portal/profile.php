<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/supplier_portal.php';
verify_csrf();
$db = getDB();
$sup = sp_require_supplier($db);
$sid = (int)$sup['id'];
$success_message = null;
$error_message = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'update_contact') {
            $person = trim($_POST['contact_person'] ?? '');
            $phone = trim($_POST['phone'] ?? '');
            $address = trim($_POST['address'] ?? '');
            if (strlen($person) < 2 || strlen($person) > 100) throw new Exception('Contact person is required (2-100 characters).');
            if (!preg_match('/^[0-9+()\-\s]{0,20}$/', $phone)) throw new Exception('Phone may contain digits, spaces, + ( ) and - only (max 20 characters).');
            if (strlen($address) > 500) throw new Exception('Address is too long.');
            $db->prepare("UPDATE suppliers SET contact_person=?, phone=?, address=? WHERE id=?")->execute([$person, $phone, $address, $sid]);
            logActivity("Supplier portal: {$sup['company_name']} updated its contact details");
            sp_notify_staff($db, 'Supplier updated contact details', $sup['company_name'] . ' updated its contact person/phone/address.', 'modules/procurement/suppliers.php');
            header('Location: profile.php?ok=' . urlencode('Contact details updated.'));
            exit();
        } elseif ($action === 'change_password') {
            $cur = $_POST['current_password'] ?? '';
            $new = $_POST['new_password'] ?? '';
            $conf = $_POST['confirm_password'] ?? '';
            $q = $db->prepare("SELECT password FROM users WHERE id=?");
            $q->execute([$_SESSION['user_id']]);
            if (!password_verify($cur, (string)$q->fetchColumn())) throw new Exception('Your current password is not correct.');
            if ($new !== $conf) throw new Exception('The new passwords do not match.');
            if (($e = sp_valid_password($new)) !== null) throw new Exception($e);
            if ($new === $cur) throw new Exception('Choose a password different from your current one.');
            $db->prepare("UPDATE users SET password=? WHERE id=?")->execute([password_hash($new, PASSWORD_DEFAULT), $_SESSION['user_id']]);
            logActivity("Supplier portal: {$_SESSION['username']} changed their password");
            header('Location: profile.php?ok=' . urlencode('Password changed.'));
            exit();
        }
    } catch (Throwable $e) {
        $error_message = $e->getMessage();
    }
}
$sup = sp_current_supplier($db) ?: $sup;
$acct = $db->prepare("SELECT username, full_name, email FROM users WHERE id=?");
$acct->execute([$_SESSION['user_id']]);
$acct = $acct->fetch();

$pageTitle = 'Profile & Security';
$pageIcon = 'fa-building-user';
include __DIR__ . '/_layout_top.php';
?>
<div class="row g-4">
<div class="col-lg-6">
    <div class="card mb-4"><div class="card-header"><h5 class="mb-0">Company profile</h5></div><div class="card-body">
        <div class="row g-2 small mb-3">
            <div class="col-6"><div class="text-muted">Company</div><strong><?php echo h($sup['company_name']); ?></strong></div>
            <div class="col-6"><div class="text-muted">Supplier code</div><strong><?php echo h($sup['supplier_code']); ?></strong></div>
            <div class="col-6"><div class="text-muted">Email on file</div><strong><?php echo h($sup['email'] ?: '—'); ?></strong></div>
            <div class="col-6"><div class="text-muted">Tax ID</div><strong><?php echo h($sup['tax_id'] ?: '—'); ?></strong></div>
            <div class="col-6"><div class="text-muted">Payment terms</div><strong><?php echo h($sup['payment_terms'] ?: '—'); ?></strong></div>
            <div class="col-6"><div class="text-muted">Lead time</div><strong><?php echo (int)$sup['lead_time_days']; ?> days</strong></div>
        </div>
        <form method="POST" data-confirm="Save your contact details?"><?php echo csrf_field(); ?><input type="hidden" name="action" value="update_contact">
            <div class="mb-2"><label class="form-label">Contact person *</label><input type="text" name="contact_person" class="form-control" maxlength="100" value="<?php echo h($sup['contact_person']); ?>" required></div>
            <div class="mb-2"><label class="form-label">Phone</label><input type="text" name="phone" class="form-control" maxlength="20" value="<?php echo h($sup['phone']); ?>"></div>
            <div class="mb-3"><label class="form-label">Address</label><textarea name="address" rows="2" maxlength="500" class="form-control"><?php echo h($sup['address']); ?></textarea></div>
            <button class="btn btn-primary">Save contact details</button>
            <div class="form-text mt-2">To change the company name, tax ID or email, contact the procurement team.</div>
        </form>
    </div></div>
</div>
<div class="col-lg-6">
    <div class="card"><div class="card-header"><h5 class="mb-0">Your login</h5></div><div class="card-body">
        <div class="small mb-3"><span class="text-muted">Username</span> <strong><?php echo h($acct['username']); ?></strong> · <span class="text-muted">Email</span> <strong><?php echo h($acct['email']); ?></strong></div>
        <form method="POST" autocomplete="off" data-confirm="Change your password?"><?php echo csrf_field(); ?><input type="hidden" name="action" value="change_password">
            <div class="mb-2"><label class="form-label">Current password *</label><input type="password" name="current_password" class="form-control" required></div>
            <div class="mb-2"><label class="form-label">New password *</label><input type="password" name="new_password" class="form-control" minlength="10" required></div>
            <div class="mb-3"><label class="form-label">Confirm new password *</label><input type="password" name="confirm_password" class="form-control" minlength="10" required><div class="form-text">At least 10 characters, with letters and numbers.</div></div>
            <button class="btn btn-primary">Change password</button>
        </form>
    </div></div>
</div>
</div>
<?php include __DIR__ . '/_layout_bottom.php';
