<?php
if (!defined('BASE_PATH') || !isset($pageTitle)) { http_response_code(403); exit('Forbidden'); }
$success_message = $success_message ?? (isset($_GET['ok']) ? $_GET['ok'] : null);
$error_message = $error_message ?? (isset($_GET['err']) ? $_GET['err'] : null);
$current_page = basename($_SERVER['PHP_SELF']);
$navMap = ['order.php' => 'orders.php', 'rfq.php' => 'rfqs.php'];
$current_page = $navMap[$current_page] ?? $current_page;
$__unread = 0;
try {
    if (isset($db) && !empty($_SESSION['user_id'])) {
        $__uq = $db->prepare("SELECT COUNT(*) FROM notifications WHERE user_id=? AND is_read=0");
        $__uq->execute([$_SESSION['user_id']]);
        $__unread = (int)$__uq->fetchColumn();
    }
} catch (Throwable $e) { $__unread = 0; }
function sp_nav(string $page, string $label, string $icon, string $current, int $badge = 0): string {
    $active = $current === $page ? 'active bg-primary text-white' : 'text-dark';
    $b = $badge > 0 ? ' <span class="badge bg-danger ms-1">' . $badge . '</span>' : '';
    return '<li class="nav-item"><a class="nav-link ' . $active . '" href="' . h(BASE_PATH) . 'modules/supplier_portal/' . $page . '"><i class="fas ' . $icon . ' me-2"></i><span class="sidebar-label"> ' . h($label) . '</span>' . $b . '</a></li>';
}
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light" data-pos-theme="light" data-pos-palette="indigo">
<head>
<script>
(function(){try{var t=localStorage.getItem('pos_theme');var p=localStorage.getItem('pos_palette');if(t==='dark'||t==='light')document.documentElement.setAttribute('data-pos-theme',t);if(['indigo','blue','emerald','violet','rose','amber'].indexOf(p)!==-1)document.documentElement.setAttribute('data-pos-palette',p);}catch(e){}})();
</script>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo h($pageTitle); ?> - Supplier Portal</title>
    <link href="<?php echo BASE_PATH; ?>assets/vendor/bootstrap/bootstrap.min.css?v=20261010" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo BASE_PATH; ?>assets/vendor/fontawesome/all.min.css?v=20261010">
    <link rel="stylesheet" href="<?php echo BASE_PATH; ?>assets/css/custom.css?v=20261010">
</head>
<body>
<?php include BASE_PATH . 'includes/header.php'; ?>
<div class="d-flex">
    <div class="sidebar bg-white shadow-sm p-3" style="min-height: calc(100vh - 56px); width: 250px; flex-shrink: 0; overflow-y: auto;">
        <div class="px-2 pb-3 mb-2 border-bottom">
            <div class="text-uppercase small text-muted fw-bold" style="letter-spacing:.08em">Supplier portal</div>
            <div class="fw-bold"><?php echo h($sup['company_name'] ?? ''); ?></div>
            <div class="small text-muted"><?php echo h($sup['supplier_code'] ?? ''); ?></div>
        </div>
        <ul class="nav flex-column">
            <?php echo sp_nav('index.php', 'Dashboard', 'fa-gauge-high', $current_page); ?>
            <?php echo sp_nav('rfqs.php', 'RFQ & Quotations', 'fa-file-invoice-dollar', $current_page); ?>
            <?php echo sp_nav('orders.php', 'Purchase Orders', 'fa-file-signature', $current_page); ?>
            <?php echo sp_nav('deliveries.php', 'Delivery Updates', 'fa-truck-fast', $current_page); ?>
            <?php echo sp_nav('documents.php', 'Documents', 'fa-folder-open', $current_page); ?>
            <?php echo sp_nav('history.php', 'Order History', 'fa-clock-rotate-left', $current_page); ?>
            <?php echo sp_nav('notifications.php', 'Notifications', 'fa-bell', $current_page, $__unread); ?>
            <?php echo sp_nav('profile.php', 'Company & Account', 'fa-building-user', $current_page); ?>
        </ul>
    </div>
    <div class="main-content flex-grow-1 p-4">
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <h4 class="mb-0"><i class="fas <?php echo h($pageIcon); ?> me-2 text-primary"></i> <?php echo h($pageTitle); ?></h4>
            <?php if (!empty($pageActions)) echo $pageActions; ?>
        </div>
        <?php if ($success_message): ?><div id="flash-message" data-type="success" data-message="<?php echo h($success_message); ?>"></div><?php endif; ?>
        <?php if ($error_message): ?><div id="flash-message" data-type="error" data-message="<?php echo h($error_message); ?>"></div><?php endif; ?>
