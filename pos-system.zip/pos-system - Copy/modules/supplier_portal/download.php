<?php
// Secure document download: ownership/permission is checked on every request.
session_start();
require_once '../../config/database.php';
require_once '../../config/supplier_portal.php';
if (empty($_SESSION['user_id'])) { header('Location: ' . BASE_PATH . 'login.php'); exit(); }
$db = getDB();
sp_ensure_schema($db);
$id = (int)($_GET['id'] ?? 0);
$q = $db->prepare("SELECT * FROM supplier_documents WHERE id=?");
$q->execute([$id]);
$doc = $q->fetch();
if (!$doc || !sp_doc_can_access($db, $doc)) {
    http_response_code(404);
    exit('Document not found.');
}
$path = sp_upload_dir() . '/' . basename($doc['stored_name']);
if (!is_file($path)) { http_response_code(404); exit('File is missing on the server.'); }
logActivity('Document downloaded: #' . $id . ' ' . $doc['original_name']);
$ext = strtolower(pathinfo($doc['stored_name'], PATHINFO_EXTENSION));
$inline = in_array($ext, ['pdf', 'jpg', 'jpeg', 'png'], true) && isset($_GET['view']);
header('Content-Type: ' . ($doc['mime'] ?: 'application/octet-stream'));
header('Content-Length: ' . filesize($path));
header('Content-Disposition: ' . ($inline ? 'inline' : 'attachment') . '; filename="' . str_replace('"', '', $doc['original_name']) . '"');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-store');
readfile($path);
exit();
