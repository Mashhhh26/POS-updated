<?php if (!defined('BASE_PATH')) { http_response_code(403); exit('Forbidden'); } ?>
    </div>
</div>
<script src="<?php echo BASE_PATH; ?>assets/vendor/sweetalert2/sweetalert2.all.min.js?v=20261010"></script>
<script src="<?php echo BASE_PATH; ?>assets/vendor/bootstrap/bootstrap.bundle.min.js?v=20261010"></script>
<script src="<?php echo BASE_PATH; ?>assets/js/script.js?v=20261010"></script>
<script>
document.querySelectorAll('form[data-confirm]').forEach(function (f) {
    f.addEventListener('submit', function (e) {
        if (f.dataset.ok === '1') return;
        e.preventDefault();
        Swal.fire({ title: 'Please confirm', text: f.dataset.confirm, icon: 'question', showCancelButton: true, confirmButtonText: 'Yes, proceed' })
            .then(function (r) { if (r.isConfirmed) { f.dataset.ok = '1'; f.submit(); } });
    });
});
</script>
</body>
</html>
