<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/supplier_portal.php';
verify_csrf();
$db = getDB();
$sup = sp_require_supplier($db);
$sid = (int)$sup['id'];
$st = $db->prepare("SELECT po.*, (SELECT COUNT(*) FROM po_shipments s WHERE s.po_id=po.id) AS ships,
        (SELECT carrier FROM po_shipments s WHERE s.po_id=po.id ORDER BY s.id DESC LIMIT 1) AS carrier,
        (SELECT tracking_no FROM po_shipments s WHERE s.po_id=po.id ORDER BY s.id DESC LIMIT 1) AS tracking_no
    FROM purchase_orders po WHERE po.supplier_id=? AND po.status IN ('acknowledged','partially_received')
    ORDER BY COALESCE(po.expected_delivery_date, po.delivery_date, '9999-12-31') ASC");
$st->execute([$sid]);
$rows = $st->fetchAll();
$sh = $db->prepare("SELECT s.*, po.po_number FROM po_shipments s JOIN purchase_orders po ON po.id=s.po_id WHERE s.supplier_id=? ORDER BY s.id DESC LIMIT 15");
$sh->execute([$sid]);
$ships = $sh->fetchAll();
$pageTitle = 'Delivery Updates';
$pageIcon = 'fa-truck-fast';
include __DIR__ . '/_layout_top.php';
?>
<div class="card mb-4"><div class="card-header"><h5 class="mb-0">Orders awaiting delivery</h5></div><div class="table-responsive"><table class="table table-hover align-middle mb-0">
    <thead><tr><th>PO number</th><th>Needed by</th><th>Your ETA</th><th>Delivery status</th><th>Latest shipment</th><th></th></tr></thead><tbody>
    <?php if (!$rows): ?><tr><td colspan="6" class="text-center text-muted py-4">No confirmed orders waiting for delivery.</td></tr><?php endif; ?>
    <?php foreach ($rows as $p): $late = $p['expected_delivery_date'] && $p['expected_delivery_date'] < date('Y-m-d') && $p['delivery_status'] !== 'delivered'; ?>
    <tr><td><strong><?php echo h($p['po_number']); ?></strong><?php if ((int)$p['revision_no'] > 0): ?> <span class="badge bg-info">rev <?php echo (int)$p['revision_no']; ?></span><?php endif; ?></td>
        <td><?php echo h(sp_fmt_date($p['delivery_date'])); ?></td>
        <td><?php echo h(sp_fmt_date($p['expected_delivery_date'])); ?><?php if ($late): ?> <span class="badge bg-danger">overdue</span><?php endif; ?></td>
        <td><?php echo sp_stage_badge($p); ?></td>
        <td class="small"><?php echo $p['ships'] ? h($p['carrier'] . ($p['tracking_no'] ? ' · ' . $p['tracking_no'] : '')) : '—'; ?></td>
        <td class="text-end"><a class="btn btn-sm btn-primary" href="order.php?id=<?php echo (int)$p['id']; ?>#delivery">Update</a></td></tr>
    <?php endforeach; ?>
    </tbody></table></div></div>
<div class="card"><div class="card-header"><h5 class="mb-0">Recent shipments</h5></div><div class="table-responsive"><table class="table mb-0">
    <thead><tr><th>PO</th><th>Carrier</th><th>Tracking no.</th><th>Shipped</th><th>Arrival</th><th>Remarks</th></tr></thead><tbody>
    <?php if (!$ships): ?><tr><td colspan="6" class="text-center text-muted py-3">No shipments recorded yet.</td></tr><?php endif; ?>
    <?php foreach ($ships as $s): ?><tr><td><?php echo h($s['po_number']); ?></td><td><?php echo h($s['carrier']); ?></td><td><?php echo h($s['tracking_no'] ?: '—'); ?></td><td><?php echo h(sp_fmt_date($s['ship_date'])); ?></td><td><?php echo h(sp_fmt_date($s['expected_arrival'])); ?></td><td class="small"><?php echo h($s['remarks'] ?: ''); ?></td></tr><?php endforeach; ?>
    </tbody></table></div></div>
<?php include __DIR__ . '/_layout_bottom.php';
