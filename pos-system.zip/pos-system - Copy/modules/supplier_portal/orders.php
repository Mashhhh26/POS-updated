<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/supplier_portal.php';
verify_csrf();
$db = getDB();
$sup = sp_require_supplier($db);
$sid = (int)$sup['id'];

$filters = [
    'all'       => ['All', ''],
    'awaiting'  => ['Awaiting response', " AND po.status='sent' AND po.supplier_response='pending'"],
    'active'    => ['In progress', " AND po.status IN ('acknowledged','partially_received')"],
    'delivery'  => ['In delivery', " AND po.status IN ('acknowledged','partially_received') AND po.delivery_status IN ('shipped','delivered')"],
    'completed' => ['Completed', " AND po.status IN ('fulfilled','closed')"],
    'rejected'  => ['Rejected / cancelled', " AND po.status IN ('rejected','cancelled')"],
];
$f = $_GET['f'] ?? 'all';
if (!isset($filters[$f])) $f = 'all';
$q = trim($_GET['q'] ?? '');

$sql = "SELECT po.* FROM purchase_orders po WHERE " . sp_visible_sql() . $filters[$f][1];
$params = [$sid];
if ($q !== '') { $sql .= " AND po.po_number LIKE ?"; $params[] = '%' . $q . '%'; }
$sql .= " ORDER BY po.sent_at DESC, po.id DESC LIMIT 300";
$st = $db->prepare($sql);
$st->execute($params);
$rows = $st->fetchAll();

$pageTitle = 'Purchase Orders';
$pageIcon = 'fa-file-signature';
include __DIR__ . '/_layout_top.php';
?>
<div class="card mb-3"><div class="card-body d-flex flex-wrap gap-2 align-items-center">
    <?php foreach ($filters as $k => $v): ?><a class="btn btn-sm <?php echo $k === $f ? 'btn-primary' : 'btn-outline-secondary'; ?>" href="orders.php?f=<?php echo h($k); ?>"><?php echo h($v[0]); ?></a><?php endforeach; ?>
    <form class="ms-auto d-flex gap-2" method="GET"><input type="hidden" name="f" value="<?php echo h($f); ?>"><input type="text" name="q" value="<?php echo h($q); ?>" class="form-control form-control-sm" placeholder="Search PO number" style="min-width:180px"><button class="btn btn-sm btn-primary">Search</button></form>
</div></div>
<div class="card"><div class="table-responsive"><table class="table table-hover align-middle mb-0">
    <thead><tr><th>PO number</th><th>Issued</th><th class="text-end">Total</th><th>Needed by</th><th>Your ETA</th><th>Status</th><th></th></tr></thead><tbody>
    <?php if (!$rows): ?><tr><td colspan="7" class="text-center text-muted py-4">No purchase orders found.</td></tr><?php endif; ?>
    <?php foreach ($rows as $p): ?>
    <tr>
        <td><strong><?php echo h($p['po_number']); ?></strong></td>
        <td><?php echo h(sp_fmt_date($p['sent_at'])); ?></td>
        <td class="text-end"><?php echo h(sp_money($p['grand_total'])); ?></td>
        <td><?php echo h(sp_fmt_date($p['delivery_date'])); ?></td>
        <td><?php echo h(sp_fmt_date($p['expected_delivery_date'])); ?></td>
        <td><?php echo sp_stage_badge($p); ?></td>
        <td class="text-end"><a class="btn btn-sm btn-outline-primary" href="order.php?id=<?php echo (int)$p['id']; ?>"><i class="fas fa-eye me-1"></i> Open</a></td>
    </tr>
    <?php endforeach; ?>
    </tbody></table></div></div>
<?php include __DIR__ . '/_layout_bottom.php';
