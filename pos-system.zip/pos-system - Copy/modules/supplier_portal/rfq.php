<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/supplier_portal.php';
verify_csrf();
$db = getDB();
$sup = sp_require_supplier($db);
$sid = (int)$sup['id'];
$rfqId = (int)($_POST['rfq_id'] ?? $_GET['id'] ?? 0);
$success_message = null;
$error_message = null;

// Only RFQs this supplier was invited to are visible, and never drafts.
$rq = $db->prepare("SELECT r.* FROM rfq_suppliers rs JOIN rfqs r ON r.id=rs.rfq_id WHERE rs.supplier_id=? AND r.id=? AND r.status<>'draft'");
$rq->execute([$sid, $rfqId]);
$rfq = $rq->fetch();
if (!$rfq) { header('Location: rfqs.php?err=' . urlencode('Request for quotation not found.')); exit(); }
$items = sp_rfq_items($db, $rfq['requisition_id'] ? (int)$rfq['requisition_id'] : null);
$qq = $db->prepare("SELECT * FROM quotations WHERE rfq_id=? AND supplier_id=? ORDER BY id DESC LIMIT 1");
$qq->execute([$rfqId, $sid]);
$quote = $qq->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'submit_quotation') {
    try {
        if (!sp_rfq_open($rfq)) throw new Exception('This request for quotation is closed (deadline passed or submissions closed).');
        if ($quote && $quote['status'] !== 'received') throw new Exception('Your quotation is already being evaluated and can no longer be changed.');
        if (!$items) throw new Exception('This RFQ has no items to quote.');
        $lines = [];
        $total = 0.0;
        foreach ($items as $it) {
            $iid = (int)$it['id'];
            $price = trim((string)($_POST['price'][$iid] ?? ''));
            $qty = trim((string)($_POST['qty'][$iid] ?? ''));
            if ($price === '' && ($qty === '' || $qty === '0')) continue;            // item not quoted
            if (!valid_money($price, false)) throw new Exception('Enter a valid unit price (more than 0, max 2 decimals) for "' . $it['item_description'] . '".');
            if (filter_var($qty, FILTER_VALIDATE_INT) === false || (int)$qty < 1 || (int)$qty > (int)$it['quantity']) throw new Exception('Available quantity for "' . $it['item_description'] . '" must be between 1 and ' . (int)$it['quantity'] . '.');
            $lead = trim((string)($_POST['lead'][$iid] ?? ''));
            if ($lead !== '' && (!ctype_digit($lead) || (int)$lead > 365)) throw new Exception('Item lead time must be 0-365 days.');
            $line = round((float)$price * (int)$qty, 2);
            $total += $line;
            $lines[] = [$it, (float)$price, (int)$qty, $line, $lead === '' ? null : (int)$lead, substr(trim((string)($_POST['remark'][$iid] ?? '')), 0, 200)];
        }
        if (!$lines) throw new Exception('Quote at least one item.');
        $leadAll = trim((string)($_POST['delivery_lead_time'] ?? ''));
        $validity = trim((string)($_POST['validity_days'] ?? '30'));
        $warranty = substr(trim((string)($_POST['warranty'] ?? '')), 0, 150);
        $terms = substr(trim((string)($_POST['payment_terms'] ?? '')), 0, 50);
        $notes = substr(trim((string)($_POST['notes'] ?? '')), 0, 1000);
        if (!ctype_digit($leadAll) || (int)$leadAll > 365) throw new Exception('Delivery estimate must be 0-365 days.');
        if (!ctype_digit($validity) || (int)$validity < 1 || (int)$validity > 365) throw new Exception('Quotation validity must be 1-365 days.');
        if ($terms === '') throw new Exception('Payment terms are required.');

        $db->beginTransaction();
        if ($quote) {
            $qid = (int)$quote['id'];
            $db->prepare("UPDATE quotations SET total_amount=?, delivery_lead_time=?, payment_terms=?, validity_days=?, warranty=?, notes=?, revision_no=revision_no+1, updated_at=NOW(), submitted_via='portal', submitted_by=? WHERE id=? AND status='received'")
               ->execute([round($total, 2), (int)$leadAll, $terms, (int)$validity, $warranty !== '' ? $warranty : null, $notes, $_SESSION['user_id'], $qid]);
            $db->prepare("DELETE FROM quotation_items WHERE quotation_id=?")->execute([$qid]);
        } else {
            $qnum = 'QUOT-' . date('Ymd') . '-' . random_int(1000, 9999);
            $db->prepare("INSERT INTO quotations (rfq_id, supplier_id, quotation_number, total_amount, delivery_lead_time, payment_terms, validity_days, warranty, status, notes, submitted_via, submitted_by) VALUES (?,?,?,?,?,?,?,?, 'received', ?, 'portal', ?)")
               ->execute([$rfqId, $sid, $qnum, round($total, 2), (int)$leadAll, $terms, (int)$validity, $warranty !== '' ? $warranty : null, $notes, $_SESSION['user_id']]);
            $qid = (int)$db->lastInsertId();
        }
        $ins = $db->prepare("INSERT INTO quotation_items (quotation_id, item_description, quantity, unit_price, total, lead_time, remarks, available_quantity, rfq_item_id) VALUES (?,?,?,?,?,?,?,?,?)");
        foreach ($lines as $l) $ins->execute([$qid, $l[0]['item_description'], $l[2], $l[1], $l[3], $l[4], $l[5], $l[2], (int)$l[0]['id']]);
        $db->prepare("UPDATE rfq_suppliers SET status='responded', responded_at=NOW() WHERE rfq_id=? AND supplier_id=?")->execute([$rfqId, $sid]);
        $db->commit();

        $upNote = '';
        if (!empty($_FILES['attachment']) && ($_FILES['attachment']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
            try { sp_store_upload($db, $_FILES['attachment'], ['supplier_id' => $sid, 'rfq_id' => $rfqId, 'doc_type' => 'quotation_attachment', 'by' => 'supplier']); }
            catch (Throwable $ue) { $upNote = ' (the attachment was not saved: ' . $ue->getMessage() . ')'; }
        }
        $isRev = (bool)$quote;
        logActivity("Supplier portal: {$sup['company_name']} " . ($isRev ? 'revised' : 'submitted') . " quotation for {$rfq['rfq_number']} (" . sp_money($total) . ")");
        // Confirmation to the supplier, alert to procurement
        sp_notify_supplier($db, $sid, 'Quotation received', 'We received your quotation for ' . $rfq['rfq_number'] . '. Total quoted: ' . sp_money($total) . '.', 'modules/supplier_portal/rfq.php?id=' . $rfqId,
            'Quotation received: ' . $rfq['rfq_number'], ['We received your quotation for ' . $rfq['rfq_number'] . '.', 'You can still revise it until the submission deadline.']);
        sp_notify_staff($db, 'Supplier quotation ' . ($isRev ? 'revised' : 'submitted'), $sup['company_name'] . ' ' . ($isRev ? 'revised' : 'submitted') . ' a quotation for ' . $rfq['rfq_number'] . '.', 'modules/procurement/quotation_compare.php?rfq_id=' . $rfqId, 'Quotation ' . ($isRev ? 'revised' : 'submitted') . ': ' . $rfq['rfq_number']);
        header('Location: rfq.php?id=' . $rfqId . '&ok=' . urlencode('Quotation ' . ($isRev ? 'updated' : 'submitted') . '. A confirmation was sent to you.' . $upNote));
        exit();
    } catch (Throwable $e) {
        if ($db->inTransaction()) $db->rollBack();
        $error_message = $e->getMessage();
    }
}

$open = sp_rfq_open($rfq);
$canEdit = $open && (!$quote || $quote['status'] === 'received');
$byItem = [];
if ($quote) {
    $qi = $db->prepare("SELECT * FROM quotation_items WHERE quotation_id=?");
    $qi->execute([$quote['id']]);
    foreach ($qi->fetchAll() as $r) $byItem[(int)$r['rfq_item_id']] = $r;
}
$docs = $db->prepare("SELECT * FROM supplier_documents WHERE supplier_id=? AND rfq_id=? ORDER BY id DESC");
$docs->execute([$sid, $rfqId]);
$docs = $docs->fetchAll();
$outcome = null;
if ($quote && $rfq['status'] === 'awarded') $outcome = $quote['status'] === 'accepted' ? 'selected' : 'not_selected';

$pageTitle = $rfq['rfq_number'];
$pageIcon = 'fa-file-invoice-dollar';
$pageActions = '<a class="btn btn-outline-secondary" href="rfqs.php"><i class="fas fa-arrow-left me-1"></i> All requests</a>';
include __DIR__ . '/_layout_top.php';
?>
<div class="card mb-4"><div class="card-body">
    <div class="d-flex flex-wrap justify-content-between gap-3 mb-2">
        <div><h5 class="mb-1"><?php echo h($rfq['title'] ?: 'Request for quotation'); ?></h5><div class="text-muted small"><?php echo nl2br(h($rfq['description'] ?: '')); ?></div></div>
        <div class="text-end"><div class="metric-label">Submission deadline</div><strong><?php echo $rfq['submission_deadline'] ? h(date('M d, Y H:i', strtotime($rfq['submission_deadline']))) : 'No deadline'; ?></strong>
            <div class="mt-1"><?php echo $open ? '<span class="badge bg-success">Open</span>' : '<span class="badge bg-secondary">Closed</span>'; ?></div></div>
    </div>
    <?php if ($outcome === 'selected'): ?><div class="alert alert-success mb-0 mt-2"><i class="fas fa-trophy me-1"></i> Your quotation was <strong>selected</strong>. A purchase order will be issued to you.</div>
    <?php elseif ($outcome === 'not_selected'): ?><div class="alert alert-secondary mb-0 mt-2">Thank you for quoting. Your quotation was not selected this time.</div><?php endif; ?>
</div></div>

<form method="POST" enctype="multipart/form-data" data-confirm="<?php echo $quote ? 'Submit your revised quotation?' : 'Submit this quotation?'; ?>">
<?php echo csrf_field(); ?><input type="hidden" name="action" value="submit_quotation"><input type="hidden" name="rfq_id" value="<?php echo $rfqId; ?>">
<div class="card mb-4"><div class="card-header"><h5 class="mb-0">Items requested</h5><div class="small text-muted mt-1">Leave an item blank if you cannot supply it. Offer only what you can deliver.</div></div>
<div class="table-responsive"><table class="table align-middle mb-0">
    <thead><tr><th>Item</th><th class="text-center">Needed</th><th style="min-width:130px">Unit price (₱)</th><th style="min-width:110px">Available qty</th><th style="min-width:110px">Lead time (days)</th><th>Remarks</th></tr></thead><tbody>
    <?php if (!$items): ?><tr><td colspan="6" class="text-center text-muted py-4">No items attached to this RFQ.</td></tr><?php endif; ?>
    <?php foreach ($items as $it): $iid = (int)$it['id']; $ex = $byItem[$iid] ?? null; ?>
    <tr><td><strong><?php echo h($it['item_description']); ?></strong><?php if ($it['specifications']): ?><div class="small text-muted"><?php echo h($it['specifications']); ?></div><?php endif; ?></td>
        <td class="text-center"><?php echo (int)$it['quantity']; ?> <?php echo h($it['unit']); ?></td>
        <td><input type="number" step="0.01" min="0.01" name="price[<?php echo $iid; ?>]" class="form-control" value="<?php echo $ex ? h($ex['unit_price']) : ''; ?>" <?php echo $canEdit ? '' : 'disabled'; ?>></td>
        <td><input type="number" min="1" max="<?php echo (int)$it['quantity']; ?>" name="qty[<?php echo $iid; ?>]" class="form-control" value="<?php echo $ex ? (int)$ex['available_quantity'] : ''; ?>" <?php echo $canEdit ? '' : 'disabled'; ?>></td>
        <td><input type="number" min="0" max="365" name="lead[<?php echo $iid; ?>]" class="form-control" value="<?php echo $ex && $ex['lead_time'] !== null ? (int)$ex['lead_time'] : ''; ?>" <?php echo $canEdit ? '' : 'disabled'; ?>></td>
        <td><input type="text" maxlength="200" name="remark[<?php echo $iid; ?>]" class="form-control" value="<?php echo $ex ? h($ex['remarks']) : ''; ?>" <?php echo $canEdit ? '' : 'disabled'; ?>></td></tr>
    <?php endforeach; ?>
    </tbody></table></div></div>

<div class="card mb-4"><div class="card-header"><h5 class="mb-0">Commercial terms</h5></div><div class="card-body"><div class="row g-3">
    <div class="col-md-3"><label class="form-label">Delivery estimate (days) *</label><input type="number" min="0" max="365" name="delivery_lead_time" class="form-control" value="<?php echo $quote ? (int)$quote['delivery_lead_time'] : (int)($sup['lead_time_days'] ?? 7); ?>" <?php echo $canEdit ? 'required' : 'disabled'; ?>></div>
    <div class="col-md-3"><label class="form-label">Warranty</label><input type="text" maxlength="150" name="warranty" class="form-control" placeholder="e.g. 1 year replacement" value="<?php echo h($quote['warranty'] ?? ''); ?>" <?php echo $canEdit ? '' : 'disabled'; ?>></div>
    <div class="col-md-3"><label class="form-label">Payment terms *</label><input type="text" maxlength="50" name="payment_terms" class="form-control" value="<?php echo h($quote['payment_terms'] ?? ($sup['payment_terms'] ?? '')); ?>" <?php echo $canEdit ? 'required' : 'disabled'; ?>></div>
    <div class="col-md-3"><label class="form-label">Valid for (days) *</label><input type="number" min="1" max="365" name="validity_days" class="form-control" value="<?php echo $quote ? (int)$quote['validity_days'] : 30; ?>" <?php echo $canEdit ? 'required' : 'disabled'; ?>></div>
    <div class="col-12"><label class="form-label">Notes</label><textarea name="notes" rows="2" maxlength="1000" class="form-control" <?php echo $canEdit ? '' : 'disabled'; ?>><?php echo h($quote['notes'] ?? ''); ?></textarea></div>
    <?php if ($canEdit): ?><div class="col-md-6"><label class="form-label">Attach a supporting file (optional)</label><input type="file" name="attachment" class="form-control" accept=".pdf,.jpg,.jpeg,.png,.doc,.docx,.xls,.xlsx"><div class="form-text">PDF, image, Word or Excel, up to 5 MB.</div></div><?php endif; ?>
</div>
<?php if ($canEdit): ?><button class="btn btn-primary mt-3"><i class="fas fa-paper-plane me-1"></i> <?php echo $quote ? 'Submit revised quotation' : 'Submit quotation'; ?></button><?php else: ?><div class="alert alert-secondary mt-3 mb-0 small"><?php echo $open ? 'Your quotation is being evaluated and can no longer be changed.' : 'Submissions for this request are closed.'; ?></div><?php endif; ?>
</div></div>
</form>

<?php if ($docs): ?><div class="card"><div class="card-header"><h5 class="mb-0">Your attachments</h5></div><div class="card-body">
    <?php foreach ($docs as $d): ?><a class="soft-row" href="download.php?id=<?php echo (int)$d['id']; ?>"><i class="fas fa-paperclip"></i><span class="small fw-semibold"><?php echo h($d['original_name']); ?></span><span class="ms-auto small text-muted"><?php echo h(sp_fmt_size((int)$d['size_bytes'])); ?></span></a><?php endforeach; ?>
</div></div><?php endif; ?>
<?php include __DIR__ . '/_layout_bottom.php';
