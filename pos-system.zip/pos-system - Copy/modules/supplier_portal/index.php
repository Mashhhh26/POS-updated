<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/supplier_portal.php';
verify_csrf();
$db = getDB();
$sup = sp_require_supplier($db);
$sid = (int)$sup['id'];

$c = $db->prepare("SELECT
        COALESCE(SUM(po.status='sent' AND po.supplier_response='pending'),0) AS new_pos,
        COALESCE(SUM(po.status IN ('acknowledged','partially_received')),0) AS in_delivery,
        COALESCE(SUM(po.status IN ('fulfilled','closed')),0) AS completed
    FROM purchase_orders po WHERE " . sp_visible_sql());
$c->execute([$sid]);
$cnt = $c->fetch();

$pq = $db->prepare("SELECT COUNT(*) FROM rfq_suppliers rs JOIN rfqs r ON r.id=rs.rfq_id
    WHERE rs.supplier_id=? AND r.status='sent' AND (r.submission_deadline IS NULL OR r.submission_deadline>=NOW())
      AND NOT EXISTS (SELECT 1 FROM quotations q WHERE q.rfq_id=r.id AND q.supplier_id=rs.supplier_id)");
$pq->execute([$sid]);
$pendingQuotes = (int)$pq->fetchColumn();

$newPos = $db->prepare("SELECT po.id, po.po_number, po.grand_total, po.sent_at, po.delivery_date FROM purchase_orders po WHERE po.supplier_id=? AND po.status='sent' AND po.supplier_response='pending' ORDER BY po.sent_at DESC LIMIT 5");
$newPos->execute([$sid]);
$newPos = $newPos->fetchAll();

$rfqs = $db->prepare("SELECT r.id, r.rfq_number, r.title, r.submission_deadline FROM rfq_suppliers rs JOIN rfqs r ON r.id=rs.rfq_id
    WHERE rs.supplier_id=? AND r.status='sent' AND (r.submission_deadline IS NULL OR r.submission_deadline>=NOW())
      AND NOT EXISTS (SELECT 1 FROM quotations q WHERE q.rfq_id=r.id AND q.supplier_id=rs.supplier_id)
    ORDER BY r.submission_deadline IS NULL, r.submission_deadline ASC LIMIT 5");
$rfqs->execute([$sid]);
$rfqs = $rfqs->fetchAll();

$active = $db->prepare("SELECT po.* FROM purchase_orders po WHERE po.supplier_id=? AND po.status IN ('acknowledged','partially_received') ORDER BY COALESCE(po.expected_delivery_date, po.delivery_date, '9999-12-31') ASC LIMIT 5");
$active->execute([$sid]);
$active = $active->fetchAll();

$notes = $db->prepare("SELECT id, title, message, link, is_read, created_at FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 5");
$notes->execute([$_SESSION['user_id']]);
$notes = $notes->fetchAll();

$hist = $db->prepare("SELECT po.id, po.po_number, po.grand_total, po.status, po.sent_at FROM purchase_orders po WHERE po.supplier_id=? AND po.status IN ('fulfilled','closed') ORDER BY po.sent_at DESC LIMIT 5");
$hist->execute([$sid]);
$hist = $hist->fetchAll();

$pageTitle = 'Supplier Dashboard';
$pageIcon = 'fa-gauge-high';
include __DIR__ . '/_layout_top.php';
$tiles = [
    ['New purchase orders', $cnt['new_pos'], 'fa-file-circle-plus', 'orders.php?f=awaiting'],
    ['Pending quotations', $pendingQuotes, 'fa-file-invoice-dollar', 'rfqs.php?f=open'],
    ['Orders in delivery', $cnt['in_delivery'], 'fa-truck-fast', 'deliveries.php'],
    ['Completed orders', $cnt['completed'], 'fa-circle-check', 'history.php'],
];
?>
<div class="row g-3 mb-4">
<?php foreach ($tiles as $t): ?>
    <div class="col-xl-3 col-md-6"><a href="<?php echo $t[3]; ?>" class="text-decoration-none"><div class="card h-100"><div class="card-body d-flex align-items-center gap-3">
        <span class="icon-bubble"><i class="fas <?php echo $t[2]; ?>"></i></span>
        <div><div class="metric-label"><?php echo h($t[0]); ?></div><div class="metric-value"><?php echo (int)$t[1]; ?></div></div>
    </div></div></a></div>
<?php endforeach; ?>
</div>

<div class="row g-4">
    <div class="col-lg-7">
        <div class="card mb-4"><div class="card-header d-flex justify-content-between"><h5 class="mb-0"><i class="fas fa-file-circle-plus me-2 text-warning"></i> New purchase orders</h5><a class="small" href="orders.php">View all</a></div><div class="card-body">
            <?php if (!$newPos): ?><div class="text-center text-muted py-3 small"><i class="fas fa-circle-check fa-2x text-success mb-2 d-block"></i>No new purchase orders waiting for you.</div><?php endif; ?>
            <?php foreach ($newPos as $p): ?>
            <a class="soft-row" href="order.php?id=<?php echo (int)$p['id']; ?>"><span class="count-pill warn"><i class="fas fa-file-signature"></i></span>
                <span><strong><?php echo h($p['po_number']); ?></strong><div class="small text-muted">Issued <?php echo h(sp_fmt_date($p['sent_at'])); ?> · needed by <?php echo h(sp_fmt_date($p['delivery_date'])); ?></div></span>
                <strong class="ms-auto"><?php echo h(sp_money($p['grand_total'])); ?></strong></a>
            <?php endforeach; ?>
        </div></div>

        <div class="card mb-4"><div class="card-header d-flex justify-content-between"><h5 class="mb-0"><i class="fas fa-file-invoice-dollar me-2 text-primary"></i> Quotations to submit</h5><a class="small" href="rfqs.php">View all</a></div><div class="card-body">
            <?php if (!$rfqs): ?><div class="text-center text-muted py-3 small">No open requests for quotation.</div><?php endif; ?>
            <?php foreach ($rfqs as $r): ?>
            <a class="soft-row" href="rfq.php?id=<?php echo (int)$r['id']; ?>"><span><strong><?php echo h($r['rfq_number']); ?></strong><div class="small text-muted"><?php echo h($r['title'] ?: 'Request for quotation'); ?></div></span>
                <span class="ms-auto small text-muted">Due <?php echo $r['submission_deadline'] ? h(date('M d, H:i', strtotime($r['submission_deadline']))) : 'open'; ?></span></a>
            <?php endforeach; ?>
        </div></div>

        <div class="card"><div class="card-header d-flex justify-content-between"><h5 class="mb-0"><i class="fas fa-truck-fast me-2 text-primary"></i> Orders in delivery</h5><a class="small" href="deliveries.php">Delivery updates</a></div><div class="card-body">
            <?php if (!$active): ?><div class="text-center text-muted py-3 small">No orders in delivery.</div><?php endif; ?>
            <?php foreach ($active as $p): ?>
            <a class="soft-row" href="order.php?id=<?php echo (int)$p['id']; ?>"><span><strong><?php echo h($p['po_number']); ?></strong><div class="small text-muted">ETA <?php echo h(sp_fmt_date($p['expected_delivery_date'])); ?></div></span>
                <span class="ms-auto"><?php echo sp_stage_badge($p); ?></span></a>
            <?php endforeach; ?>
        </div></div>
    </div>
    <div class="col-lg-5">
        <div class="card mb-4"><div class="card-header d-flex justify-content-between"><h5 class="mb-0"><i class="fas fa-bell me-2 text-primary"></i> Notifications</h5><a class="small" href="notifications.php">View all</a></div><div class="card-body">
            <?php if (!$notes): ?><div class="text-muted small text-center py-3">No notifications yet.</div><?php endif; ?>
            <?php foreach ($notes as $n): ?>
            <a class="soft-row" href="<?php echo h($n['link'] ?: 'notifications.php'); ?>"><div class="small"><?php if (!$n['is_read']): ?><i class="fas fa-circle text-primary me-1" style="font-size:.5rem"></i><?php endif; ?><strong><?php echo h($n['title']); ?></strong><div class="text-muted"><?php echo h($n['message']); ?></div></div></a>
            <?php endforeach; ?>
        </div></div>
        <div class="card"><div class="card-header d-flex justify-content-between"><h5 class="mb-0"><i class="fas fa-clock-rotate-left me-2 text-primary"></i> Transaction history</h5><a class="small" href="history.php">View all</a></div><div class="card-body">
            <?php if (!$hist): ?><div class="text-muted small text-center py-3">No completed orders yet.</div><?php endif; ?>
            <?php foreach ($hist as $p): ?>
            <a class="soft-row" href="order.php?id=<?php echo (int)$p['id']; ?>"><span class="small"><strong><?php echo h($p['po_number']); ?></strong><div class="text-muted"><?php echo h(sp_fmt_date($p['sent_at'])); ?></div></span><strong class="ms-auto small"><?php echo h(sp_money($p['grand_total'])); ?></strong></a>
            <?php endforeach; ?>
        </div></div>
    </div>
</div>
<?php include __DIR__ . '/_layout_bottom.php';
