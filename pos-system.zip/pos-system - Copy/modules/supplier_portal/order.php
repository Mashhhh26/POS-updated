<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/supplier_portal.php';
verify_csrf();
$db = getDB();
$sup = sp_require_supplier($db);
$sid = (int)$sup['id'];

$poId = (int)($_POST['po_id'] ?? $_GET['id'] ?? 0);
$po = sp_load_po($db, $poId, $sid);   // supplier id comes from the account link, never from the request
if (!$po) { header('Location: orders.php?err=' . urlencode('Purchase order not found.')); exit(); }
$success_message = null;
$error_message = null;

function ord_back(int $id, string $ok): void {
    header('Location: order.php?id=' . $id . '&ok=' . urlencode($ok));
    exit();
}

$activeStatuses = ['acknowledged', 'partially_received'];
$openStatuses = ['sent', 'acknowledged', 'partially_received'];
$deliveryOrder = ['not_started' => 0, 'preparing' => 1, 'shipped' => 2, 'delivered' => 3];
$staffPath = 'modules/procurement/po_view.php?id=' . $poId;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $today = date('Y-m-d');
    try {
        switch ($action) {
            case 'confirm':
                if ($po['status'] !== 'sent' || $po['supplier_response'] !== 'pending') throw new Exception('This order is no longer waiting for your response.');
                $eta = $_POST['expected_delivery_date'] ?? '';
                if (!sp_is_date($eta) || $eta < $today) throw new Exception('Enter a valid expected delivery date (today or later).');
                $remarks = substr(trim($_POST['remarks'] ?? ''), 0, 500);
                $u = $db->prepare("UPDATE purchase_orders SET status='acknowledged', supplier_response='confirmed', supplier_responded_at=NOW(), supplier_remarks=?, expected_delivery_date=?, delivery_status='not_started', acknowledged_at=NOW(), acknowledgement_note='Confirmed by supplier via portal' WHERE id=? AND supplier_id=? AND status='sent'");
                $u->execute([$remarks !== '' ? $remarks : null, $eta, $poId, $sid]);
                if ($u->rowCount() === 0) throw new Exception('Could not confirm: the order changed. Refresh and try again.');
                sp_log_event($db, $poId, $sid, 'supplier', 'confirmed', 'ETA ' . $eta . ($remarks !== '' ? ' - ' . $remarks : ''));
                logActivity("Supplier portal: {$sup['company_name']} confirmed {$po['po_number']} (ETA $eta)");
                sp_notify_staff($db, 'PO confirmed by supplier', $sup['company_name'] . ' confirmed ' . $po['po_number'] . ' (ETA ' . sp_fmt_date($eta) . ').', $staffPath, 'PO confirmed: ' . $po['po_number']);
                ord_back($poId, 'Order confirmed. Thank you!');

            case 'reject':
                if ($po['status'] !== 'sent' || $po['supplier_response'] !== 'pending') throw new Exception('This order is no longer waiting for your response.');
                $reason = trim($_POST['reason'] ?? '');
                if (strlen($reason) < 10) throw new Exception('Please explain why you cannot fulfil this order (at least 10 characters).');
                $reason = substr($reason, 0, 500);
                $u = $db->prepare("UPDATE purchase_orders SET status='rejected', supplier_response='rejected', supplier_responded_at=NOW(), supplier_remarks=? WHERE id=? AND supplier_id=? AND status='sent'");
                $u->execute([$reason, $poId, $sid]);
                if ($u->rowCount() === 0) throw new Exception('Could not reject: the order changed. Refresh and try again.');
                sp_log_event($db, $poId, $sid, 'supplier', 'rejected', $reason);
                logActivity("Supplier portal: {$sup['company_name']} rejected {$po['po_number']} - $reason");
                sp_notify_staff($db, 'PO rejected by supplier', $sup['company_name'] . ' rejected ' . $po['po_number'] . ': ' . $reason, $staffPath, 'PO rejected: ' . $po['po_number']);
                ord_back($poId, 'Order rejected. Procurement has been notified.');

            case 'add_remark':
                if (!in_array($po['status'], $openStatuses, true)) throw new Exception('Remarks can only be added to open orders.');
                $remark = trim($_POST['remark'] ?? '');
                if (strlen($remark) < 3) throw new Exception('Write a remark (at least 3 characters).');
                $remark = substr($remark, 0, 500);
                sp_log_event($db, $poId, $sid, 'supplier', 'remark', $remark);
                sp_notify_staff($db, 'Supplier remark on ' . $po['po_number'], $sup['company_name'] . ': ' . $remark, $staffPath);
                ord_back($poId, 'Remark added.');

            case 'update_eta':
                if (!in_array($po['status'], $activeStatuses, true)) throw new Exception('Delivery date can only be changed on a confirmed order.');
                $eta = $_POST['expected_delivery_date'] ?? '';
                $why = trim($_POST['reason'] ?? '');
                if (!sp_is_date($eta) || $eta < $today) throw new Exception('Enter a valid expected delivery date (today or later).');
                if (strlen($why) < 5) throw new Exception('Give a short reason for the change (at least 5 characters).');
                $old = $po['expected_delivery_date'];
                $db->prepare("UPDATE purchase_orders SET expected_delivery_date=?, delivery_updated_at=NOW() WHERE id=? AND supplier_id=?")->execute([$eta, $poId, $sid]);
                sp_log_event($db, $poId, $sid, 'supplier', 'eta_updated', ($old ?: 'none') . ' to ' . $eta . ': ' . substr($why, 0, 300));
                sp_notify_staff($db, 'Delivery date changed', $po['po_number'] . ': new ETA ' . sp_fmt_date($eta) . ' (' . $why . ')', $staffPath);
                ord_back($poId, 'Expected delivery date updated.');

            case 'update_delivery':
                if (!in_array($po['status'], $activeStatuses, true)) throw new Exception('Delivery status can only be updated on a confirmed order.');
                $new = $_POST['delivery_status'] ?? '';
                $note = substr(trim($_POST['delivery_note'] ?? ''), 0, 255);
                if (!isset($deliveryOrder[$new]) || $new === 'not_started') throw new Exception('Choose a delivery status.');
                if ($deliveryOrder[$new] <= $deliveryOrder[$po['delivery_status']]) throw new Exception('Delivery status can only move forward.');
                $ship = null;
                if ($new === 'shipped') {
                    $carrier = substr(trim($_POST['carrier'] ?? ''), 0, 100);
                    $track = substr(trim($_POST['tracking_no'] ?? ''), 0, 100);
                    $shipDate = $_POST['ship_date'] ?? $today;
                    $arrive = trim($_POST['expected_arrival'] ?? '');
                    if (strlen($carrier) < 2) throw new Exception('Enter the carrier / courier for this shipment.');
                    if (!sp_is_date($shipDate) || $shipDate > $today) throw new Exception('Ship date must be a valid date that is not in the future.');
                    if ($arrive !== '' && (!sp_is_date($arrive) || $arrive < $shipDate)) throw new Exception('Expected arrival must be a valid date on/after the ship date.');
                    $ship = [$carrier, $track !== '' ? $track : null, $shipDate, $arrive !== '' ? $arrive : null];
                }
                $db->beginTransaction();
                $db->prepare("UPDATE purchase_orders SET delivery_status=?, delivery_note=COALESCE(?, delivery_note), delivery_updated_at=NOW() WHERE id=? AND supplier_id=?")->execute([$new, $note !== '' ? $note : null, $poId, $sid]);
                if ($ship) {
                    $db->prepare("INSERT INTO po_shipments(po_id,supplier_id,carrier,tracking_no,ship_date,expected_arrival,remarks,created_by) VALUES(?,?,?,?,?,?,?,?)")
                       ->execute([$poId, $sid, $ship[0], $ship[1], $ship[2], $ship[3], $note !== '' ? $note : null, $_SESSION['user_id']]);
                    if ($ship[3]) $db->prepare("UPDATE purchase_orders SET expected_delivery_date=? WHERE id=?")->execute([$ship[3], $poId]);
                }
                $db->commit();
                sp_log_event($db, $poId, $sid, 'supplier', 'delivery_updated', sp_delivery_label($po['delivery_status']) . ' to ' . sp_delivery_label($new) . ($ship ? ' via ' . $ship[0] . ($ship[1] ? ' #' . $ship[1] : '') : '') . ($note !== '' ? ' (' . $note . ')' : ''));
                logActivity("Supplier portal: {$sup['company_name']} set {$po['po_number']} delivery to $new");
                $emailSub = in_array($new, ['shipped', 'delivered'], true) ? 'Delivery update: ' . $po['po_number'] . ' is ' . $new : null;
                sp_notify_staff($db, 'Delivery update', $po['po_number'] . ' is now ' . sp_delivery_label($new) . ($ship ? ' via ' . $ship[0] : '') . ($note !== '' ? ' (' . $note . ')' : '') . '.', $staffPath, $emailSub);
                ord_back($poId, 'Delivery status updated.');

            case 'request_change':
                if (!in_array($po['status'], $openStatuses, true)) throw new Exception('Changes can only be requested on an open order.');
                $pend = $db->prepare("SELECT COUNT(*) FROM po_change_requests WHERE po_id=? AND status='pending'");
                $pend->execute([$poId]);
                if ((int)$pend->fetchColumn() > 0) throw new Exception('You already have a change request waiting for approval on this order.');
                $reason = trim($_POST['reason'] ?? '');
                if (strlen($reason) < 10) throw new Exception('Explain why you need the change (at least 10 characters).');
                $newDate = trim($_POST['new_delivery_date'] ?? '');
                if ($newDate !== '' && (!sp_is_date($newDate) || $newDate < $today)) throw new Exception('The proposed delivery date must be today or later.');
                if ($newDate === $po['delivery_date']) $newDate = '';
                $newTerms = substr(trim($_POST['new_payment_terms'] ?? ''), 0, 50);
                if ($newTerms === (string)$po['payment_terms']) $newTerms = '';
                $itemRows = $db->prepare("SELECT id, item_description, quantity, unit_price, received_quantity FROM po_items WHERE po_id=? ORDER BY id");
                $itemRows->execute([$poId]);
                $changes = [];
                foreach ($itemRows->fetchAll() as $it) {
                    $x = $_POST['cr'][$it['id']] ?? null;
                    if (!$x) continue;
                    $qty = trim((string)($x['quantity'] ?? ''));
                    $price = trim((string)($x['unit_price'] ?? ''));
                    if ($qty === '' && $price === '') continue;
                    if (filter_var($qty, FILTER_VALIDATE_INT) === false || (int)$qty < max(1, (int)$it['received_quantity']) || (int)$qty > 1000000) throw new Exception('Quantity for "' . $it['item_description'] . '" must be a whole number of at least ' . max(1, (int)$it['received_quantity']) . ' (already received counts).');
                    if (!valid_money($price, false)) throw new Exception('Enter a valid unit price for "' . $it['item_description'] . '".');
                    if ((int)$qty !== (int)$it['quantity'] || round((float)$price, 2) !== round((float)$it['unit_price'], 2)) $changes[] = ['item_id' => (int)$it['id'], 'quantity' => (int)$qty, 'unit_price' => round((float)$price, 2)];
                }
                if ($newDate === '' && $newTerms === '' && !$changes) throw new Exception('You did not change anything. Edit a quantity, price, delivery date or payment terms.');
                $db->prepare("INSERT INTO po_change_requests(po_id,supplier_id,requested_by,new_delivery_date,new_payment_terms,items_json,reason) VALUES(?,?,?,?,?,?,?)")
                   ->execute([$poId, $sid, $_SESSION['user_id'], $newDate !== '' ? $newDate : null, $newTerms !== '' ? $newTerms : null, $changes ? json_encode($changes) : null, substr($reason, 0, 500)]);
                sp_log_event($db, $poId, $sid, 'supplier', 'change_requested', substr($reason, 0, 300));
                logActivity("Supplier portal: {$sup['company_name']} requested a change on {$po['po_number']}");
                sp_notify_staff($db, 'PO change request', $sup['company_name'] . ' requested a change on ' . $po['po_number'] . ': ' . $reason, 'modules/procurement/po_revisions.php', 'PO change request: ' . $po['po_number']);
                ord_back($poId, 'Change request sent. The order stays as issued until procurement approves it.');

            case 'withdraw_change':
                $w = $db->prepare("UPDATE po_change_requests SET status='withdrawn' WHERE id=? AND po_id=? AND supplier_id=? AND status='pending'");
                $w->execute([(int)($_POST['request_id'] ?? 0), $poId, $sid]);
                if ($w->rowCount() === 0) throw new Exception('That request can no longer be withdrawn.');
                sp_log_event($db, $poId, $sid, 'supplier', 'change_withdrawn', null);
                ord_back($poId, 'Change request withdrawn.');

            case 'upload_doc':
                if (!in_array($po['status'], array_merge($openStatuses, ['fulfilled']), true)) throw new Exception('Documents can only be added to an active order.');
                $type = $_POST['doc_type'] ?? 'other';
                if (!in_array($type, ['delivery_receipt', 'packing_list', 'invoice', 'certificate', 'other'], true)) throw new Exception('Choose a document type.');
                $docId = sp_store_upload($db, $_FILES['file'] ?? [], ['supplier_id' => $sid, 'po_id' => $poId, 'doc_type' => $type, 'by' => 'supplier', 'note' => trim($_POST['note'] ?? '')]);
                sp_log_event($db, $poId, $sid, 'supplier', 'document_uploaded', sp_doc_types()[$type]);
                logActivity("Supplier portal: {$sup['company_name']} uploaded document #$docId for {$po['po_number']}");
                sp_notify_staff($db, 'Supplier document uploaded', $sup['company_name'] . ' uploaded a ' . strtolower(sp_doc_types()[$type]) . ' for ' . $po['po_number'] . '.', $staffPath);
                ord_back($poId, 'Document uploaded.');

            case 'discrepancy_response':
                $resp = trim($_POST['response'] ?? '');
                if (strlen($resp) < 5) throw new Exception('Write your response (at least 5 characters).');
                $u = $db->prepare("UPDATE receiving_discrepancies SET supplier_response=?, supplier_responded_at=NOW() WHERE id=? AND po_id=? AND supplier_id=? AND status<>'resolved'");
                $u->execute([substr($resp, 0, 500), (int)($_POST['disc_id'] ?? 0), $poId, $sid]);
                if ($u->rowCount() === 0) throw new Exception('That discrepancy can no longer be updated.');
                sp_log_event($db, $poId, $sid, 'supplier', 'discrepancy_response', substr($resp, 0, 300));
                sp_notify_staff($db, 'Supplier replied to a discrepancy', $sup['company_name'] . ' responded on ' . $po['po_number'] . ': ' . $resp, 'modules/procurement/discrepancies.php');
                ord_back($poId, 'Your response was sent to procurement.');
        }
    } catch (Throwable $e) {
        if ($db->inTransaction()) $db->rollBack();
        $error_message = $e->getMessage();
        $po = sp_load_po($db, $poId, $sid) ?: $po;
    }
}

$items = $db->prepare("SELECT id, item_description, quantity, unit_price, total, received_quantity FROM po_items WHERE po_id=? ORDER BY id");
$items->execute([$poId]);
$items = $items->fetchAll();
$events = $db->prepare("SELECT * FROM supplier_po_events WHERE po_id=? ORDER BY id DESC LIMIT 40");
$events->execute([$poId]);
$events = $events->fetchAll();
$shipments = $db->prepare("SELECT * FROM po_shipments WHERE po_id=? AND supplier_id=? ORDER BY id DESC");
$shipments->execute([$poId, $sid]);
$shipments = $shipments->fetchAll();
$docs = $db->prepare("SELECT * FROM supplier_documents WHERE po_id=? AND supplier_id=? ORDER BY id DESC");
$docs->execute([$poId, $sid]);
$docs = $docs->fetchAll();
$crs = $db->prepare("SELECT * FROM po_change_requests WHERE po_id=? AND supplier_id=? ORDER BY id DESC LIMIT 10");
$crs->execute([$poId, $sid]);
$crs = $crs->fetchAll();
$pendingCr = null;
foreach ($crs as $c) if ($c['status'] === 'pending') { $pendingCr = $c; break; }
$revs = $db->prepare("SELECT revision_no, summary, created_at FROM po_revisions WHERE po_id=? ORDER BY revision_no DESC");
$revs->execute([$poId]);
$revs = $revs->fetchAll();
$discs = $db->prepare("SELECT d.*, i.item_description FROM receiving_discrepancies d LEFT JOIN po_items i ON i.id=d.po_item_id WHERE d.po_id=? AND d.supplier_id=? ORDER BY d.id DESC");
$discs->execute([$poId, $sid]);
$discs = $discs->fetchAll();

$isOpenNew = $po['status'] === 'sent' && $po['supplier_response'] === 'pending';
$isActive = in_array($po['status'], $activeStatuses, true);
$isOpen = in_array($po['status'], $openStatuses, true);
$curDl = $po['delivery_status'] ?: 'not_started';
$defaultEta = date('Y-m-d', strtotime('+' . max(1, (int)($sup['lead_time_days'] ?? 7)) . ' days'));
$dlLabels = ['preparing' => 'Preparing order', 'shipped' => 'Shipped / on the way', 'delivered' => 'Delivered to the buyer'];
$crLabel = ['pending' => ['Waiting for approval', 'warning'], 'approved' => ['Approved', 'success'], 'rejected' => ['Rejected', 'danger'], 'withdrawn' => ['Withdrawn', 'secondary']];

$pageTitle = $po['po_number'];
$pageIcon = 'fa-file-signature';
$pageActions = '<a class="btn btn-outline-secondary" href="orders.php"><i class="fas fa-arrow-left me-1"></i> All orders</a>';
include __DIR__ . '/_layout_top.php';
?>
<div class="row g-4">
<div class="col-lg-8">
    <div class="card mb-4"><div class="card-body">
        <div class="d-flex flex-wrap justify-content-between align-items-start gap-2 mb-3">
            <div><div class="metric-label">Status</div><div class="mt-1"><?php echo sp_stage_badge($po); ?><?php if ((int)$po['revision_no'] > 0): ?> <span class="badge bg-info">Revision <?php echo (int)$po['revision_no']; ?></span><?php endif; ?></div></div>
            <div class="text-end"><div class="metric-label">Order total</div><div class="metric-value"><?php echo h(sp_money($po['grand_total'])); ?></div></div>
        </div>
        <div class="row g-3 small">
            <div class="col-sm-4"><div class="text-muted">Issued</div><strong><?php echo h(sp_fmt_date($po['sent_at'])); ?></strong></div>
            <div class="col-sm-4"><div class="text-muted">Needed by</div><strong><?php echo h(sp_fmt_date($po['delivery_date'])); ?></strong></div>
            <div class="col-sm-4"><div class="text-muted">Payment terms</div><strong><?php echo h($po['payment_terms'] ?: '—'); ?></strong></div>
        </div>
        <div class="small text-muted mt-3"><i class="fas fa-lock me-1"></i> An issued purchase order cannot be edited by the supplier. To change quantities, prices, dates or terms, send a change request below.</div>
    </div></div>

    <div class="card mb-4"><div class="card-header"><h5 class="mb-0">Items ordered</h5></div>
    <div class="table-responsive"><table class="table mb-0">
        <thead><tr><th>Description</th><th class="text-end">Qty</th><th class="text-end">Unit price</th><th class="text-end">Line total</th><th class="text-end">Accepted so far</th></tr></thead><tbody>
        <?php foreach ($items as $i): ?><tr><td><?php echo h($i['item_description']); ?></td><td class="text-end"><?php echo (int)$i['quantity']; ?></td><td class="text-end"><?php echo h(sp_money($i['unit_price'])); ?></td><td class="text-end"><?php echo h(sp_money($i['total'])); ?></td><td class="text-end"><?php echo (int)$i['received_quantity']; ?></td></tr><?php endforeach; ?>
        <tr class="fw-semibold"><td colspan="3" class="text-end text-muted">Subtotal</td><td class="text-end"><?php echo h(sp_money($po['total_amount'])); ?></td><td></td></tr>
        <?php if ((float)$po['tax'] > 0): ?><tr><td colspan="3" class="text-end text-muted">Tax</td><td class="text-end"><?php echo h(sp_money($po['tax'])); ?></td><td></td></tr><?php endif; ?>
        <?php if ((float)$po['shipping_cost'] > 0): ?><tr><td colspan="3" class="text-end text-muted">Shipping</td><td class="text-end"><?php echo h(sp_money($po['shipping_cost'])); ?></td><td></td></tr><?php endif; ?>
        <tr class="fw-bold"><td colspan="3" class="text-end">Grand total</td><td class="text-end"><?php echo h(sp_money($po['grand_total'])); ?></td><td></td></tr>
        </tbody></table></div></div>

    <?php if ($isOpenNew): ?>
    <div class="card mb-4 border-warning"><div class="card-header"><h5 class="mb-0"><i class="fas fa-reply me-2 text-warning"></i> Respond to this order</h5></div><div class="card-body"><div class="row g-4">
        <div class="col-md-6"><h6 class="text-success"><i class="fas fa-check me-1"></i> Confirm</h6>
            <form method="POST" data-confirm="Confirm this purchase order and commit to the delivery date?"><?php echo csrf_field(); ?><input type="hidden" name="action" value="confirm"><input type="hidden" name="po_id" value="<?php echo $poId; ?>">
                <label class="form-label">Expected delivery date *</label><input type="date" name="expected_delivery_date" class="form-control mb-2" min="<?php echo date('Y-m-d'); ?>" value="<?php echo h($defaultEta); ?>" required>
                <label class="form-label">Remarks (optional)</label><textarea name="remarks" rows="2" maxlength="500" class="form-control mb-2"></textarea>
                <button class="btn btn-success w-100">Confirm order</button></form></div>
        <div class="col-md-6"><h6 class="text-danger"><i class="fas fa-xmark me-1"></i> Reject</h6>
            <form method="POST" data-confirm="Reject this purchase order? Procurement will be notified."><?php echo csrf_field(); ?><input type="hidden" name="action" value="reject"><input type="hidden" name="po_id" value="<?php echo $poId; ?>">
                <label class="form-label">Reason *</label><textarea name="reason" rows="4" minlength="10" maxlength="500" class="form-control mb-2" placeholder="e.g. Item out of stock until next month" required></textarea>
                <button class="btn btn-outline-danger w-100">Reject order</button></form></div>
    </div></div></div>
    <?php endif; ?>

    <?php if ($isActive): ?>
    <div class="card mb-4" id="delivery"><div class="card-header"><h5 class="mb-0"><i class="fas fa-truck-fast me-2 text-primary"></i> Delivery updates</h5></div><div class="card-body"><div class="row g-4">
        <div class="col-md-7"><h6>Delivery status &amp; shipment</h6>
            <?php $opts = array_filter($dlLabels, function ($k) use ($deliveryOrder, $curDl) { return $deliveryOrder[$k] > $deliveryOrder[$curDl]; }, ARRAY_FILTER_USE_KEY); ?>
            <?php if ($opts): ?>
            <form method="POST" data-confirm="Update the delivery status? Procurement will be notified."><?php echo csrf_field(); ?><input type="hidden" name="action" value="update_delivery"><input type="hidden" name="po_id" value="<?php echo $poId; ?>">
                <select name="delivery_status" id="dlSel" class="form-select mb-2" required><?php foreach ($opts as $k => $l): ?><option value="<?php echo h($k); ?>"><?php echo h($l); ?></option><?php endforeach; ?></select>
                <div id="shipFields" class="row g-2 mb-2" style="display:none">
                    <div class="col-md-6"><input type="text" name="carrier" maxlength="100" class="form-control" placeholder="Carrier / courier *"></div>
                    <div class="col-md-6"><input type="text" name="tracking_no" maxlength="100" class="form-control" placeholder="Tracking / waybill no."></div>
                    <div class="col-md-6"><label class="form-label small mb-0">Ship date</label><input type="date" name="ship_date" max="<?php echo date('Y-m-d'); ?>" value="<?php echo date('Y-m-d'); ?>" class="form-control"></div>
                    <div class="col-md-6"><label class="form-label small mb-0">Expected arrival</label><input type="date" name="expected_arrival" min="<?php echo date('Y-m-d'); ?>" class="form-control"></div>
                </div>
                <input type="text" name="delivery_note" maxlength="255" class="form-control mb-2" placeholder="Delivery remarks (optional)">
                <button class="btn btn-primary w-100">Update status</button></form>
            <?php else: ?><div class="text-muted small">Marked as delivered. Procurement will inspect and receive the goods.</div><?php endif; ?>
        </div>
        <div class="col-md-5"><h6>Expected delivery date</h6>
            <form method="POST" data-confirm="Change the expected delivery date?"><?php echo csrf_field(); ?><input type="hidden" name="action" value="update_eta"><input type="hidden" name="po_id" value="<?php echo $poId; ?>">
                <input type="date" name="expected_delivery_date" class="form-control mb-2" min="<?php echo date('Y-m-d'); ?>" value="<?php echo h($po['expected_delivery_date'] ?: $defaultEta); ?>" required>
                <input type="text" name="reason" maxlength="300" minlength="5" class="form-control mb-2" placeholder="Reason for the change *" required>
                <button class="btn btn-outline-primary w-100">Update date</button></form></div>
    </div>
    <?php if ($shipments): ?><hr><h6>Shipments</h6><?php foreach ($shipments as $s): ?><div class="soft-row small"><i class="fas fa-box"></i><span><strong><?php echo h($s['carrier']); ?></strong><?php echo $s['tracking_no'] ? ' · ' . h($s['tracking_no']) : ''; ?><div class="text-muted">Shipped <?php echo h(sp_fmt_date($s['ship_date'])); ?><?php echo $s['expected_arrival'] ? ' · arrives ' . h(sp_fmt_date($s['expected_arrival'])) : ''; ?></div></span></div><?php endforeach; ?><?php endif; ?>
    </div></div>
    <script>(function(){var s=document.getElementById('dlSel');if(!s)return;var f=document.getElementById('shipFields');function t(){f.style.display=s.value==='shipped'?'flex':'none';}s.addEventListener('change',t);t();})();</script>
    <?php endif; ?>

    <?php if ($isOpen): ?>
    <div class="card mb-4"><div class="card-header"><h5 class="mb-0"><i class="fas fa-pen-to-square me-2 text-primary"></i> Request a change</h5><div class="small text-muted mt-1">The order is not changed until an authorized buyer approves your request. Each approved change becomes a numbered revision.</div></div><div class="card-body">
    <?php if ($pendingCr): ?>
        <div class="alert alert-warning mb-0"><strong>Waiting for approval</strong> — sent <?php echo h(date('M d, H:i', strtotime($pendingCr['created_at']))); ?>. <?php echo h($pendingCr['reason']); ?>
            <form method="POST" class="mt-2" data-confirm="Withdraw this change request?"><?php echo csrf_field(); ?><input type="hidden" name="action" value="withdraw_change"><input type="hidden" name="po_id" value="<?php echo $poId; ?>"><input type="hidden" name="request_id" value="<?php echo (int)$pendingCr['id']; ?>"><button class="btn btn-sm btn-outline-secondary">Withdraw request</button></form></div>
    <?php else: ?>
        <form method="POST" data-confirm="Send this change request to procurement?"><?php echo csrf_field(); ?><input type="hidden" name="action" value="request_change"><input type="hidden" name="po_id" value="<?php echo $poId; ?>">
            <div class="table-responsive mb-3"><table class="table table-sm align-middle mb-0"><thead><tr><th>Item</th><th style="width:120px">Quantity</th><th style="width:140px">Unit price (₱)</th></tr></thead><tbody>
            <?php foreach ($items as $i): ?><tr><td><?php echo h($i['item_description']); ?><div class="small text-muted">now <?php echo (int)$i['quantity']; ?> × <?php echo h(sp_money($i['unit_price'])); ?>; accepted <?php echo (int)$i['received_quantity']; ?></div></td>
                <td><input type="number" min="<?php echo max(1, (int)$i['received_quantity']); ?>" name="cr[<?php echo (int)$i['id']; ?>][quantity]" class="form-control form-control-sm" value="<?php echo (int)$i['quantity']; ?>"></td>
                <td><input type="number" step="0.01" min="0.01" name="cr[<?php echo (int)$i['id']; ?>][unit_price]" class="form-control form-control-sm" value="<?php echo h($i['unit_price']); ?>"></td></tr><?php endforeach; ?>
            </tbody></table></div>
            <div class="row g-2 mb-2"><div class="col-md-6"><label class="form-label">Proposed delivery date</label><input type="date" name="new_delivery_date" min="<?php echo date('Y-m-d'); ?>" class="form-control"></div>
                <div class="col-md-6"><label class="form-label">Proposed payment terms</label><input type="text" name="new_payment_terms" maxlength="50" class="form-control" placeholder="<?php echo h($po['payment_terms'] ?: ''); ?>"></div></div>
            <label class="form-label">Reason *</label><textarea name="reason" rows="2" minlength="10" maxlength="500" class="form-control mb-2" required></textarea>
            <button class="btn btn-outline-primary">Send change request</button>
        </form>
    <?php endif; ?>
    <?php if ($crs): ?><hr><h6>Your requests</h6><?php foreach ($crs as $c): $l = $crLabel[$c['status']]; ?><div class="soft-row small"><span><?php echo h(date('M d', strtotime($c['created_at']))); ?> — <?php echo h($c['reason']); ?><?php if ($c['decision_note']): ?><div class="text-muted">Decision: <?php echo h($c['decision_note']); ?></div><?php endif; ?></span><span class="ms-auto badge bg-<?php echo $l[1]; ?>"><?php echo h($l[0]); ?></span></div><?php endforeach; ?><?php endif; ?>
    </div></div>
    <?php endif; ?>

    <?php if ($discs): ?>
    <div class="card mb-4"><div class="card-header"><h5 class="mb-0"><i class="fas fa-triangle-exclamation me-2 text-warning"></i> Receiving discrepancies</h5></div><div class="card-body">
    <?php foreach ($discs as $d): ?>
        <div class="border rounded-3 p-3 mb-2">
            <div class="d-flex flex-wrap justify-content-between gap-2"><strong><?php echo (int)$d['quantity']; ?> × <?php echo h($d['item_description'] ?: 'item'); ?> — <?php echo h(sp_disc_type_label($d['disc_type'])); ?></strong><?php echo sp_disc_status_badge($d['status']); ?></div>
            <div class="small text-muted mt-1"><?php echo h($d['description']); ?></div>
            <?php if ($d['resolution']): ?><div class="small mt-1"><strong>Resolution:</strong> <?php echo h(ucfirst(str_replace('_', ' ', $d['resolution']))); ?><?php echo $d['resolution_note'] ? ' — ' . h($d['resolution_note']) : ''; ?></div><?php endif; ?>
            <?php if ($d['supplier_response']): ?><div class="small mt-1"><strong>Your response:</strong> <?php echo h($d['supplier_response']); ?></div><?php endif; ?>
            <?php if ($d['status'] !== 'resolved'): ?><form method="POST" class="d-flex gap-2 mt-2"><?php echo csrf_field(); ?><input type="hidden" name="action" value="discrepancy_response"><input type="hidden" name="po_id" value="<?php echo $poId; ?>"><input type="hidden" name="disc_id" value="<?php echo (int)$d['id']; ?>"><input type="text" name="response" maxlength="500" minlength="5" class="form-control form-control-sm" placeholder="Reply to procurement" required><button class="btn btn-sm btn-primary">Send</button></form><?php endif; ?>
        </div>
    <?php endforeach; ?>
    </div></div>
    <?php endif; ?>

    <?php if ($isOpen || $po['status'] === 'fulfilled'): ?>
    <div class="card mb-4"><div class="card-header"><h5 class="mb-0"><i class="fas fa-folder-open me-2 text-primary"></i> Documents</h5></div><div class="card-body">
        <form method="POST" enctype="multipart/form-data" class="row g-2 mb-3"><?php echo csrf_field(); ?><input type="hidden" name="action" value="upload_doc"><input type="hidden" name="po_id" value="<?php echo $poId; ?>">
            <div class="col-md-4"><select name="doc_type" class="form-select"><?php foreach (['delivery_receipt', 'packing_list', 'invoice', 'certificate', 'other'] as $k): ?><option value="<?php echo $k; ?>"><?php echo h(sp_doc_types()[$k]); ?></option><?php endforeach; ?></select></div>
            <div class="col-md-5"><input type="file" name="file" class="form-control" accept=".pdf,.jpg,.jpeg,.png,.doc,.docx,.xls,.xlsx" required></div>
            <div class="col-md-3"><button class="btn btn-primary w-100"><i class="fas fa-upload me-1"></i> Upload</button></div>
            <div class="col-12"><input type="text" name="note" maxlength="255" class="form-control" placeholder="Note (optional)"></div>
        </form>
        <?php foreach ($docs as $d): ?><a class="soft-row" href="download.php?id=<?php echo (int)$d['id']; ?>"><i class="fas fa-paperclip"></i><span class="small"><strong><?php echo h($d['original_name']); ?></strong><div class="text-muted"><?php echo h(sp_doc_types()[$d['doc_type']] ?? $d['doc_type']); ?> · <?php echo $d['uploaded_by_type'] === 'supplier' ? 'you' : 'procurement'; ?></div></span><span class="ms-auto small text-muted"><?php echo h(sp_fmt_size((int)$d['size_bytes'])); ?></span></a><?php endforeach; ?>
        <?php if (!$docs): ?><div class="text-muted small">No documents attached yet.</div><?php endif; ?>
    </div></div>
    <?php endif; ?>

    <?php if ($isOpenNew || $isActive): ?>
    <div class="card mb-4"><div class="card-header"><h5 class="mb-0"><i class="fas fa-comment me-2 text-primary"></i> Add a remark</h5></div><div class="card-body">
        <form method="POST" class="d-flex gap-2"><?php echo csrf_field(); ?><input type="hidden" name="action" value="add_remark"><input type="hidden" name="po_id" value="<?php echo $poId; ?>">
            <input type="text" name="remark" class="form-control" maxlength="500" minlength="3" placeholder="Message to procurement" required><button class="btn btn-primary">Send</button></form>
    </div></div>
    <?php endif; ?>
</div>

<div class="col-lg-4">
    <div class="card mb-4"><div class="card-header"><h5 class="mb-0"><i class="fas fa-truck me-2 text-primary"></i> Delivery information</h5></div><div class="card-body small">
        <div class="d-flex justify-content-between mb-2"><span class="text-muted">Your response</span><strong><?php echo h(ucfirst($po['supplier_response'])); ?></strong></div>
        <div class="d-flex justify-content-between mb-2"><span class="text-muted">Expected delivery</span><strong><?php echo h(sp_fmt_date($po['expected_delivery_date'])); ?></strong></div>
        <div class="d-flex justify-content-between mb-2"><span class="text-muted">Delivery status</span><strong><?php echo h(sp_delivery_label($curDl)); ?></strong></div>
        <?php if ($po['delivery_note']): ?><div class="mb-2"><span class="text-muted">Note</span><div><?php echo h($po['delivery_note']); ?></div></div><?php endif; ?>
        <?php if ($po['supplier_remarks']): ?><div><span class="text-muted">Your remarks</span><div><?php echo h($po['supplier_remarks']); ?></div></div><?php endif; ?>
    </div></div>

    <?php if ($revs): ?><div class="card mb-4"><div class="card-header"><h5 class="mb-0"><i class="fas fa-code-compare me-2 text-primary"></i> Revision history</h5></div><div class="card-body">
        <?php foreach ($revs as $r): ?><div class="soft-row small"><span class="badge bg-info">Rev <?php echo (int)$r['revision_no']; ?></span><span><?php echo h($r['summary']); ?><div class="text-muted"><?php echo h(date('M d, Y', strtotime($r['created_at']))); ?></div></span></div><?php endforeach; ?>
    </div></div><?php endif; ?>

    <div class="card"><div class="card-header"><h5 class="mb-0"><i class="fas fa-timeline me-2 text-primary"></i> Activity</h5></div><div class="card-body">
        <?php if (!$events): ?><div class="text-muted small">No activity yet.</div><?php endif; ?>
        <?php foreach ($events as $e): ?>
        <div class="soft-row"><div class="small"><strong><?php echo h(ucfirst(str_replace('_', ' ', $e['event_type']))); ?></strong>
            <div class="text-muted"><?php echo h($e['actor_type'] === 'supplier' ? 'You' : ($e['actor_type'] === 'procurement' ? 'Procurement' : 'System')); ?> · <?php echo h(date('M d, H:i', strtotime($e['created_at']))); ?></div>
            <?php if ($e['note']): ?><div><?php echo h($e['note']); ?></div><?php endif; ?></div></div>
        <?php endforeach; ?>
    </div></div>
</div>
</div>
<?php include __DIR__ . '/_layout_bottom.php';
