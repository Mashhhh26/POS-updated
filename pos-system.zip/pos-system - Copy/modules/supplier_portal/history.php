<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/supplier_portal.php';
verify_csrf();
$db = getDB();
$sup = sp_require_supplier($db);
$sid = (int)$sup['id'];

$done = $db->prepare("SELECT po.* FROM purchase_orders po WHERE po.supplier_id=? AND po.status IN ('fulfilled','closed','rejected','cancelled') AND po.sent_at IS NOT NULL ORDER BY po.sent_at DESC LIMIT 300");
$done->execute([$sid]);
$done = $done->fetchAll();

$sum = $db->prepare("SELECT COUNT(*) c, COALESCE(SUM(grand_total),0) t FROM purchase_orders WHERE supplier_id=? AND status IN ('fulfilled','closed')");
$sum->execute([$sid]);
$sum = $sum->fetch();

// payment visibility: only this supplier's own invoices
$inv = [];
try {
    $iq = $db->prepare("SELECT po_id, COUNT(*) AS c, COALESCE(MAX(status='paid'),0) AS paid FROM invoices WHERE supplier_id=? GROUP BY po_id");
    $iq->execute([$sid]);
    foreach ($iq->fetchAll() as $r) $inv[(int)$r['po_id']] = $r;
} catch (Throwable $e) { /* invoices optional */ }

$supplied = $db->prepare("SELECT i.item_description, SUM(i.received_quantity) AS qty, COUNT(DISTINCT i.po_id) AS pos
    FROM po_items i JOIN purchase_orders po ON po.id=i.po_id
    WHERE po.supplier_id=? AND po.status IN ('partially_received','fulfilled','closed') AND i.received_quantity>0
    GROUP BY i.item_description ORDER BY qty DESC LIMIT 15");
$supplied->execute([$sid]);
$supplied = $supplied->fetchAll();

$pageTitle = 'Transaction History';
$pageIcon = 'fa-clock-rotate-left';
include __DIR__ . '/_layout_top.php';
?>
<div class="row g-3 mb-4">
    <div class="col-md-6"><div class="card"><div class="card-body d-flex align-items-center gap-3"><span class="icon-bubble"><i class="fas fa-file-circle-check"></i></span><div><div class="metric-label">Completed orders</div><div class="metric-value"><?php echo (int)$sum['c']; ?></div></div></div></div></div>
    <div class="col-md-6"><div class="card"><div class="card-body d-flex align-items-center gap-3"><span class="icon-bubble"><i class="fas fa-peso-sign"></i></span><div><div class="metric-label">Total value supplied</div><div class="metric-value"><?php echo h(sp_money($sum['t'])); ?></div></div></div></div></div>
</div>
<div class="row g-4">
<div class="col-lg-8"><div class="card"><div class="card-header"><h5 class="mb-0">Previous orders</h5></div><div class="table-responsive"><table class="table table-hover align-middle mb-0">
    <thead><tr><th>PO number</th><th>Issued</th><th class="text-end">Total</th><th>Status</th><th>Payment</th><th></th></tr></thead><tbody>
    <?php if (!$done): ?><tr><td colspan="6" class="text-center text-muted py-4">No completed transactions yet.</td></tr><?php endif; ?>
    <?php foreach ($done as $p): $i = $inv[(int)$p['id']] ?? null; ?>
    <tr><td><strong><?php echo h($p['po_number']); ?></strong></td><td><?php echo h(sp_fmt_date($p['sent_at'])); ?></td><td class="text-end"><?php echo h(sp_money($p['grand_total'])); ?></td><td><?php echo sp_stage_badge($p); ?></td>
        <td><?php echo $i ? ((int)$i['paid'] ? '<span class="badge bg-success">Paid</span>' : '<span class="badge bg-warning text-dark">Invoiced</span>') : '<span class="text-muted">—</span>'; ?></td>
        <td class="text-end"><a class="btn btn-sm btn-outline-primary" href="order.php?id=<?php echo (int)$p['id']; ?>">Open</a></td></tr>
    <?php endforeach; ?>
    </tbody></table></div></div></div>
<div class="col-lg-4"><div class="card"><div class="card-header"><h5 class="mb-0">Items you have supplied</h5></div><div class="card-body">
    <?php if (!$supplied): ?><div class="text-muted small">Nothing received yet.</div><?php endif; ?>
    <?php foreach ($supplied as $s): ?><div class="soft-row"><span class="small fw-semibold"><?php echo h($s['item_description']); ?></span><span class="ms-auto small text-muted"><?php echo (int)$s['qty']; ?> pcs · <?php echo (int)$s['pos']; ?> PO</span></div><?php endforeach; ?>
</div></div></div>
</div>
<?php include __DIR__ . '/_layout_bottom.php';
