<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/supplier_portal.php';
verify_csrf();
$db = getDB();
$sup = sp_require_supplier($db);
$uid = (int)$_SESSION['user_id'];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (($_POST['action'] ?? '') === 'mark_all') $db->prepare("UPDATE notifications SET is_read=1 WHERE user_id=?")->execute([$uid]);
    elseif (($_POST['action'] ?? '') === 'mark_one') $db->prepare("UPDATE notifications SET is_read=1 WHERE id=? AND user_id=?")->execute([(int)($_POST['id'] ?? 0), $uid]);
    header('Location: notifications.php');
    exit();
}
$st = $db->prepare("SELECT id, title, message, link, is_read, created_at FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 100");
$st->execute([$uid]);
$rows = $st->fetchAll();
$pageTitle = 'Notifications';
$pageIcon = 'fa-bell';
$pageActions = '<form method="POST">' . csrf_field() . '<input type="hidden" name="action" value="mark_all"><button class="btn btn-outline-secondary"><i class="fas fa-check-double me-1"></i> Mark all as read</button></form>';
include __DIR__ . '/_layout_top.php';
?>
<div class="card"><div class="card-body">
    <?php if (!$rows): ?><div class="text-center text-muted py-4"><i class="fas fa-bell-slash fa-2x mb-2 d-block"></i>No notifications yet.</div><?php endif; ?>
    <?php foreach ($rows as $n): ?>
    <div class="soft-row">
        <div class="small flex-grow-1"><?php if (!$n['is_read']): ?><i class="fas fa-circle text-primary me-1" style="font-size:.5rem"></i><?php endif; ?><strong><?php echo h($n['title']); ?></strong>
            <div class="text-muted"><?php echo h($n['message']); ?></div><div class="text-muted" style="font-size:.72rem"><?php echo h(date('M d, Y H:i', strtotime($n['created_at']))); ?></div></div>
        <?php if ($n['link']): ?><a class="btn btn-sm btn-outline-primary" href="<?php echo h($n['link']); ?>">Open</a><?php endif; ?>
        <?php if (!$n['is_read']): ?><form method="POST"><?php echo csrf_field(); ?><input type="hidden" name="action" value="mark_one"><input type="hidden" name="id" value="<?php echo (int)$n['id']; ?>"><button class="btn btn-sm btn-outline-secondary" title="Mark as read"><i class="fas fa-check"></i></button></form><?php endif; ?>
    </div>
    <?php endforeach; ?>
</div></div>
<?php include __DIR__ . '/_layout_bottom.php';
