<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/supplier_portal.php';
verify_csrf();
$db = getDB();
$sup = sp_require_supplier($db);
$sid = (int)$sup['id'];
$f = $_GET['f'] ?? 'all';
if (!in_array($f, ['all', 'open', 'submitted', 'closed'], true)) $f = 'all';

$st = $db->prepare("SELECT r.id, r.rfq_number, r.title, r.status AS rfq_status, r.submission_deadline, rs.status AS invite_status,
        q.id AS quotation_id, q.status AS q_status, q.total_amount, q.revision_no, q.submitted_at, q.updated_at
    FROM rfq_suppliers rs JOIN rfqs r ON r.id=rs.rfq_id
    LEFT JOIN quotations q ON q.id=(SELECT MAX(id) FROM quotations WHERE rfq_id=r.id AND supplier_id=rs.supplier_id)
    WHERE rs.supplier_id=? AND r.status<>'draft' ORDER BY r.created_at DESC LIMIT 200");
$st->execute([$sid]);
$rows = [];
foreach ($st->fetchAll() as $r) {
    $open = sp_rfq_open(['status' => $r['rfq_status'], 'submission_deadline' => $r['submission_deadline']]);
    if ($r['quotation_id']) {
        if ($r['rfq_status'] === 'awarded' && $r['q_status'] === 'accepted') { $label = 'Selected'; $cls = 'success'; }
        elseif ($r['q_status'] === 'rejected') { $label = 'Not selected'; $cls = 'secondary'; }
        elseif ($open) { $label = 'Submitted' . ((int)$r['revision_no'] > 0 ? ' (rev ' . (int)$r['revision_no'] . ')' : ''); $cls = 'info'; }
        else { $label = 'Under evaluation'; $cls = 'primary'; }
    } else {
        if ($open) { $label = 'Awaiting your quotation'; $cls = 'warning'; } else { $label = 'Closed - not submitted'; $cls = 'secondary'; }
    }
    $r['label'] = $label; $r['cls'] = $cls; $r['open'] = $open;
    if ($f === 'open' && !($open && !$r['quotation_id'])) continue;
    if ($f === 'submitted' && !$r['quotation_id']) continue;
    if ($f === 'closed' && $open) continue;
    $rows[] = $r;
}

$pageTitle = 'RFQ & Quotations';
$pageIcon = 'fa-file-invoice-dollar';
include __DIR__ . '/_layout_top.php';
$tabs = ['all' => 'All', 'open' => 'Awaiting my quotation', 'submitted' => 'Submitted', 'closed' => 'Closed'];
?>
<div class="card mb-3"><div class="card-body d-flex flex-wrap gap-2"><?php foreach ($tabs as $k => $l): ?><a class="btn btn-sm <?php echo $k === $f ? 'btn-primary' : 'btn-outline-secondary'; ?>" href="rfqs.php?f=<?php echo $k; ?>"><?php echo h($l); ?></a><?php endforeach; ?></div></div>
<div class="card"><div class="table-responsive"><table class="table table-hover align-middle mb-0">
    <thead><tr><th>RFQ</th><th>Title</th><th>Deadline</th><th>Your quotation</th><th class="text-end">Quoted total</th><th>Status</th><th></th></tr></thead><tbody>
    <?php if (!$rows): ?><tr><td colspan="7" class="text-center text-muted py-4">No requests for quotation found.</td></tr><?php endif; ?>
    <?php foreach ($rows as $r): ?>
    <tr><td><strong><?php echo h($r['rfq_number']); ?></strong></td><td><?php echo h($r['title'] ?: '—'); ?></td>
        <td><?php echo $r['submission_deadline'] ? h(date('M d, Y H:i', strtotime($r['submission_deadline']))) : 'No deadline'; ?></td>
        <td class="small"><?php echo $r['quotation_id'] ? h(date('M d, Y', strtotime($r['updated_at'] ?: $r['submitted_at']))) : '—'; ?></td>
        <td class="text-end"><?php echo $r['quotation_id'] ? h(sp_money($r['total_amount'])) : '—'; ?></td>
        <td><span class="badge bg-<?php echo $r['cls']; ?><?php echo in_array($r['cls'], ['warning', 'info'], true) ? ' text-dark' : ''; ?>"><?php echo h($r['label']); ?></span></td>
        <td class="text-end"><a class="btn btn-sm btn-outline-primary" href="rfq.php?id=<?php echo (int)$r['id']; ?>"><?php echo $r['open'] ? ($r['quotation_id'] ? 'Revise' : 'Quote') : 'View'; ?></a></td></tr>
    <?php endforeach; ?>
    </tbody></table></div></div>
<?php include __DIR__ . '/_layout_bottom.php';
