<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/supplier_portal.php';
verify_csrf();
$db = getDB();
$sup = sp_require_supplier($db);
$sid = (int)$sup['id'];
$success_message = null;
$error_message = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'upload') {
    try {
        list($kind, $rid) = array_pad(explode(':', (string)($_POST['related'] ?? ''), 2), 2, null);
        $rid = (int)$rid;
        $type = $_POST['doc_type'] ?? 'other';
        $allowedTypes = $kind === 'rfq' ? ['quotation_attachment', 'certificate', 'other'] : ['delivery_receipt', 'packing_list', 'invoice', 'certificate', 'other'];
        if (!in_array($type, $allowedTypes, true)) throw new Exception('Choose a valid document type.');
        $meta = ['supplier_id' => $sid, 'doc_type' => $type, 'by' => 'supplier', 'note' => trim($_POST['note'] ?? '')];
        if ($kind === 'po') {
            $po = sp_load_po($db, $rid, $sid);
            if (!$po) throw new Exception('Choose one of your purchase orders.');
            $meta['po_id'] = $rid;
        } elseif ($kind === 'rfq') {
            $chk = $db->prepare("SELECT COUNT(*) FROM rfq_suppliers rs JOIN rfqs r ON r.id=rs.rfq_id WHERE rs.supplier_id=? AND r.id=? AND r.status<>'draft'");
            $chk->execute([$sid, $rid]);
            if (!(int)$chk->fetchColumn()) throw new Exception('Choose one of your requests for quotation.');
            $meta['rfq_id'] = $rid;
        } else {
            throw new Exception('Choose what the document relates to.');
        }
        $docId = sp_store_upload($db, $_FILES['file'] ?? [], $meta);
        if ($kind === 'po') {
            sp_log_event($db, $rid, $sid, 'supplier', 'document_uploaded', sp_doc_types()[$type] . ' uploaded');
            sp_notify_staff($db, 'Supplier document uploaded', $sup['company_name'] . ' uploaded a ' . strtolower(sp_doc_types()[$type]) . ' for ' . $po['po_number'] . '.', 'modules/procurement/po_view.php?id=' . $rid);
        }
        logActivity("Supplier portal: {$sup['company_name']} uploaded document #$docId ($type)");
        header('Location: documents.php?ok=' . urlencode('Document uploaded.'));
        exit();
    } catch (Throwable $e) {
        $error_message = $e->getMessage();
    }
}

$pos = $db->prepare("SELECT po.id, po.po_number FROM purchase_orders po WHERE " . sp_visible_sql() . " ORDER BY po.id DESC LIMIT 100");
$pos->execute([$sid]);
$pos = $pos->fetchAll();
$rfqs = $db->prepare("SELECT r.id, r.rfq_number FROM rfq_suppliers rs JOIN rfqs r ON r.id=rs.rfq_id WHERE rs.supplier_id=? AND r.status<>'draft' ORDER BY r.id DESC LIMIT 100");
$rfqs->execute([$sid]);
$rfqs = $rfqs->fetchAll();
$docs = $db->prepare("SELECT d.*, po.po_number, r.rfq_number FROM supplier_documents d LEFT JOIN purchase_orders po ON po.id=d.po_id LEFT JOIN rfqs r ON r.id=d.rfq_id WHERE d.supplier_id=? ORDER BY d.id DESC LIMIT 200");
$docs->execute([$sid]);
$docs = $docs->fetchAll();

$pageTitle = 'Documents';
$pageIcon = 'fa-folder-open';
include __DIR__ . '/_layout_top.php';
?>
<div class="card mb-4 pos-form-center"><div class="card-header"><h5 class="mb-0"><i class="fas fa-cloud-arrow-up me-2 text-primary"></i> Upload a document</h5></div><div class="card-body">
<form method="POST" enctype="multipart/form-data" class="row g-3"><?php echo csrf_field(); ?><input type="hidden" name="action" value="upload">
    <div class="col-md-6"><label class="form-label">Related to *</label><select name="related" class="form-select" required><option value="">Choose…</option>
        <optgroup label="Purchase orders"><?php foreach ($pos as $p): ?><option value="po:<?php echo (int)$p['id']; ?>"><?php echo h($p['po_number']); ?></option><?php endforeach; ?></optgroup>
        <optgroup label="Requests for quotation"><?php foreach ($rfqs as $r): ?><option value="rfq:<?php echo (int)$r['id']; ?>"><?php echo h($r['rfq_number']); ?></option><?php endforeach; ?></optgroup></select></div>
    <div class="col-md-6"><label class="form-label">Document type *</label><select name="doc_type" class="form-select"><?php foreach (sp_doc_types() as $k => $l): if ($k === 'discrepancy_evidence') continue; ?><option value="<?php echo $k; ?>"><?php echo h($l); ?></option><?php endforeach; ?></select></div>
    <div class="col-md-6"><label class="form-label">File *</label><input type="file" name="file" class="form-control" accept=".pdf,.jpg,.jpeg,.png,.doc,.docx,.xls,.xlsx" required><div class="form-text">PDF, image, Word or Excel, up to 5 MB.</div></div>
    <div class="col-md-6"><label class="form-label">Note</label><input type="text" name="note" maxlength="255" class="form-control"></div>
    <div class="col-12 text-center"><button class="btn btn-primary"><i class="fas fa-upload me-1"></i> Upload</button></div>
</form></div></div>

<div class="card"><div class="card-header"><h5 class="mb-0">Your documents</h5></div><div class="table-responsive"><table class="table table-hover align-middle mb-0">
    <thead><tr><th>File</th><th>Type</th><th>Related to</th><th>By</th><th>Uploaded</th><th>Size</th><th></th></tr></thead><tbody>
    <?php if (!$docs): ?><tr><td colspan="7" class="text-center text-muted py-4">No documents yet.</td></tr><?php endif; ?>
    <?php foreach ($docs as $d): ?>
    <tr><td><strong><?php echo h($d['original_name']); ?></strong><?php if ($d['note']): ?><div class="small text-muted"><?php echo h($d['note']); ?></div><?php endif; ?></td>
        <td><?php echo h(sp_doc_types()[$d['doc_type']] ?? $d['doc_type']); ?></td>
        <td><?php echo h($d['po_number'] ?: ($d['rfq_number'] ?: '—')); ?></td>
        <td><span class="badge bg-<?php echo $d['uploaded_by_type'] === 'supplier' ? 'primary' : 'secondary'; ?>"><?php echo $d['uploaded_by_type'] === 'supplier' ? 'You' : 'Procurement'; ?></span></td>
        <td class="small"><?php echo h(date('M d, Y', strtotime($d['created_at']))); ?></td><td class="small"><?php echo h(sp_fmt_size((int)$d['size_bytes'])); ?></td>
        <td class="text-end"><a class="btn btn-sm btn-outline-primary" href="download.php?id=<?php echo (int)$d['id']; ?>"><i class="fas fa-download"></i></a></td></tr>
    <?php endforeach; ?>
    </tbody></table></div></div>
<?php include __DIR__ . '/_layout_bottom.php';
