<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/payroll.php';
require_permission('view_payroll');
verify_csrf();
$db = getDB();
payroll_ensure_schema($db);
$success_message = null;
$error_message = null;
$canEdit = hasPermission('manage_payroll_setup');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $empId = (int)($_POST['employee_id'] ?? 0);
    try {
        require_permission('manage_payroll_setup');
        if ($action === 'save_salary') {
            $type = $_POST['salary_type'] ?? '';
            $sched = $_POST['pay_schedule'] ?? '';
            $basic = $_POST['basic_salary'] ?? '';
            $eff = $_POST['effective_from'] ?? '';
            if (!in_array($type, ['monthly', 'daily', 'hourly'], true)) throw new Exception('Choose a valid salary type.');
            if (!in_array($sched, ['weekly', 'semi_monthly', 'monthly'], true)) throw new Exception('Choose a valid pay schedule.');
            if (!valid_money($basic, false)) throw new Exception('Basic salary must be more than 0 with at most 2 decimals.');
            if (!payroll_is_date($eff)) throw new Exception('Effective date is not valid.');
            $e = $db->prepare("SELECT id, first_name, last_name FROM employees WHERE id=?");
            $e->execute([$empId]);
            $emp = $e->fetch();
            if (!$emp) throw new Exception('Employee not found.');
            $prev = payroll_current_salary($db, $empId, $eff);
            $db->prepare("INSERT INTO employee_salary(employee_id,salary_type,basic_salary,pay_schedule,effective_from,applies_sss,applies_philhealth,applies_pagibig,applies_tax,ot_eligible,notes,created_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)")
               ->execute([$empId, $type, (float)$basic, $sched, $eff, isset($_POST['applies_sss']) ? 1 : 0, isset($_POST['applies_philhealth']) ? 1 : 0, isset($_POST['applies_pagibig']) ? 1 : 0, isset($_POST['applies_tax']) ? 1 : 0, isset($_POST['ot_eligible']) ? 1 : 0, substr(trim($_POST['notes'] ?? ''), 0, 255), $_SESSION['user_id']]);
            logActivity("Payroll: salary setup for {$emp['first_name']} {$emp['last_name']} (employee #$empId) effective $eff: $type " . payroll_money($basic) . " $sched" . ($prev ? " [was {$prev['salary_type']} " . payroll_money($prev['basic_salary']) . " {$prev['pay_schedule']}]" : ' [first setup]'));
            payroll_redirect('salary.php', 'Salary arrangement saved.', null, ['employee' => $empId]);
        } elseif ($action === 'add_recurring') {
            $kind = $_POST['kind'] ?? '';
            $name = trim($_POST['item_name'] ?? '');
            $amt = $_POST['amount'] ?? '';
            $from = $_POST['effective_from'] ?? '';
            $to = trim($_POST['effective_to'] ?? '');
            $doc = trim($_POST['documentation'] ?? '');
            if (!in_array($kind, ['earning', 'deduction'], true)) throw new Exception('Choose allowance or deduction.');
            if ($name === '' || strlen($name) > 80) throw new Exception('Name is required (max 80 characters).');
            if (!valid_money($amt, false)) throw new Exception('Amount must be more than 0 with at most 2 decimals.');
            if (!payroll_is_date($from)) throw new Exception('Start date is not valid.');
            if ($to !== '' && (!payroll_is_date($to) || $to < $from)) throw new Exception('End date must be a valid date on/after the start date.');
            if ($kind === 'deduction' && strlen($doc) < 5) throw new Exception('Authorized deductions need documentation (who authorized it / basis).');
            $db->prepare("INSERT INTO employee_recurring_items(employee_id,kind,item_name,amount,effective_from,effective_to,documentation,created_by) VALUES(?,?,?,?,?,?,?,?)")
               ->execute([$empId, $kind, $name, (float)$amt, $from, $to !== '' ? $to : null, substr($doc, 0, 255), $_SESSION['user_id']]);
            logActivity("Payroll: added recurring $kind '$name' " . payroll_money($amt) . " for employee #$empId");
            payroll_redirect('salary.php', 'Item added.', null, ['employee' => $empId]);
        } elseif ($action === 'deactivate_recurring') {
            $rid = (int)($_POST['recurring_id'] ?? 0);
            $db->prepare("UPDATE employee_recurring_items SET is_active=0 WHERE id=? AND employee_id=?")->execute([$rid, $empId]);
            logActivity("Payroll: deactivated recurring item #$rid for employee #$empId");
            payroll_redirect('salary.php', 'Item deactivated.', null, ['employee' => $empId]);
        } elseif ($action === 'import_salaries') {
            $rows = $db->query("SELECT id, hire_date, salary FROM employees WHERE status<>'terminated' AND salary IS NOT NULL AND salary>0 AND id NOT IN (SELECT employee_id FROM employee_salary)")->fetchAll();
            $ins = $db->prepare("INSERT INTO employee_salary(employee_id,salary_type,basic_salary,pay_schedule,effective_from,notes,created_by) VALUES(?, 'monthly', ?, 'semi_monthly', ?, 'Imported from employee profile (assumed monthly salary)', ?)");
            foreach ($rows as $r) $ins->execute([$r['id'], $r['salary'], $r['hire_date'] ?: date('Y-m-d'), $_SESSION['user_id']]);
            logActivity('Payroll: imported ' . count($rows) . ' salary arrangement(s) from employee profiles');
            payroll_redirect('salary.php', count($rows) . ' employee(s) imported as monthly / semi-monthly. Please review them.');
        }
    } catch (Throwable $e) {
        $error_message = $e->getMessage();
    }
}

$focus = (int)($_GET['employee'] ?? 0);
$pageTitle = 'Employee Salary Setup';
$pageIcon = 'fa-user-gear';
$pageActions = '';
if ($canEdit && !$focus) {
    $pageActions = '<form method="POST" class="d-inline" data-confirm="Create a monthly / semi-monthly salary setup from the salary in each employee profile (only for employees with no setup yet)?">' . csrf_field() . '<input type="hidden" name="action" value="import_salaries"><button class="btn btn-outline-primary"><i class="fas fa-file-import me-1"></i> Import from employee profiles</button></form>';
}
if ($focus) $pageActions = '<a class="btn btn-outline-secondary" href="salary.php"><i class="fas fa-arrow-left me-1"></i> Back to list</a>';
include __DIR__ . '/_layout_top.php';

if (!$focus):
    $rows = $db->query("SELECT e.id, e.employee_id AS emp_code, e.first_name, e.last_name, e.position, e.department, e.salary AS profile_salary, e.user_id,
            s.salary_type, s.basic_salary, s.pay_schedule, s.effective_from,
            (SELECT COUNT(*) FROM employee_recurring_items ri WHERE ri.employee_id=e.id AND ri.is_active=1) AS item_count
        FROM employees e
        LEFT JOIN employee_salary s ON s.id=(SELECT id FROM employee_salary WHERE employee_id=e.id AND effective_from<=CURDATE() ORDER BY effective_from DESC, id DESC LIMIT 1)
        WHERE e.status<>'terminated' ORDER BY e.last_name, e.first_name")->fetchAll();
?>
<div class="card shadow-sm"><div class="table-responsive">
<table class="table table-hover align-middle mb-0">
    <thead class="table-light"><tr><th>Employee</th><th>Position</th><th>Salary type</th><th class="text-end">Basic</th><th>Schedule</th><th>Effective</th><th>Allow./Deduct.</th><th>Attendance link</th><th></th></tr></thead>
    <tbody>
    <?php if (!$rows): ?><tr><td colspan="9" class="text-center text-muted py-4">No employees found.</td></tr><?php endif; ?>
    <?php foreach ($rows as $r): ?>
        <tr>
            <td><strong><?php echo h($r['first_name'] . ' ' . $r['last_name']); ?></strong><div class="small text-muted"><?php echo h($r['emp_code']); ?></div></td>
            <td><?php echo h($r['position'] ?: '—'); ?></td>
            <?php if ($r['salary_type']): ?>
                <td><?php echo h(ucfirst($r['salary_type'])); ?></td>
                <td class="text-end"><?php echo h(payroll_money($r['basic_salary'])); ?></td>
                <td><?php echo h(payroll_schedule_label($r['pay_schedule'])); ?></td>
                <td><?php echo h(payroll_fmt_date($r['effective_from'])); ?></td>
            <?php else: ?>
                <td colspan="4"><span class="badge bg-danger">No salary setup</span><?php if ($r['profile_salary']): ?> <span class="small text-muted">(profile shows <?php echo h(payroll_money($r['profile_salary'])); ?>)</span><?php endif; ?></td>
            <?php endif; ?>
            <td><?php echo (int)$r['item_count']; ?></td>
            <td><?php echo $r['user_id'] ? '<span class="badge bg-success">Linked</span>' : '<span class="badge bg-warning text-dark" title="No user account: attendance cannot be read">No account</span>'; ?></td>
            <td class="text-end"><a class="btn btn-sm btn-outline-primary" href="salary.php?employee=<?php echo (int)$r['id']; ?>"><i class="fas fa-pen me-1"></i> <?php echo $canEdit ? 'Manage' : 'View'; ?></a></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table></div></div>
<?php
else:
    $e = $db->prepare("SELECT * FROM employees WHERE id=?");
    $e->execute([$focus]);
    $emp = $e->fetch();
    if (!$emp) { echo '<div class="alert alert-danger">Employee not found.</div>'; include __DIR__ . '/_layout_bottom.php'; exit(); }
    $cur = payroll_current_salary($db, $focus, date('Y-m-d'));
    $hist = $db->prepare("SELECT s.*, u.full_name AS who FROM employee_salary s LEFT JOIN users u ON u.id=s.created_by WHERE s.employee_id=? ORDER BY s.effective_from DESC, s.id DESC");
    $hist->execute([$focus]);
    $hist = $hist->fetchAll();
    $items = $db->prepare("SELECT * FROM employee_recurring_items WHERE employee_id=? ORDER BY is_active DESC, id DESC");
    $items->execute([$focus]);
    $items = $items->fetchAll();
    $v = $cur ?: ['salary_type' => 'monthly', 'basic_salary' => $emp['salary'] ?: '', 'pay_schedule' => 'semi_monthly', 'applies_sss' => 1, 'applies_philhealth' => 1, 'applies_pagibig' => 1, 'applies_tax' => 1, 'ot_eligible' => 1, 'notes' => ''];
?>
<div class="mb-3"><h5 class="mb-0"><?php echo h($emp['first_name'] . ' ' . $emp['last_name']); ?></h5>
<div class="text-muted small"><?php echo h($emp['employee_id']); ?> · <?php echo h($emp['position'] ?: 'No position'); ?> · <?php echo h($emp['department'] ?: 'No department'); ?></div></div>
<div class="row g-4">
  <div class="col-lg-6">
    <div class="card shadow-sm"><div class="card-header bg-white"><strong>Salary arrangement</strong> <span class="text-muted small">— saving creates a new effective-dated record; history is kept</span></div>
    <div class="card-body">
    <?php if ($canEdit): ?>
      <form method="POST" data-confirm="Save this salary arrangement?">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="save_salary"><input type="hidden" name="employee_id" value="<?php echo $focus; ?>">
        <div class="row g-3">
          <div class="col-md-6"><label class="form-label">Salary type *</label><select name="salary_type" class="form-select"><?php foreach (['monthly' => 'Monthly (fixed monthly salary)', 'daily' => 'Daily rate', 'hourly' => 'Hourly rate'] as $k => $l): ?><option value="<?php echo $k; ?>"<?php echo $v['salary_type'] === $k ? ' selected' : ''; ?>><?php echo $l; ?></option><?php endforeach; ?></select></div>
          <div class="col-md-6"><label class="form-label">Basic salary / rate (₱) *</label><input type="number" step="0.01" min="0.01" name="basic_salary" class="form-control" value="<?php echo h($v['basic_salary']); ?>" required></div>
          <div class="col-md-6"><label class="form-label">Pay schedule *</label><select name="pay_schedule" class="form-select"><?php foreach (['semi_monthly' => 'Semi-monthly', 'monthly' => 'Monthly', 'weekly' => 'Weekly'] as $k => $l): ?><option value="<?php echo $k; ?>"<?php echo $v['pay_schedule'] === $k ? ' selected' : ''; ?>><?php echo $l; ?></option><?php endforeach; ?></select></div>
          <div class="col-md-6"><label class="form-label">Effective from *</label><input type="date" name="effective_from" class="form-control" value="<?php echo h(date('Y-m-d')); ?>" required></div>
          <div class="col-12"><label class="form-label d-block">Applicable deductions &amp; eligibility</label>
            <?php foreach (['applies_sss' => 'SSS', 'applies_philhealth' => 'PhilHealth', 'applies_pagibig' => 'Pag-IBIG', 'applies_tax' => 'Withholding tax', 'ot_eligible' => 'Overtime eligible'] as $k => $l): ?>
              <div class="form-check form-check-inline"><input class="form-check-input" type="checkbox" name="<?php echo $k; ?>" id="<?php echo $k; ?>"<?php echo !empty($v[$k]) ? ' checked' : ''; ?>><label class="form-check-label" for="<?php echo $k; ?>"><?php echo $l; ?></label></div>
            <?php endforeach; ?></div>
          <div class="col-12"><label class="form-label">Notes</label><input type="text" name="notes" maxlength="255" class="form-control" value="<?php echo h($v['notes'] ?? ''); ?>"></div>
        </div>
        <button class="btn btn-primary mt-3"><i class="fas fa-save me-1"></i> Save salary arrangement</button>
      </form>
    <?php else: ?><p class="text-muted mb-0">You can view but not change salary arrangements.</p><?php endif; ?>
    </div></div>

    <div class="card shadow-sm mt-4"><div class="card-header bg-white"><strong>Salary history</strong></div>
    <div class="table-responsive"><table class="table table-sm mb-0"><thead class="table-light"><tr><th>Effective</th><th>Type</th><th class="text-end">Basic</th><th>Schedule</th><th>Set by</th></tr></thead><tbody>
    <?php if (!$hist): ?><tr><td colspan="5" class="text-muted text-center">No salary history.</td></tr><?php endif; ?>
    <?php foreach ($hist as $h1): ?><tr><td><?php echo h(payroll_fmt_date($h1['effective_from'])); ?></td><td><?php echo h(ucfirst($h1['salary_type'])); ?></td><td class="text-end"><?php echo h(payroll_money($h1['basic_salary'])); ?></td><td><?php echo h(payroll_schedule_label($h1['pay_schedule'])); ?></td><td><?php echo h($h1['who'] ?: '—'); ?></td></tr><?php endforeach; ?>
    </tbody></table></div></div>
  </div>

  <div class="col-lg-6">
    <div class="card shadow-sm"><div class="card-header bg-white"><strong>Allowances &amp; other authorized deductions</strong> <span class="text-muted small">— amount per payroll period</span></div>
    <div class="card-body">
    <?php if ($canEdit): ?>
      <form method="POST" class="row g-2 mb-3">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="add_recurring"><input type="hidden" name="employee_id" value="<?php echo $focus; ?>">
        <div class="col-md-4"><select name="kind" class="form-select"><option value="earning">Allowance (earning)</option><option value="deduction">Authorized deduction</option></select></div>
        <div class="col-md-5"><input type="text" name="item_name" class="form-control" maxlength="80" placeholder="e.g. Meal allowance" required></div>
        <div class="col-md-3"><input type="number" step="0.01" min="0.01" name="amount" class="form-control" placeholder="₱ / period" required></div>
        <div class="col-md-4"><label class="form-label small mb-0">From</label><input type="date" name="effective_from" class="form-control" value="<?php echo h(date('Y-m-d')); ?>" required></div>
        <div class="col-md-4"><label class="form-label small mb-0">Until (optional)</label><input type="date" name="effective_to" class="form-control"></div>
        <div class="col-md-4 d-flex align-items-end"><button class="btn btn-primary w-100">Add</button></div>
        <div class="col-12"><input type="text" name="documentation" class="form-control" maxlength="255" placeholder="Documentation / authorization basis (required for deductions)"></div>
      </form>
    <?php endif; ?>
    <div class="table-responsive"><table class="table table-sm mb-0"><thead class="table-light"><tr><th>Type</th><th>Name</th><th class="text-end">Amount</th><th>Period</th><th></th></tr></thead><tbody>
    <?php if (!$items): ?><tr><td colspan="5" class="text-muted text-center">None.</td></tr><?php endif; ?>
    <?php foreach ($items as $i): ?>
      <tr class="<?php echo $i['is_active'] ? '' : 'text-muted'; ?>">
        <td><?php echo $i['kind'] === 'earning' ? '<span class="badge bg-success">Allowance</span>' : '<span class="badge bg-danger">Deduction</span>'; ?></td>
        <td><?php echo h($i['item_name']); ?><?php if ($i['documentation']): ?><div class="small text-muted"><?php echo h($i['documentation']); ?></div><?php endif; ?></td>
        <td class="text-end"><?php echo h(payroll_money($i['amount'])); ?></td>
        <td class="small"><?php echo h(payroll_fmt_date($i['effective_from'])); ?> → <?php echo $i['effective_to'] ? h(payroll_fmt_date($i['effective_to'])) : 'ongoing'; ?></td>
        <td class="text-end"><?php if ($i['is_active'] && $canEdit): ?>
          <form method="POST" data-confirm="Deactivate this item? It will no longer apply to future payroll runs."><?php echo csrf_field(); ?><input type="hidden" name="action" value="deactivate_recurring"><input type="hidden" name="employee_id" value="<?php echo $focus; ?>"><input type="hidden" name="recurring_id" value="<?php echo (int)$i['id']; ?>"><button class="btn btn-sm btn-outline-danger">Deactivate</button></form>
        <?php elseif (!$i['is_active']): ?><span class="small">inactive</span><?php endif; ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody></table></div>
    </div></div>
  </div>
</div>
<?php
endif;
include __DIR__ . '/_layout_bottom.php';
