<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/payroll.php';
if (!isset($_SESSION['user_id'])) { header('Location: ' . BASE_PATH . 'login.php'); exit(); }
verify_csrf();
$db = getDB();
payroll_ensure_schema($db);
$success_message = null;
$error_message = null;
$isStaff = hasPermission('view_payroll');
$mine = !$isStaff || !empty($_GET['mine']);
$me = payroll_current_employee($db);
$S = payroll_settings($db);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'resend_email') {
    try {
        require_permission('process_payroll');
        $sid = (int)($_POST['slip_id'] ?? 0);
        $q = $db->prepare("SELECT s.*, p.period_name FROM payslips s JOIN payroll_runs r ON r.id=s.run_id JOIN payroll_periods p ON p.id=r.period_id WHERE s.id=? AND r.status IN ('finalized','partially_paid','paid')");
        $q->execute([$sid]);
        $s = $q->fetch();
        if (!$s) throw new Exception('Payslip not found or payroll is not finalized.');
        $c = payroll_employee_contact($db, (int)$s['employee_id']);
        if (!$c || !filter_var($c['email'] ?? '', FILTER_VALIDATE_EMAIL)) throw new Exception('This employee has no valid email address.');
        $lid = payroll_queue_email($db, $c['email'], 'Your payslip for ' . $s['period_name'] . ' is available',
            payroll_email_html('Your payslip is available', ['Hello ' . $c['first_name'] . ', your payslip for "' . $s['period_name'] . '" (ref. ' . $s['reference_no'] . ') is available.', 'For your privacy, payslip details are not included in this email.'], payroll_portal_url('modules/payroll/payslip.php?id=' . $sid), 'View my payslip'),
            'payslip_available', 'payslips', $sid);
        $ok = payroll_dispatch_email($db, $lid);
        logActivity("Payroll: resent payslip email for payslip #$sid - " . ($ok ? 'sent' : 'failed/queued'));
        if ($ok) payroll_redirect('payslips.php', 'Payslip email sent.');
        payroll_redirect('payslips.php', null, 'Email could not be sent now; it is queued in the Payroll Email Log for retry. Payroll and payment records were not affected.');
    } catch (Throwable $e) {
        $error_message = $e->getMessage();
    }
}

$run = (int)($_GET['run'] ?? 0);
$sql = "SELECT s.id, s.reference_no, s.revision, s.email_status, s.emailed_at, s.last_viewed_at, i.net_pay, i.payment_status, e.first_name, e.last_name, e.employee_id AS emp_code,
               p.period_name, p.pay_date, r.status AS run_status, r.id AS run_id
        FROM payslips s JOIN payroll_items i ON i.id=s.item_id JOIN employees e ON e.id=s.employee_id
        JOIN payroll_runs r ON r.id=s.run_id JOIN payroll_periods p ON p.id=r.period_id WHERE 1=1";
$params = [];
if ($mine) {
    $sql .= " AND s.employee_id=? AND r.status IN ('finalized','partially_paid','paid')";
    $params[] = $me ? (int)$me['id'] : 0;
} elseif ($run) {
    $sql .= " AND s.run_id=?";
    $params[] = $run;
}
$sql .= " ORDER BY p.pay_date DESC, e.last_name, e.first_name LIMIT 500";
$st = $db->prepare($sql);
$st->execute($params);
$rows = $st->fetchAll();

$pageTitle = $mine ? 'My Payslips' : 'All Payslips';
$pageIcon = 'fa-file-invoice-dollar';
$pageActions = ($isStaff && $mine) ? '<a class="btn btn-outline-secondary" href="payslips.php">View all payslips</a>' : ($isStaff ? '<a class="btn btn-outline-secondary" href="payslips.php?mine=1">My payslips</a>' : '');
include __DIR__ . '/_layout_top.php';
?>
<?php if ($mine && !$me): ?>
<div class="alert alert-info">Your user account is not linked to an employee record, so there are no payslips to show. Please contact HR.</div>
<?php endif; ?>
<div class="card shadow-sm"><div class="table-responsive"><table class="table table-hover align-middle mb-0">
<thead class="table-light"><tr><?php if (!$mine): ?><th>Employee</th><?php endif; ?><th>Period</th><th>Pay date</th><th>Reference</th><?php if (!$mine): ?><th class="text-end">Net</th><?php endif; ?><th>Payment</th><?php if (!$mine): ?><th>Email</th><?php endif; ?><th></th></tr></thead><tbody>
<?php if (!$rows): ?><tr><td colspan="8" class="text-center text-muted py-4">No payslips yet.</td></tr><?php endif; ?>
<?php foreach ($rows as $r): ?>
<tr>
    <?php if (!$mine): ?><td><strong><?php echo h($r['first_name'] . ' ' . $r['last_name']); ?></strong><div class="small text-muted"><?php echo h($r['emp_code']); ?></div></td><?php endif; ?>
    <td><?php echo h($r['period_name']); ?></td>
    <td><?php echo h(payroll_fmt_date($r['pay_date'])); ?></td>
    <td class="small"><?php echo h($r['reference_no']); ?><?php if ((int)$r['revision'] > 0): ?> <span class="badge bg-info text-dark">rev <?php echo (int)$r['revision']; ?></span><?php endif; ?></td>
    <?php if (!$mine): ?><td class="text-end"><?php echo h(payroll_money($r['net_pay'])); ?></td><?php endif; ?>
    <td><?php echo payroll_pay_badge($r['payment_status']); ?></td>
    <?php if (!$mine): ?><td><?php $c = ['sent' => 'success', 'failed' => 'danger', 'pending' => 'secondary', 'skipped' => 'light text-dark border']; echo '<span class="badge bg-' . ($c[$r['email_status']] ?? 'secondary') . '">' . h(ucfirst($r['email_status'])) . '</span>'; ?></td><?php endif; ?>
    <td class="text-end">
        <a class="btn btn-sm btn-outline-primary" href="payslip.php?id=<?php echo (int)$r['id']; ?>"><i class="fas fa-eye me-1"></i> View / Print</a>
        <?php if (!$mine && hasPermission('process_payroll') && in_array($r['run_status'], ['finalized', 'partially_paid', 'paid'], true)): ?>
        <form method="POST" class="d-inline" data-confirm="Send the payslip-available email to this employee again?"><?php echo csrf_field(); ?><input type="hidden" name="action" value="resend_email"><input type="hidden" name="slip_id" value="<?php echo (int)$r['id']; ?>"><button class="btn btn-sm btn-outline-secondary" title="Resend email"><i class="fas fa-envelope"></i></button></form>
        <?php endif; ?>
    </td>
</tr>
<?php endforeach; ?>
</tbody></table></div></div>
<?php include __DIR__ . '/_layout_bottom.php';
