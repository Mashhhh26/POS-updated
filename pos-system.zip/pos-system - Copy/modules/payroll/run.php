<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/payroll.php';
require_permission('view_payroll');
verify_csrf();
$db = getDB();
payroll_ensure_schema($db);
$success_message = null;
$error_message = null;

function run_load(PDO $db, int $id) {
    $q = $db->prepare("SELECT r.*, p.period_name, p.start_date, p.end_date, p.pay_date, p.pay_schedule, p.deadline_date, u.full_name AS preparer
        FROM payroll_runs r JOIN payroll_periods p ON p.id=r.period_id LEFT JOIN users u ON u.id=r.prepared_by WHERE r.id=?");
    $q->execute([$id]);
    return $q->fetch();
}
function run_item(PDO $db, int $runId, int $itemId) {
    $q = $db->prepare("SELECT i.*, e.first_name, e.last_name, e.employee_id AS emp_code, e.position, e.user_id FROM payroll_items i JOIN employees e ON e.id=i.employee_id WHERE i.id=? AND i.run_id=?");
    $q->execute([$itemId, $runId]);
    return $q->fetch();
}
function run_need(array $run, array $allowed, string $msg): void {
    if (!in_array($run['status'], $allowed, true)) throw new Exception($msg);
}
function run_notify_users(array $users, string $title, string $msg, int $runId): void {
    foreach ($users as $u) notify_user((int)$u['id'], $title, $msg, BASE_PATH . 'modules/payroll/run.php?id=' . $runId);
}

$runId = (int)($_POST['run_id'] ?? $_GET['id'] ?? 0);
$run = run_load($db, $runId);
if (!$run) payroll_redirect('periods.php', null, 'Payroll run not found.');
$S = payroll_settings($db);
$uid = (int)$_SESSION['user_id'];
$methods = ['bank_transfer' => 'Bank transfer', 'cash' => 'Cash', 'ewallet' => 'E-wallet', 'cheque' => 'Cheque', 'other' => 'Other'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $itemId = (int)($_POST['item_id'] ?? 0);
    $note = trim($_POST['note'] ?? '');
    $to = ['id' => $runId];
    try {
        switch ($action) {
            case 'collect':
                require_permission('process_payroll');
                run_need($run, ['draft'], 'Time records can only be collected while the payroll is a Draft.');
                $res = payroll_generate_items($db, $runId);
                $_SESSION['payroll_excluded_' . $runId] = $res['excluded'];
                payroll_log_approval($db, $runId, 'collect', 'draft', 'draft', "new {$res['created']}, refreshed {$res['refreshed']}, kept {$res['kept']}, excluded " . count($res['excluded']));
                logActivity("Payroll run #$runId: collected time records (new {$res['created']}, refreshed {$res['refreshed']}, excluded " . count($res['excluded']) . ')');
                payroll_redirect('run.php', "Time records collected: {$res['created']} new, {$res['refreshed']} refreshed, {$res['kept']} kept (already validated).", null, $to);

            case 'validate_item':
                require_permission('process_payroll');
                run_need($run, ['draft'], 'Records can only be validated while the payroll is a Draft.');
                $it = run_item($db, $runId, $itemId);
                if (!$it) throw new Exception('Employee record not found.');
                $abs = $_POST['absent_days'] ?? '';
                $late = $_POST['late_minutes'] ?? '';
                $ut = $_POST['undertime_minutes'] ?? '';
                $ot = $_POST['ot_hours'] ?? '';
                if (!is_numeric($abs) || (float)$abs < 0 || (float)$abs > (float)$it['scheduled_days'] || fmod((float)$abs * 2, 1.0) != 0.0) throw new Exception('Absent days must be between 0 and the scheduled days, in half-day steps.');
                if (!ctype_digit((string)$late) || (int)$late > 100000 || !ctype_digit((string)$ut) || (int)$ut > 100000) throw new Exception('Late and undertime minutes must be whole numbers (0 or more).');
                if (!is_numeric($ot) || (float)$ot < 0 || (float)$ot > 300) throw new Exception('Overtime hours must be between 0 and 300.');
                $db->prepare("UPDATE payroll_items SET absent_days=?, late_minutes=?, undertime_minutes=?, ot_hours=?, validated=1, validated_by=?, validated_at=NOW(), validation_note=?, calculated_at=NULL WHERE id=?")
                   ->execute([(float)$abs, (int)$late, (int)$ut, round((float)$ot, 2), $uid, substr($note, 0, 255), $itemId]);
                logActivity("Payroll run #$runId: validated {$it['first_name']} {$it['last_name']} (absent {$it['absent_days']}->$abs, late {$it['late_minutes']}->$late, undertime {$it['undertime_minutes']}->$ut, OT {$it['ot_hours']}->$ot)" . ($note ? " note: $note" : ''));
                payroll_redirect('run.php', 'Record validated. Recalculate payroll to apply it.', null, $to + ['item' => $itemId]);

            case 'confirm_all':
                require_permission('process_payroll');
                run_need($run, ['draft'], 'Only a Draft payroll can be validated.');
                $st = $db->prepare("UPDATE payroll_items SET validated=1, validated_by=?, validated_at=NOW(), calculated_at=NULL WHERE run_id=? AND validated=0 AND (issues IS NULL OR issues='')");
                $st->execute([$uid, $runId]);
                logActivity("Payroll run #$runId: confirmed " . $st->rowCount() . ' record(s) with no issues as detected');
                payroll_redirect('run.php', $st->rowCount() . ' record(s) without issues were confirmed. Records with issues must be reviewed one by one.', null, $to);

            case 'calculate':
                require_permission('process_payroll');
                run_need($run, ['draft'], 'Payroll can only be calculated while it is a Draft.');
                $unval = (int)$db->query("SELECT COUNT(*) FROM payroll_items WHERE run_id=$runId AND validated=0")->fetchColumn();
                $cnt = (int)$db->query("SELECT COUNT(*) FROM payroll_items WHERE run_id=$runId")->fetchColumn();
                if ($cnt === 0) throw new Exception('Collect time records first.');
                if ($unval > 0) throw new Exception("$unval record(s) are not validated yet. Validate all records before calculating.");
                $db->beginTransaction();
                foreach ($db->query("SELECT id FROM payroll_items WHERE run_id=$runId")->fetchAll(PDO::FETCH_COLUMN) as $iid) payroll_calculate_item($db, (int)$iid, $S);
                payroll_update_run_totals($db, $runId);
                payroll_log_approval($db, $runId, 'calculate', 'draft', 'draft', "$cnt employee(s) calculated");
                $db->commit();
                logActivity("Payroll run #$runId: calculated $cnt employee(s)");
                payroll_redirect('run.php', "Payroll calculated for $cnt employee(s).", null, $to);

            case 'add_line':
                require_permission('process_payroll');
                run_need($run, ['draft'], 'Lines can only be added while the payroll is a Draft.');
                $it = run_item($db, $runId, $itemId);
                if (!$it) throw new Exception('Employee record not found.');
                $kind = $_POST['kind'] ?? '';
                $ltype = $_POST['line_type'] ?? '';
                $desc = trim($_POST['description'] ?? '');
                $amt = $_POST['amount'] ?? '';
                if (!in_array($kind, ['earning', 'deduction'], true)) throw new Exception('Choose earning or deduction.');
                if ($kind === 'earning' && !in_array($ltype, ['holiday_pay', 'night_diff', 'bonus', 'other_earning'], true)) throw new Exception('Choose a valid earning type.');
                if ($kind === 'deduction') $ltype = 'other';
                if ($desc === '' || strlen($desc) > 150) throw new Exception('Description is required (max 150 characters).');
                if ($kind === 'deduction' && strlen($desc) < 5) throw new Exception('Deductions need a documented basis in the description.');
                if (!valid_money($amt, false)) throw new Exception('Amount must be more than 0 with at most 2 decimals.');
                if ($kind === 'earning') {
                    $db->prepare("INSERT INTO payroll_earnings(item_id,earning_type,description,amount,source,created_by) VALUES(?,?,?,?, 'manual', ?)")->execute([$itemId, $ltype, $desc, (float)$amt, $uid]);
                } else {
                    $db->prepare("INSERT INTO payroll_deductions(item_id,deduction_type,description,amount,source,created_by) VALUES(?,?,?,?, 'manual', ?)")->execute([$itemId, $ltype, $desc, (float)$amt, $uid]);
                }
                payroll_recalc_item_totals($db, $itemId);
                payroll_update_run_totals($db, $runId);
                logActivity("Payroll run #$runId: added manual $kind '$desc' " . payroll_money($amt) . " for {$it['first_name']} {$it['last_name']}");
                payroll_redirect('run.php', 'Line added.', null, $to + ['item' => $itemId]);

            case 'delete_line':
                require_permission('process_payroll');
                run_need($run, ['draft'], 'Lines can only be removed while the payroll is a Draft.');
                $kind = $_POST['kind'] ?? '';
                $lid = (int)($_POST['line_id'] ?? 0);
                if (!in_array($kind, ['earning', 'deduction'], true)) throw new Exception('Invalid line.');
                $tbl = $kind === 'earning' ? 'payroll_earnings' : 'payroll_deductions';
                $del = $db->prepare("DELETE l FROM $tbl l JOIN payroll_items i ON i.id=l.item_id WHERE l.id=? AND l.source='manual' AND i.run_id=?");
                $del->execute([$lid, $runId]);
                if ($del->rowCount() === 0) throw new Exception('Only manual lines can be removed.');
                payroll_recalc_item_totals($db, $itemId);
                payroll_update_run_totals($db, $runId);
                logActivity("Payroll run #$runId: removed manual $kind line #$lid");
                payroll_redirect('run.php', 'Line removed.', null, $to + ['item' => $itemId]);

            case 'submit_review':
                require_permission('process_payroll');
                run_need($run, ['draft'], 'Only a Draft payroll can be submitted.');
                $problems = payroll_submit_problems($db, $runId);
                if ($problems) throw new Exception(implode(' ', $problems));
                $db->prepare("UPDATE payroll_runs SET status='for_review', submitted_at=NOW(), prepared_by=? WHERE id=?")->execute([$uid, $runId]);
                payroll_log_approval($db, $runId, 'submit_review', 'draft', 'for_review', $note ?: null);
                logActivity("Payroll run #$runId: submitted for review");
                run_notify_users(payroll_users_with_permission($db, 'review_payroll', $uid), 'Payroll awaiting review', $run['period_name'] . ' payroll is ready for review.', $runId);
                payroll_redirect('run.php', 'Submitted for review.', null, $to);

            case 'review_pass':
                require_permission('review_payroll');
                run_need($run, ['for_review'], 'This payroll is not waiting for review.');
                $db->prepare("UPDATE payroll_runs SET status='for_approval', reviewed_by=?, reviewed_at=NOW(), review_note=? WHERE id=?")->execute([$uid, substr($note, 0, 500), $runId]);
                payroll_log_approval($db, $runId, 'review_pass', 'for_review', 'for_approval', $note ?: null);
                logActivity("Payroll run #$runId: review passed");
                run_notify_users(payroll_users_with_permission($db, 'approve_payroll', $uid), 'Payroll awaiting approval', $run['period_name'] . ' payroll passed review and needs approval.', $runId);
                payroll_redirect('run.php', 'Review passed. Waiting for approval.', null, $to);

            case 'review_return':
            case 'approve_return':
                if ($action === 'review_return') { require_permission('review_payroll'); run_need($run, ['for_review'], 'This payroll is not waiting for review.'); }
                else { require_permission('approve_payroll'); run_need($run, ['for_approval'], 'This payroll is not waiting for approval.'); }
                if (strlen($note) < 5) throw new Exception('Please explain what needs to be corrected (at least 5 characters).');
                $from = $run['status'];
                $db->prepare("UPDATE payroll_runs SET status='draft', submitted_at=NULL, review_note=?, reviewed_by=NULL, reviewed_at=NULL WHERE id=?")->execute([substr($note, 0, 500), $runId]);
                payroll_log_approval($db, $runId, $action, $from, 'draft', $note);
                logActivity("Payroll run #$runId: returned to draft - $note");
                if ($run['prepared_by']) notify_user((int)$run['prepared_by'], 'Payroll returned for correction', $run['period_name'] . ': ' . $note, BASE_PATH . 'modules/payroll/run.php?id=' . $runId);
                payroll_redirect('run.php', 'Payroll returned to Draft for correction.', null, $to);

            case 'approve':
                require_permission('approve_payroll');
                run_need($run, ['for_approval'], 'This payroll is not waiting for approval.');
                list($allowed, $why) = payroll_can_approve_run($db, $run);
                if (!$allowed) throw new Exception($why);
                $db->prepare("UPDATE payroll_runs SET status='approved', approved_by=?, approved_at=NOW(), approval_note=? WHERE id=?")->execute([$uid, substr($note, 0, 500), $runId]);
                payroll_log_approval($db, $runId, 'approve', 'for_approval', 'approved', trim(($note ?: '') . ' ' . $why));
                logActivity("Payroll run #$runId: approved" . ($why ? " ($why)" : ''));
                payroll_redirect('run.php', 'Payroll approved. It can now be finalized.', null, $to);

            case 'finalize':
                require_permission('approve_payroll');
                run_need($run, ['approved'], 'Only an Approved payroll can be finalized.');
                $problems = payroll_submit_problems($db, $runId);
                if ($problems) throw new Exception(implode(' ', $problems));
                $db->beginTransaction();
                $db->prepare("UPDATE payroll_runs SET status='finalized', finalized_by=?, finalized_at=NOW() WHERE id=? AND status='approved'")->execute([$uid, $runId]);
                payroll_update_run_totals($db, $runId);
                $made = payroll_generate_payslips($db, $runId);
                payroll_log_approval($db, $runId, 'finalize', 'approved', 'finalized', "Figures locked; $made payslip(s) generated");
                $db->commit();
                logActivity("Payroll run #$runId: FINALIZED (figures locked, $made payslips)");

                // Notifications + queued emails (never block finalization if SMTP is down)
                $queued = 0;
                if ($S['notify_finalized'] === '1') {
                    foreach (payroll_users_with_permission($db, 'view_payroll') as $u) {
                        if (filter_var($u['email'] ?? '', FILTER_VALIDATE_EMAIL)) {
                            payroll_queue_email($db, $u['email'], 'Payroll finalized: ' . $run['period_name'],
                                payroll_email_html('Payroll finalized', ['The payroll for "' . $run['period_name'] . '" has been approved and finalized. Next step: record the payments.'], payroll_portal_url('modules/payroll/run.php?id=' . $runId), 'Open the payroll run'),
                                'payroll_finalized', 'payroll_runs', $runId);
                            $queued++;
                        }
                    }
                }
                $slips = $db->prepare("SELECT s.id, s.reference_no, s.employee_id FROM payslips s WHERE s.run_id=?");
                $slips->execute([$runId]);
                foreach ($slips->fetchAll() as $s) {
                    $c = payroll_employee_contact($db, (int)$s['employee_id']);
                    if (!$c) continue;
                    if ($c['user_id']) notify_user((int)$c['user_id'], 'Payslip available', 'Your payslip for ' . $run['period_name'] . ' is ready.', BASE_PATH . 'modules/payroll/payslip.php?id=' . $s['id']);
                    if ($S['notify_payslip_available'] === '1' && filter_var($c['email'] ?? '', FILTER_VALIDATE_EMAIL)) {
                        payroll_queue_email($db, $c['email'], 'Your payslip for ' . $run['period_name'] . ' is available',
                            payroll_email_html('Your payslip is available', ['Hello ' . $c['first_name'] . ', your payslip for "' . $run['period_name'] . '" (ref. ' . $s['reference_no'] . ') is now available.', 'For your privacy, payslip details are not included in this email.'], payroll_portal_url('modules/payroll/payslip.php?id=' . $s['id']), 'View my payslip'),
                            'payslip_available', 'payslips', (int)$s['id']);
                        $queued++;
                    } else {
                        $db->prepare("UPDATE payslips SET email_status='skipped' WHERE id=?")->execute([$s['id']]);
                    }
                }
                $sendRes = $queued > 0 ? payroll_dispatch_pending($db, 100) : ['sent' => 0, 'failed' => 0];
                $msg = "Payroll finalized. $made payslip(s) generated.";
                if ($queued > 0) $msg .= " Emails: {$sendRes['sent']} sent" . ($sendRes['failed'] ? ", {$sendRes['failed']} failed/queued (see Payroll Email Log)" : '') . '.';
                payroll_redirect('run.php', $msg, null, $to);

            case 'record_payment':
                require_permission('record_payroll_payments');
                run_need($run, ['finalized', 'partially_paid'], 'Payments can only be recorded for a finalized payroll.');
                $it = run_item($db, $runId, $itemId);
                if (!$it) throw new Exception('Employee record not found.');
                $method = $_POST['payment_method'] ?? '';
                $pdate = $_POST['paid_date'] ?? '';
                $ref = trim($_POST['reference_no'] ?? '');
                if (!isset($methods[$method])) throw new Exception('Choose a payment method.');
                if (!payroll_is_date($pdate) || $pdate > date('Y-m-d')) throw new Exception('Payment date must be a valid date that is not in the future.');
                if (empty($_POST['confirmed'])) throw new Exception('Tick the confirmation: only record a payment after it has actually been made/confirmed.');
                if ($method !== 'cash' && $ref === '') throw new Exception('A reference number is required for non-cash payments.');
                if (!valid_money($_POST['amount'] ?? '', false)) throw new Exception('Amount must be more than 0 with at most 2 decimals.');
                $idem = preg_replace('/[^a-f0-9]/', '', (string)($_POST['idem_key'] ?? ''));
                $res = payroll_record_payment($db, $itemId, (float)$_POST['amount'], $method, $pdate, substr($ref, 0, 80) ?: null, substr($note, 0, 255) ?: null, $idem !== '' ? 'p' . $idem : null);
                if (!$res['ok']) throw new Exception($res['message']);
                if (!$res['duplicate']) {
                    logActivity("Payroll run #$runId: recorded payment " . payroll_money($_POST['amount']) . " ($method, ref " . ($ref ?: 'n/a') . ") for {$it['first_name']} {$it['last_name']}");
                    $c = payroll_employee_contact($db, (int)$it['employee_id']);
                    if ($c && $c['user_id']) notify_user((int)$c['user_id'], 'Payroll payment recorded', 'A payment for ' . $run['period_name'] . ' was recorded (' . $methods[$method] . ').', BASE_PATH . 'modules/payroll/payslips.php?mine=1');
                    if ($c && $S['notify_payment_recorded'] === '1' && filter_var($c['email'] ?? '', FILTER_VALIDATE_EMAIL)) {
                        $lid = payroll_queue_email($db, $c['email'], 'Payroll payment recorded: ' . $run['period_name'],
                            payroll_email_html('Payment recorded', ['Hello ' . $c['first_name'] . ', a payroll payment for "' . $run['period_name'] . '" was recorded on ' . payroll_fmt_date($pdate) . ' via ' . $methods[$method] . '.'], payroll_portal_url('modules/payroll/payslips.php?mine=1'), 'View my payslips'),
                            'payment_recorded', 'payroll_items', $itemId);
                        payroll_dispatch_email($db, $lid);
                    }
                }
                payroll_redirect('run.php', $res['duplicate'] ? 'That payment was already recorded (duplicate submission ignored).' : 'Payment recorded.', null, $to + ['item' => $itemId]);

            case 'record_payment_all':
                require_permission('record_payroll_payments');
                run_need($run, ['finalized', 'partially_paid'], 'Payments can only be recorded for a finalized payroll.');
                $method = $_POST['payment_method'] ?? '';
                $pdate = $_POST['paid_date'] ?? '';
                $ref = trim($_POST['reference_no'] ?? '');
                if (!isset($methods[$method])) throw new Exception('Choose a payment method.');
                if (!payroll_is_date($pdate) || $pdate > date('Y-m-d')) throw new Exception('Payment date must be a valid date that is not in the future.');
                if (empty($_POST['confirmed'])) throw new Exception('Tick the confirmation: only record payments after they have actually been made/confirmed.');
                if ($method !== 'cash' && $ref === '') throw new Exception('A batch/reference number is required for non-cash payments.');
                $base = preg_replace('/[^a-f0-9]/', '', (string)($_POST['idem_key'] ?? ''));
                $rows = $db->query("SELECT id, employee_id, net_pay, amount_paid FROM payroll_items WHERE run_id=$runId AND net_pay-amount_paid>0.004")->fetchAll();
                if (!$rows) throw new Exception('Nothing left to pay.');
                $ok = 0; $dup = 0; $fail = 0;
                foreach ($rows as $r) {
                    $bal = round((float)$r['net_pay'] - (float)$r['amount_paid'], 2);
                    $res = payroll_record_payment($db, (int)$r['id'], $bal, $method, $pdate, substr($ref, 0, 80) ?: null, substr($note, 0, 255) ?: null, $base !== '' ? 'b' . $base . '-' . $r['id'] : null);
                    if (!$res['ok']) { $fail++; continue; }
                    if ($res['duplicate']) { $dup++; continue; }
                    $ok++;
                    $c = payroll_employee_contact($db, (int)$r['employee_id']);
                    if ($c && $c['user_id']) notify_user((int)$c['user_id'], 'Payroll payment recorded', 'A payment for ' . $run['period_name'] . ' was recorded (' . $methods[$method] . ').', BASE_PATH . 'modules/payroll/payslips.php?mine=1');
                    if ($c && $S['notify_payment_recorded'] === '1' && filter_var($c['email'] ?? '', FILTER_VALIDATE_EMAIL)) {
                        payroll_queue_email($db, $c['email'], 'Payroll payment recorded: ' . $run['period_name'],
                            payroll_email_html('Payment recorded', ['Hello ' . $c['first_name'] . ', a payroll payment for "' . $run['period_name'] . '" was recorded on ' . payroll_fmt_date($pdate) . ' via ' . $methods[$method] . '.'], payroll_portal_url('modules/payroll/payslips.php?mine=1'), 'View my payslips'),
                            'payment_recorded', 'payroll_items', (int)$r['id']);
                    }
                }
                payroll_dispatch_pending($db, 100);
                logActivity("Payroll run #$runId: batch payment recorded ($method, ref " . ($ref ?: 'n/a') . ") - $ok recorded, $dup duplicate(s) ignored, $fail failed");
                payroll_redirect('run.php', "Batch payment: $ok recorded" . ($dup ? ", $dup duplicate(s) ignored" : '') . ($fail ? ", $fail failed" : '') . '.', null, $to);

            case 'cancel':
                if ($run['status'] === 'draft') require_permission('process_payroll'); else require_permission('approve_payroll');
                run_need($run, ['draft', 'for_review', 'for_approval', 'approved', 'finalized'], 'This payroll can no longer be cancelled. Use the adjustment workflow for corrections.');
                $pc = $db->prepare("SELECT COUNT(*) FROM payroll_payments WHERE run_id=?");
                $pc->execute([$runId]);
                if ((int)$pc->fetchColumn() > 0) throw new Exception('Payments were already recorded, so this payroll cannot be cancelled. Use the adjustment workflow instead.');
                if (strlen($note) < 5) throw new Exception('A cancellation reason is required (at least 5 characters).');
                $from = $run['status'];
                $db->prepare("UPDATE payroll_runs SET status='cancelled', cancelled_by=?, cancelled_at=NOW(), cancel_reason=? WHERE id=?")->execute([$uid, substr($note, 0, 500), $runId]);
                payroll_log_approval($db, $runId, 'cancel', $from, 'cancelled', $note);
                logActivity("Payroll run #$runId: CANCELLED from $from - $note");
                payroll_redirect('periods.php', 'Payroll run cancelled. You may open a new run for the period.');
        }
    } catch (Throwable $e) {
        if ($db->inTransaction()) $db->rollBack();
        $error_message = $e->getMessage();
        $run = run_load($db, $runId);
    }
}

// ------------------------------------------------------------------ view data
$status = $run['status'];
$canProcess = hasPermission('process_payroll');
$canReview = hasPermission('review_payroll');
$canApprove = hasPermission('approve_payroll');
$canPay = hasPermission('record_payroll_payments');
$items = $db->prepare("SELECT i.*, e.first_name, e.last_name, e.employee_id AS emp_code FROM payroll_items i JOIN employees e ON e.id=i.employee_id WHERE i.run_id=? ORDER BY e.last_name, e.first_name");
$items->execute([$runId]);
$items = $items->fetchAll();
$itemCount = count($items);
$unvalidated = 0; $uncalc = 0; $withIssuesUnval = 0;
foreach ($items as $i) {
    if (!(int)$i['validated']) { $unvalidated++; if (trim((string)$i['issues']) !== '') $withIssuesUnval++; }
    if ($i['calculated_at'] === null) $uncalc++;
}
$problems = ($status === 'draft' || $status === 'approved') ? payroll_submit_problems($db, $runId) : [];
$hist = $db->prepare("SELECT a.*, u.full_name FROM payroll_approvals a LEFT JOIN users u ON u.id=a.user_id WHERE a.run_id=? ORDER BY a.id DESC");
$hist->execute([$runId]);
$hist = $hist->fetchAll();
$excluded = $_SESSION['payroll_excluded_' . $runId] ?? [];
unset($_SESSION['payroll_excluded_' . $runId]);
$focusId = (int)($_GET['item'] ?? 0);
$focus = $focusId ? run_item($db, $runId, $focusId) : null;
$locked = $status !== 'draft';

$es = $db->prepare("SELECT COUNT(*) FROM email_logs WHERE status='sent' AND ((ref_table='payroll_runs' AND ref_id=?) OR (ref_table='payslips' AND ref_id IN (SELECT id FROM payslips WHERE run_id=?)))");
$es->execute([$runId, $runId]);
$emailsSent = (int)$es->fetchColumn();
$steps = [
    ['Employee setup', true],
    ['Open period', true],
    ['Collect time records', $itemCount > 0],
    ['Validate records', $itemCount > 0 && $unvalidated === 0],
    ['Calculate payroll', $itemCount > 0 && $uncalc === 0],
    ['Review & approve', in_array($status, ['approved', 'finalized', 'partially_paid', 'paid'], true)],
    ['Finalize', in_array($status, ['finalized', 'partially_paid', 'paid'], true)],
    ['Record payment', $status === 'paid'],
    ['Payslips', in_array($status, ['finalized', 'partially_paid', 'paid'], true)],
    ['Notify employees', $emailsSent > 0 && in_array($status, ['finalized', 'partially_paid', 'paid'], true)],
];

$pageTitle = $run['period_name'];
$pageIcon = 'fa-coins';
$pageActions = '<a class="btn btn-outline-secondary" href="periods.php"><i class="fas fa-arrow-left me-1"></i> Periods</a>';
include __DIR__ . '/_layout_top.php';
?>
<div class="card shadow-sm mb-3"><div class="card-body">
    <div class="row g-3 align-items-center">
        <div class="col-lg-8">
            <div class="d-flex flex-wrap gap-3">
                <div><div class="text-muted small">Status</div><?php echo payroll_status_badge($status); ?></div>
                <div><div class="text-muted small">Coverage</div><strong><?php echo h(payroll_fmt_date($run['start_date'])); ?> – <?php echo h(payroll_fmt_date($run['end_date'])); ?></strong></div>
                <div><div class="text-muted small">Pay date</div><strong><?php echo h(payroll_fmt_date($run['pay_date'])); ?></strong></div>
                <div><div class="text-muted small">Schedule</div><strong><?php echo h(payroll_schedule_label($run['pay_schedule'])); ?></strong></div>
                <div><div class="text-muted small">Prepared by</div><strong><?php echo h($run['preparer'] ?: '—'); ?></strong></div>
                <?php if ($run['finalized_at']): ?><div><div class="text-muted small">Finalized</div><strong><?php echo h(date('M d, Y H:i', strtotime($run['finalized_at']))); ?></strong></div><?php endif; ?>
            </div>
        </div>
        <div class="col-lg-4 text-lg-end">
            <div class="small text-muted">Gross <?php echo h(payroll_money($run['total_gross'])); ?> · Deductions <?php echo h(payroll_money($run['total_deductions'])); ?></div>
            <div class="fs-4 fw-bold">Net <?php echo h(payroll_money($run['total_net'])); ?></div>
        </div>
    </div>
    <hr>
    <div class="d-flex flex-wrap gap-2">
        <?php foreach ($steps as $n => $s): ?>
            <span class="badge <?php echo $s[1] ? 'bg-success' : 'bg-light text-muted border'; ?>"><?php echo sprintf('%02d', $n + 1); ?> <?php echo h($s[0]); ?> <?php echo $s[1] ? '✓' : ''; ?></span>
        <?php endforeach; ?>
    </div>
    <div class="small text-muted mt-2"><strong>Finalized ≠ Paid.</strong> Finalizing locks the figures; salary is only marked paid after a payment is recorded and confirmed.</div>
</div></div>

<?php if ($excluded): ?>
<div class="alert alert-info small"><strong>Not included in this run:</strong>
    <?php foreach ($excluded as $x): ?><span class="badge bg-light text-dark border me-1"><?php echo h($x[0]); ?> — <?php echo h($x[1]); ?></span><?php endforeach; ?></div>
<?php endif; ?>

<?php // ---------------- Action panel ?>
<div class="card shadow-sm mb-3" data-no-center><div class="card-header bg-white"><strong>Next actions</strong></div><div class="card-body">
<?php if ($status === 'draft'): ?>
    <?php if ($canProcess): ?>
    <div class="d-flex flex-wrap gap-2 mb-3">
        <form method="POST" data-confirm="Collect attendance, leave and overtime for all eligible employees? Unvalidated records will be refreshed."><?php echo csrf_field(); ?><input type="hidden" name="action" value="collect"><input type="hidden" name="run_id" value="<?php echo $runId; ?>"><button class="btn btn-outline-primary"><i class="fas fa-clock me-1"></i> 03 Collect time records</button></form>
        <?php if ($unvalidated > 0): ?>
        <form method="POST" data-confirm="Confirm all records that have no issues exactly as detected?"><?php echo csrf_field(); ?><input type="hidden" name="action" value="confirm_all"><input type="hidden" name="run_id" value="<?php echo $runId; ?>"><button class="btn btn-outline-primary"><i class="fas fa-check-double me-1"></i> 04 Confirm records without issues</button></form>
        <?php endif; ?>
        <form method="POST" data-confirm="Calculate earnings, deductions, gross and net pay for all employees?"><?php echo csrf_field(); ?><input type="hidden" name="action" value="calculate"><input type="hidden" name="run_id" value="<?php echo $runId; ?>"><button class="btn btn-outline-primary"<?php echo ($itemCount === 0 || $unvalidated > 0) ? ' disabled' : ''; ?>><i class="fas fa-calculator me-1"></i> 05 Calculate payroll</button></form>
    </div>
    <?php if ($unvalidated > 0): ?><div class="small text-muted mb-2"><?php echo $unvalidated; ?> record(s) need validation (<?php echo $withIssuesUnval; ?> with issues such as missing time-in/out or unrecorded absences). Deductions are only applied from validated values.</div><?php endif; ?>
    <?php if ($problems): ?>
        <div class="alert alert-warning small mb-3"><strong>Before submitting for review:</strong><ul class="mb-0"><?php foreach ($problems as $p): ?><li><?php echo h($p); ?></li><?php endforeach; ?></ul></div>
    <?php else: ?>
        <form method="POST" class="row g-2" data-confirm="Submit this payroll for review? It will be locked from editing until reviewed or returned."><?php echo csrf_field(); ?><input type="hidden" name="action" value="submit_review"><input type="hidden" name="run_id" value="<?php echo $runId; ?>">
            <div class="col-md-8"><input type="text" name="note" class="form-control" maxlength="500" placeholder="Note for the reviewer (optional)"></div>
            <div class="col-md-4"><button class="btn btn-primary w-100"><i class="fas fa-paper-plane me-1"></i> 06 Submit for review</button></div>
        </form>
    <?php endif; ?>
    <?php else: ?><p class="text-muted mb-0">Waiting for the payroll officer to prepare this payroll.</p><?php endif; ?>

<?php elseif ($status === 'for_review'): ?>
    <?php if ($canReview): ?>
    <form method="POST" class="row g-2"><?php echo csrf_field(); ?><input type="hidden" name="run_id" value="<?php echo $runId; ?>">
        <div class="col-12"><input type="text" name="note" class="form-control" maxlength="500" placeholder="Review remarks (required if returning to draft)"></div>
        <div class="col-auto"><button name="action" value="review_pass" class="btn btn-success" onclick="return confirm('Pass this payroll to approval?')"><i class="fas fa-check me-1"></i> Review passed</button></div>
        <div class="col-auto"><button name="action" value="review_return" class="btn btn-outline-danger" onclick="return confirm('Return this payroll to Draft for correction?')"><i class="fas fa-rotate-left me-1"></i> Return to draft</button></div>
    </form>
    <?php else: ?><p class="text-muted mb-0">Waiting for a reviewer.</p><?php endif; ?>

<?php elseif ($status === 'for_approval'): ?>
    <?php if ($canApprove): list($allowedApprove, $whyApprove) = payroll_can_approve_run($db, $run); ?>
    <?php if ($whyApprove): ?><div class="alert alert-<?php echo $allowedApprove ? 'info' : 'warning'; ?> small"><?php echo h($whyApprove); ?></div><?php endif; ?>
    <form method="POST" class="row g-2"><?php echo csrf_field(); ?><input type="hidden" name="run_id" value="<?php echo $runId; ?>">
        <div class="col-12"><input type="text" name="note" class="form-control" maxlength="500" placeholder="Approval remarks (required if returning to draft)"></div>
        <div class="col-auto"><button name="action" value="approve" class="btn btn-success"<?php echo $allowedApprove ? '' : ' disabled'; ?> onclick="return confirm('Approve this payroll computation?')"><i class="fas fa-stamp me-1"></i> Approve</button></div>
        <div class="col-auto"><button name="action" value="approve_return" class="btn btn-outline-danger" onclick="return confirm('Return this payroll to Draft for correction?')"><i class="fas fa-rotate-left me-1"></i> Return to draft</button></div>
    </form>
    <?php else: ?><p class="text-muted mb-0">Waiting for an authorized approver.</p><?php endif; ?>

<?php elseif ($status === 'approved'): ?>
    <?php if ($canApprove): ?>
    <form method="POST" data-confirm="Finalize this payroll? Figures will be locked, payslips generated and employees notified. Corrections afterwards need the adjustment workflow."><?php echo csrf_field(); ?><input type="hidden" name="action" value="finalize"><input type="hidden" name="run_id" value="<?php echo $runId; ?>"><button class="btn btn-dark"><i class="fas fa-lock me-1"></i> 07 Finalize payroll</button></form>
    <?php else: ?><p class="text-muted mb-0">Approved. Waiting for an authorized person to finalize.</p><?php endif; ?>

<?php elseif (in_array($status, ['finalized', 'partially_paid'], true)): ?>
    <?php if ($canPay): ?>
    <form method="POST" class="row g-2 align-items-end" data-confirm="Record the full remaining balance as paid for ALL employees using these details? Only do this after the payment was actually made."><?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="record_payment_all"><input type="hidden" name="run_id" value="<?php echo $runId; ?>"><input type="hidden" name="idem_key" value="<?php echo h(bin2hex(random_bytes(10))); ?>">
        <div class="col-md-3"><label class="form-label small mb-0">Method</label><select name="payment_method" class="form-select"><?php foreach ($methods as $k => $l): ?><option value="<?php echo $k; ?>"><?php echo h($l); ?></option><?php endforeach; ?></select></div>
        <div class="col-md-2"><label class="form-label small mb-0">Date paid</label><input type="date" name="paid_date" class="form-control" max="<?php echo date('Y-m-d'); ?>" value="<?php echo date('Y-m-d'); ?>" required></div>
        <div class="col-md-3"><label class="form-label small mb-0">Batch / reference no.</label><input type="text" name="reference_no" class="form-control" maxlength="80"></div>
        <div class="col-md-4"><div class="form-check"><input class="form-check-input" type="checkbox" name="confirmed" value="1" id="conf_all"><label class="form-check-label small" for="conf_all">Payment is confirmed as made</label></div><button class="btn btn-success w-100 mt-1"><i class="fas fa-money-bill-wave me-1"></i> 08 Record payment for all unpaid</button></div>
    </form>
    <div class="small text-muted mt-2">For individual or partial payments, open an employee below.</div>
    <?php else: ?><p class="text-muted mb-0">Finalized. Waiting for Finance to record payments.</p><?php endif; ?>
<?php elseif ($status === 'paid'): ?>
    <p class="text-success mb-0"><i class="fas fa-circle-check me-1"></i> All employees have been paid.</p>
<?php elseif ($status === 'cancelled'): ?>
    <p class="text-danger mb-0"><i class="fas fa-ban me-1"></i> Cancelled: <?php echo h($run['cancel_reason']); ?></p>
<?php endif; ?>

<?php if (in_array($status, ['draft', 'for_review', 'for_approval', 'approved', 'finalized'], true) && (($status === 'draft' && $canProcess) || ($status !== 'draft' && $canApprove))): ?>
    <hr>
    <form method="POST" class="row g-2" data-confirm="Cancel this payroll run? This cannot be undone (you can open a new run for the period)."><?php echo csrf_field(); ?><input type="hidden" name="action" value="cancel"><input type="hidden" name="run_id" value="<?php echo $runId; ?>">
        <div class="col-md-9"><input type="text" name="note" class="form-control form-control-sm" maxlength="500" placeholder="Reason for cancelling (required)"></div>
        <div class="col-md-3"><button class="btn btn-sm btn-outline-danger w-100">Cancel payroll run</button></div>
    </form>
<?php endif; ?>
</div></div>

<?php // ---------------- Items table ?>
<div class="card shadow-sm mb-3"><div class="card-header bg-white"><strong>Employees in this payroll</strong> <span class="text-muted small">(<?php echo $itemCount; ?>)</span></div>
<div class="table-responsive"><table class="table table-hover table-sm align-middle mb-0">
<thead class="table-light"><tr><th>Employee</th><th>Type</th><th class="text-end">Present / Sched.</th><th class="text-end">Absent</th><th class="text-end">Late (min)</th><th class="text-end">UT (min)</th><th class="text-end">OT (h)</th><th>Validated</th><th class="text-end">Gross</th><th class="text-end">Deductions</th><th class="text-end">Net</th><th>Payment</th><th></th></tr></thead><tbody>
<?php if (!$items): ?><tr><td colspan="13" class="text-center text-muted py-4">No employees yet. Use “Collect time records”.</td></tr><?php endif; ?>
<?php $tg = $td = $tn = 0; foreach ($items as $i): $tg += $i['gross_pay']; $td += $i['total_deductions']; $tn += $i['net_pay']; ?>
<tr<?php echo $focusId === (int)$i['id'] ? ' class="table-active"' : ''; ?>>
    <td><strong><?php echo h($i['first_name'] . ' ' . $i['last_name']); ?></strong><div class="small text-muted"><?php echo h($i['emp_code']); ?></div></td>
    <td><?php echo h(ucfirst($i['salary_type'])); ?></td>
    <td class="text-end"><?php echo h(rtrim(rtrim(number_format((float)$i['days_present'], 2, '.', ''), '0'), '.') ?: '0'); ?> / <?php echo h(rtrim(rtrim(number_format((float)$i['scheduled_days'], 2, '.', ''), '0'), '.') ?: '0'); ?></td>
    <td class="text-end"><?php echo h(rtrim(rtrim(number_format((float)$i['absent_days'], 2, '.', ''), '0'), '.') ?: '0'); ?></td>
    <td class="text-end"><?php echo (int)$i['late_minutes']; ?></td>
    <td class="text-end"><?php echo (int)$i['undertime_minutes']; ?></td>
    <td class="text-end"><?php echo h(rtrim(rtrim(number_format((float)$i['ot_hours'], 2, '.', ''), '0'), '.') ?: '0'); ?></td>
    <td><?php echo (int)$i['validated'] ? '<span class="badge bg-success">Yes</span>' : (trim((string)$i['issues']) !== '' ? '<span class="badge bg-warning text-dark" title="Has issues to resolve">Issues</span>' : '<span class="badge bg-secondary">Pending</span>'); ?></td>
    <td class="text-end"><?php echo $i['calculated_at'] ? h(payroll_money($i['gross_pay'])) : '—'; ?></td>
    <td class="text-end"><?php echo $i['calculated_at'] ? h(payroll_money($i['total_deductions'])) : '—'; ?></td>
    <td class="text-end <?php echo (float)$i['net_pay'] < 0 ? 'text-danger fw-bold' : 'fw-semibold'; ?>"><?php echo $i['calculated_at'] ? h(payroll_money($i['net_pay'])) : '—'; ?></td>
    <td><?php echo in_array($status, ['finalized', 'partially_paid', 'paid'], true) ? payroll_pay_badge($i['payment_status']) : '—'; ?></td>
    <td class="text-end"><a class="btn btn-sm btn-outline-primary" href="run.php?id=<?php echo $runId; ?>&item=<?php echo (int)$i['id']; ?>#detail">Details</a></td>
</tr>
<?php endforeach; ?>
<?php if ($items): ?><tr class="table-light fw-bold"><td colspan="8" class="text-end">Totals</td><td class="text-end"><?php echo h(payroll_money($tg)); ?></td><td class="text-end"><?php echo h(payroll_money($td)); ?></td><td class="text-end"><?php echo h(payroll_money($tn)); ?></td><td colspan="2"></td></tr><?php endif; ?>
</tbody></table></div></div>

<?php // ---------------- Item detail ?>
<?php if ($focus):
    $earn = $db->prepare("SELECT * FROM payroll_earnings WHERE item_id=? ORDER BY id");
    $earn->execute([$focus['id']]);
    $earn = $earn->fetchAll();
    $ded = $db->prepare("SELECT * FROM payroll_deductions WHERE item_id=? ORDER BY id");
    $ded->execute([$focus['id']]);
    $ded = $ded->fetchAll();
    $pays = $db->prepare("SELECT p.*, u.full_name FROM payroll_payments p LEFT JOIN users u ON u.id=p.recorded_by WHERE p.item_id=? ORDER BY p.id");
    $pays->execute([$focus['id']]);
    $pays = $pays->fetchAll();
    $detected = json_decode((string)$focus['detected_json'], true) ?: [];
    $issueLines = array_filter(explode("\n", (string)$focus['issues']), 'strlen');
    $balance = round((float)$focus['net_pay'] - (float)$focus['amount_paid'], 2);
?>
<div class="card shadow-sm mb-3" id="detail" data-no-center><div class="card-header bg-white d-flex justify-content-between"><strong><?php echo h($focus['first_name'] . ' ' . $focus['last_name']); ?> — details</strong><a href="run.php?id=<?php echo $runId; ?>" class="small">close</a></div><div class="card-body">
<div class="row g-4">
  <div class="col-lg-5">
    <h6>Time records (step 03–04)</h6>
    <?php if ($detected): ?><div class="small text-muted mb-2">Detected: absent <?php echo h($detected['absent_days'] ?? 0); ?> · late <?php echo (int)($detected['late_minutes'] ?? 0); ?> min · undertime <?php echo (int)($detected['undertime_minutes'] ?? 0); ?> min · OT <?php echo h($detected['ot_hours'] ?? 0); ?> h · paid leave <?php echo h($detected['paid_leave_days'] ?? 0); ?> d · unpaid leave <?php echo h($detected['unpaid_leave_days'] ?? 0); ?> d</div><?php endif; ?>
    <?php if ($issueLines): ?><div class="alert alert-warning small py-2"><strong>Resolve before confirming:</strong><ul class="mb-0 ps-3"><?php foreach (array_slice($issueLines, 0, 25) as $l): ?><li><?php echo h($l); ?></li><?php endforeach; ?><?php if (count($issueLines) > 25): ?><li>… and <?php echo count($issueLines) - 25; ?> more</li><?php endif; ?></ul></div><?php endif; ?>
    <?php if ($status === 'draft' && $canProcess): ?>
    <form method="POST" class="row g-2" data-confirm="Confirm these values? Deductions and overtime are computed from them."><?php echo csrf_field(); ?><input type="hidden" name="action" value="validate_item"><input type="hidden" name="run_id" value="<?php echo $runId; ?>"><input type="hidden" name="item_id" value="<?php echo (int)$focus['id']; ?>">
        <div class="col-6"><label class="form-label small mb-0">Unpaid absent days</label><input type="number" step="0.5" min="0" max="<?php echo h($focus['scheduled_days']); ?>" name="absent_days" class="form-control form-control-sm" value="<?php echo h((float)$focus['absent_days']); ?>"></div>
        <div class="col-6"><label class="form-label small mb-0">Late (minutes)</label><input type="number" min="0" name="late_minutes" class="form-control form-control-sm" value="<?php echo (int)$focus['late_minutes']; ?>"></div>
        <div class="col-6"><label class="form-label small mb-0">Undertime (minutes)</label><input type="number" min="0" name="undertime_minutes" class="form-control form-control-sm" value="<?php echo (int)$focus['undertime_minutes']; ?>"></div>
        <div class="col-6"><label class="form-label small mb-0">Approved overtime (hours)</label><input type="number" step="0.25" min="0" max="300" name="ot_hours" class="form-control form-control-sm" value="<?php echo h((float)$focus['ot_hours']); ?>"></div>
        <div class="col-12"><input type="text" name="note" maxlength="255" class="form-control form-control-sm" placeholder="Validation note (e.g. approved by supervisor, forgot to time-out)" value="<?php echo h($focus['validation_note']); ?>"></div>
        <div class="col-12"><button class="btn btn-sm btn-primary"><i class="fas fa-check me-1"></i> <?php echo (int)$focus['validated'] ? 'Re-confirm values' : 'Confirm values'; ?></button></div>
    </form>
    <?php else: ?>
    <div class="small">Confirmed: absent <?php echo h((float)$focus['absent_days']); ?> d · late <?php echo (int)$focus['late_minutes']; ?> min · undertime <?php echo (int)$focus['undertime_minutes']; ?> min · OT <?php echo h((float)$focus['ot_hours']); ?> h<?php if ($focus['validation_note']): ?><br>Note: <?php echo h($focus['validation_note']); ?><?php endif; ?></div>
    <?php endif; ?>
  </div>

  <div class="col-lg-7">
    <h6>Computation</h6>
    <?php if (!$focus['calculated_at']): ?><div class="text-muted small">Not calculated yet.</div><?php else: ?>
    <div class="row g-3">
      <div class="col-md-6"><table class="table table-sm"><thead><tr><th colspan="3" class="table-success">Earnings</th></tr></thead><tbody>
        <?php foreach ($earn as $l): ?><tr><td><?php echo h($l['description']); ?><?php if ($l['source'] !== 'auto'): ?> <span class="badge bg-light text-dark border"><?php echo h($l['source']); ?></span><?php endif; ?></td><td class="text-end"><?php echo h(payroll_money($l['amount'])); ?></td><td class="text-end"><?php if ($l['source'] === 'manual' && $status === 'draft' && $canProcess): ?><form method="POST" data-confirm="Remove this line?" class="d-inline"><?php echo csrf_field(); ?><input type="hidden" name="action" value="delete_line"><input type="hidden" name="run_id" value="<?php echo $runId; ?>"><input type="hidden" name="item_id" value="<?php echo (int)$focus['id']; ?>"><input type="hidden" name="kind" value="earning"><input type="hidden" name="line_id" value="<?php echo (int)$l['id']; ?>"><button class="btn btn-sm btn-link text-danger p-0">✕</button></form><?php endif; ?></td></tr><?php endforeach; ?>
        <tr class="fw-bold"><td>Gross pay</td><td class="text-end"><?php echo h(payroll_money($focus['gross_pay'])); ?></td><td></td></tr></tbody></table></div>
      <div class="col-md-6"><table class="table table-sm"><thead><tr><th colspan="3" class="table-danger">Deductions</th></tr></thead><tbody>
        <?php if (!$ded): ?><tr><td colspan="3" class="text-muted">None</td></tr><?php endif; ?>
        <?php foreach ($ded as $l): ?><tr><td><?php echo h($l['description']); ?><?php if ($l['source'] !== 'auto'): ?> <span class="badge bg-light text-dark border"><?php echo h($l['source']); ?></span><?php endif; ?></td><td class="text-end"><?php echo h(payroll_money($l['amount'])); ?></td><td class="text-end"><?php if ($l['source'] === 'manual' && $status === 'draft' && $canProcess): ?><form method="POST" data-confirm="Remove this line?" class="d-inline"><?php echo csrf_field(); ?><input type="hidden" name="action" value="delete_line"><input type="hidden" name="run_id" value="<?php echo $runId; ?>"><input type="hidden" name="item_id" value="<?php echo (int)$focus['id']; ?>"><input type="hidden" name="kind" value="deduction"><input type="hidden" name="line_id" value="<?php echo (int)$l['id']; ?>"><button class="btn btn-sm btn-link text-danger p-0">✕</button></form><?php endif; ?></td></tr><?php endforeach; ?>
        <tr class="fw-bold"><td>Total deductions</td><td class="text-end"><?php echo h(payroll_money($focus['total_deductions'])); ?></td><td></td></tr></tbody></table></div>
    </div>
    <div class="fs-5 fw-bold text-end">Net pay: <?php echo h(payroll_money($focus['net_pay'])); ?></div>
    <?php endif; ?>

    <?php if ($status === 'draft' && $canProcess): ?>
    <form method="POST" class="row g-2 mt-2 border-top pt-2"><?php echo csrf_field(); ?><input type="hidden" name="action" value="add_line"><input type="hidden" name="run_id" value="<?php echo $runId; ?>"><input type="hidden" name="item_id" value="<?php echo (int)$focus['id']; ?>">
        <div class="col-12 small text-muted">Add a manual line (holiday pay, night differential, bonus, other earning, or a documented deduction). These are not computed automatically because holiday calendars and shift data are not tracked.</div>
        <div class="col-md-3"><select name="kind" class="form-select form-select-sm"><option value="earning">Earning</option><option value="deduction">Deduction</option></select></div>
        <div class="col-md-3"><select name="line_type" class="form-select form-select-sm"><option value="holiday_pay">Holiday pay</option><option value="night_diff">Night differential</option><option value="bonus">Bonus / incentive</option><option value="other_earning">Other earning</option></select></div>
        <div class="col-md-4"><input type="text" name="description" maxlength="150" class="form-control form-control-sm" placeholder="Description / basis" required></div>
        <div class="col-md-2"><input type="number" step="0.01" min="0.01" name="amount" class="form-control form-control-sm" placeholder="₱" required></div>
        <div class="col-12"><button class="btn btn-sm btn-outline-primary">Add line</button> <span class="small text-muted">(for deductions, “Type” is ignored)</span></div>
    </form>
    <?php endif; ?>

    <?php if (in_array($status, ['finalized', 'partially_paid', 'paid'], true)): ?>
    <div class="border-top mt-3 pt-3"><h6>Payments</h6>
      <div class="small mb-2">Net <?php echo h(payroll_money($focus['net_pay'])); ?> · Paid <?php echo h(payroll_money($focus['amount_paid'])); ?> · Balance <strong><?php echo h(payroll_money(max(0, $balance))); ?></strong> <?php echo payroll_pay_badge($focus['payment_status']); ?></div>
      <?php if ($pays): ?><table class="table table-sm"><thead><tr><th>Date</th><th>Method</th><th>Reference</th><th class="text-end">Amount</th><th>By</th></tr></thead><tbody><?php foreach ($pays as $p): ?><tr><td><?php echo h(payroll_fmt_date($p['paid_date'])); ?></td><td><?php echo h($methods[$p['payment_method']] ?? $p['payment_method']); ?></td><td><?php echo h($p['reference_no'] ?: '—'); ?></td><td class="text-end"><?php echo h(payroll_money($p['amount'])); ?></td><td><?php echo h($p['full_name'] ?: '—'); ?></td></tr><?php endforeach; ?></tbody></table><?php endif; ?>
      <?php if ($canPay && in_array($status, ['finalized', 'partially_paid'], true) && $balance > 0.004): ?>
      <form method="POST" class="row g-2" data-confirm="Record this payment? Only do so after it was actually made."><?php echo csrf_field(); ?><input type="hidden" name="action" value="record_payment"><input type="hidden" name="run_id" value="<?php echo $runId; ?>"><input type="hidden" name="item_id" value="<?php echo (int)$focus['id']; ?>"><input type="hidden" name="idem_key" value="<?php echo h(bin2hex(random_bytes(10))); ?>">
        <div class="col-md-3"><input type="number" step="0.01" min="0.01" max="<?php echo h($balance); ?>" name="amount" class="form-control form-control-sm" value="<?php echo h(number_format($balance, 2, '.', '')); ?>" required></div>
        <div class="col-md-3"><select name="payment_method" class="form-select form-select-sm"><?php foreach ($methods as $k => $l): ?><option value="<?php echo $k; ?>"><?php echo h($l); ?></option><?php endforeach; ?></select></div>
        <div class="col-md-3"><input type="date" name="paid_date" class="form-control form-control-sm" max="<?php echo date('Y-m-d'); ?>" value="<?php echo date('Y-m-d'); ?>" required></div>
        <div class="col-md-3"><input type="text" name="reference_no" maxlength="80" class="form-control form-control-sm" placeholder="Reference no."></div>
        <div class="col-md-8"><input type="text" name="note" maxlength="255" class="form-control form-control-sm" placeholder="Notes (optional)"></div>
        <div class="col-md-4"><div class="form-check"><input class="form-check-input" type="checkbox" name="confirmed" value="1" id="conf_one"><label class="form-check-label small" for="conf_one">Payment confirmed</label></div></div>
        <div class="col-12"><button class="btn btn-sm btn-success">Record payment</button></div>
      </form>
      <?php endif; ?>
    </div>
    <?php endif; ?>
  </div>
</div></div></div>
<?php endif; ?>

<div class="card shadow-sm"><div class="card-header bg-white"><strong>Approval &amp; status history</strong></div>
<div class="table-responsive"><table class="table table-sm mb-0"><thead class="table-light"><tr><th>When</th><th>Action</th><th>From → To</th><th>By</th><th>Remarks</th></tr></thead><tbody>
<?php foreach ($hist as $a): ?><tr><td class="small"><?php echo h(date('M d, Y H:i', strtotime($a['created_at']))); ?></td><td><?php echo h($a['action']); ?></td><td class="small"><?php echo h(($a['from_status'] ?: '—') . ' → ' . ($a['to_status'] ?: '—')); ?></td><td><?php echo h($a['full_name'] ?: 'System'); ?></td><td class="small"><?php echo h($a['remarks']); ?></td></tr><?php endforeach; ?>
</tbody></table></div></div>
<?php include __DIR__ . '/_layout_bottom.php';
