<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/payroll.php';
require_permission('view_payroll');
verify_csrf();
$db = getDB();
payroll_ensure_schema($db);
$success_message = null;
$error_message = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    try {
        require_permission('process_payroll');
        if ($action === 'dispatch_pending') {
            $res = payroll_dispatch_pending($db, 25);
            logActivity("Payroll email: dispatch run - sent {$res['sent']}, failed {$res['failed']}");
            if ($res['failed'] > 0) payroll_redirect('emails.php', null, "Sent {$res['sent']}, failed {$res['failed']}. Check the error column - SMTP may not be configured.");
            payroll_redirect('emails.php', "Sent {$res['sent']} email(s).");
        } elseif ($action === 'retry') {
            $id = (int)($_POST['log_id'] ?? 0);
            $ok = payroll_dispatch_email($db, $id);
            logActivity("Payroll email: retry log #$id - " . ($ok ? 'sent' : 'failed'));
            if ($ok) payroll_redirect('emails.php', 'Email sent.');
            payroll_redirect('emails.php', null, 'Email still failed. See the error message in the log.');
        }
    } catch (Throwable $e) {
        $error_message = $e->getMessage();
    }
}

$counts = ['pending' => 0, 'sent' => 0, 'failed' => 0];
foreach ($db->query("SELECT status, COUNT(*) c FROM email_logs GROUP BY status")->fetchAll() as $c) $counts[$c['status']] = (int)$c['c'];
$logs = $db->query("SELECT * FROM email_logs ORDER BY id DESC LIMIT 200")->fetchAll();
$canProcess = hasPermission('process_payroll');
$smtpOk = function_exists('smtp_is_configured') && smtp_is_configured();

$pageTitle = 'Email Delivery Log';
$pageIcon = 'fa-envelope-circle-check';
$pageActions = ($canProcess && ($counts['pending'] + $counts['failed']) > 0)
    ? '<form method="POST" data-confirm="Send all pending and failed emails now?">' . csrf_field() . '<input type="hidden" name="action" value="dispatch_pending"><button class="btn btn-primary"><i class="fas fa-paper-plane me-1"></i> Send pending / retry failed</button></form>' : '';
include __DIR__ . '/_layout_top.php';
?>
<?php if (!$smtpOk): ?>
<div class="alert alert-warning small"><i class="fas fa-triangle-exclamation me-1"></i> Email is not ready yet:
    <ul class="mb-1 ps-3"><?php foreach (mail_diagnostics()['problems'] ?: ['The SMTP credentials are incomplete.'] as $pr): ?><li><?php echo h($pr); ?></li><?php endforeach; ?></ul>
    Check Settings &gt; HRMS Email / SMTP for the full checklist. Nothing is lost: emails stay queued here and can be sent later without re-running any payroll step.</div>
<?php endif; ?>
<div class="row g-3 mb-4">
    <div class="col-md-4"><div class="card shadow-sm"><div class="card-body"><div class="text-muted small">Pending</div><div class="fs-3 fw-bold"><?php echo $counts['pending']; ?></div></div></div></div>
    <div class="col-md-4"><div class="card shadow-sm"><div class="card-body"><div class="text-muted small">Sent</div><div class="fs-3 fw-bold text-success"><?php echo $counts['sent']; ?></div></div></div></div>
    <div class="col-md-4"><div class="card shadow-sm"><div class="card-body"><div class="text-muted small">Failed</div><div class="fs-3 fw-bold text-danger"><?php echo $counts['failed']; ?></div></div></div></div>
</div>
<div class="card shadow-sm"><div class="table-responsive"><table class="table table-hover align-middle mb-0">
<thead class="table-light"><tr><th>When</th><th>Event</th><th>Recipient</th><th>Subject</th><th>Status</th><th>Tries</th><th>Error</th><th></th></tr></thead><tbody>
<?php if (!$logs): ?><tr><td colspan="8" class="text-center text-muted py-4">No emails logged yet.</td></tr><?php endif; ?>
<?php foreach ($logs as $l): ?>
<tr>
    <td class="small"><?php echo h(date('M d, Y H:i', strtotime($l['created_at']))); ?></td>
    <td><span class="badge bg-light text-dark border"><?php echo h($l['event_type']); ?></span></td>
    <td class="small"><?php echo h($l['recipient']); ?></td>
    <td class="small"><?php echo h($l['subject']); ?></td>
    <td><?php echo $l['status'] === 'sent' ? '<span class="badge bg-success">Sent</span>' : ($l['status'] === 'failed' ? '<span class="badge bg-danger">Failed</span>' : '<span class="badge bg-secondary">Pending</span>'); ?></td>
    <td><?php echo (int)$l['attempts']; ?></td>
    <td class="small text-muted"><?php echo h($l['error_message'] ?: ''); ?></td>
    <td class="text-end"><?php if ($canProcess && $l['status'] !== 'sent'): ?><form method="POST"><?php echo csrf_field(); ?><input type="hidden" name="action" value="retry"><input type="hidden" name="log_id" value="<?php echo (int)$l['id']; ?>"><button class="btn btn-sm btn-outline-primary">Retry</button></form><?php endif; ?></td>
</tr>
<?php endforeach; ?>
</tbody></table></div></div>
<?php include __DIR__ . '/_layout_bottom.php';
