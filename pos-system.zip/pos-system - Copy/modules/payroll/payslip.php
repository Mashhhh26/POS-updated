<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/payroll.php';
if (!isset($_SESSION['user_id'])) { header('Location: ' . BASE_PATH . 'login.php'); exit(); }
$db = getDB();
payroll_ensure_schema($db);

$slipId = (int)($_GET['id'] ?? 0);
$sq = $db->prepare("SELECT * FROM payslips WHERE id=?");
$sq->execute([$slipId]);
$slip = $sq->fetch();
if (!$slip) payroll_redirect('payslips.php', null, 'Payslip not found.', ['mine' => 1]);

$isStaff = hasPermission('view_payroll');
$me = payroll_current_employee($db);
$isOwner = $me && (int)$me['id'] === (int)$slip['employee_id'];

$rq = $db->prepare("SELECT r.status, r.finalized_at, p.period_name, p.start_date, p.end_date, p.pay_date, p.pay_schedule FROM payroll_runs r JOIN payroll_periods p ON p.id=r.period_id WHERE r.id=?");
$rq->execute([$slip['run_id']]);
$run = $rq->fetch();

// Employees can only see their OWN payslip, and only once payroll is finalized.
if (!$isStaff) {
    if (!$isOwner) {
        logActivity("Payroll: blocked access to payslip #$slipId");
        payroll_redirect('payslips.php', null, 'You can only view your own payslips.', ['mine' => 1]);
    }
    if (!in_array($run['status'], ['finalized', 'partially_paid', 'paid'], true)) payroll_redirect('payslips.php', null, 'This payslip is not available.', ['mine' => 1]);
    $db->prepare("UPDATE payslips SET last_viewed_at=NOW() WHERE id=?")->execute([$slipId]);
}

$iq = $db->prepare("SELECT i.*, e.first_name, e.last_name, e.employee_id AS emp_code, e.position, e.department FROM payroll_items i JOIN employees e ON e.id=i.employee_id WHERE i.id=?");
$iq->execute([$slip['item_id']]);
$it = $iq->fetch();
$earn = $db->prepare("SELECT * FROM payroll_earnings WHERE item_id=? ORDER BY id");
$earn->execute([$it['id']]);
$earn = $earn->fetchAll();
$ded = $db->prepare("SELECT * FROM payroll_deductions WHERE item_id=? ORDER BY id");
$ded->execute([$it['id']]);
$ded = $ded->fetchAll();
$pays = $db->prepare("SELECT * FROM payroll_payments WHERE item_id=? ORDER BY paid_date, id");
$pays->execute([$it['id']]);
$pays = $pays->fetchAll();
$S = payroll_settings($db);
$methods = ['bank_transfer' => 'Bank transfer', 'cash' => 'Cash', 'ewallet' => 'E-wallet', 'cheque' => 'Cheque', 'other' => 'Other'];
$back = $isStaff && !$isOwner ? 'run.php?id=' . (int)$slip['run_id'] . '&item=' . (int)$it['id'] . '#detail' : 'payslips.php?mine=1';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payslip <?php echo h($slip['reference_no']); ?></title>
    <link href="<?php echo BASE_PATH; ?>assets/vendor/bootstrap/bootstrap.min.css?v=20261010" rel="stylesheet">
    <style>
        body { background:#f3f4f6; }
        .slip { max-width:820px; margin:24px auto; background:#fff; padding:32px; border:1px solid #ddd; border-radius:8px; color:#111; }
        .slip h2 { font-size:1.4rem; margin:0; }
        .slip table td, .slip table th { padding:.35rem .5rem; }
        .net { font-size:1.6rem; font-weight:700; }
        @media print { body { background:#fff; } .no-print { display:none !important; } .slip { border:0; margin:0; padding:0; max-width:100%; } }
    </style>
</head>
<body>
<div class="container no-print mt-3" style="max-width:820px">
    <a href="<?php echo h($back); ?>" class="btn btn-outline-secondary btn-sm">← Back</a>
    <button class="btn btn-primary btn-sm float-end" onclick="window.print()">Print / Save as PDF</button>
</div>
<div class="slip">
    <div class="d-flex justify-content-between align-items-start border-bottom pb-3 mb-3">
        <div><h2><?php echo h($S['company_name']); ?></h2><div class="text-muted small"><?php echo h($S['company_address']); ?></div></div>
        <div class="text-end"><div class="fw-bold">PAYSLIP</div><div class="small">Ref: <?php echo h($slip['reference_no']); ?><?php if ((int)$slip['revision'] > 0): ?> (rev. <?php echo (int)$slip['revision']; ?>)<?php endif; ?></div><div class="small text-muted">Generated <?php echo h(date('M d, Y', strtotime($slip['generated_at']))); ?></div></div>
    </div>
    <div class="row mb-3 small">
        <div class="col-6"><div><strong>Employee:</strong> <?php echo h($it['first_name'] . ' ' . $it['last_name']); ?></div><div><strong>Employee ID:</strong> <?php echo h($it['emp_code']); ?></div><div><strong>Position:</strong> <?php echo h($it['position'] ?: '—'); ?></div><div><strong>Department:</strong> <?php echo h($it['department'] ?: '—'); ?></div></div>
        <div class="col-6"><div><strong>Payroll period:</strong> <?php echo h($run['period_name']); ?></div><div><strong>Coverage:</strong> <?php echo h(payroll_fmt_date($run['start_date'])); ?> – <?php echo h(payroll_fmt_date($run['end_date'])); ?></div><div><strong>Pay date:</strong> <?php echo h(payroll_fmt_date($run['pay_date'])); ?></div><div><strong>Salary type:</strong> <?php echo h(ucfirst($it['salary_type'])); ?> (<?php echo h(payroll_schedule_label($run['pay_schedule'])); ?>)</div></div>
    </div>
    <div class="row g-3">
        <div class="col-6"><table class="table table-sm table-bordered"><thead class="table-light"><tr><th colspan="2">Earnings</th></tr></thead><tbody>
            <?php foreach ($earn as $l): ?><tr><td><?php echo h($l['description']); ?></td><td class="text-end"><?php echo h(payroll_money($l['amount'])); ?></td></tr><?php endforeach; ?>
            <tr class="fw-bold"><td>Gross pay</td><td class="text-end"><?php echo h(payroll_money($it['gross_pay'])); ?></td></tr></tbody></table></div>
        <div class="col-6"><table class="table table-sm table-bordered"><thead class="table-light"><tr><th colspan="2">Deductions</th></tr></thead><tbody>
            <?php if (!$ded): ?><tr><td colspan="2" class="text-muted">None</td></tr><?php endif; ?>
            <?php foreach ($ded as $l): ?><tr><td><?php echo h($l['description']); ?></td><td class="text-end"><?php echo h(payroll_money($l['amount'])); ?></td></tr><?php endforeach; ?>
            <tr class="fw-bold"><td>Total deductions</td><td class="text-end"><?php echo h(payroll_money($it['total_deductions'])); ?></td></tr></tbody></table></div>
    </div>
    <div class="d-flex justify-content-between align-items-center border-top border-bottom py-3 my-2">
        <div class="fw-bold">NET PAY</div><div class="net"><?php echo h(payroll_money($it['net_pay'])); ?></div>
    </div>
    <div class="small mb-2"><strong>Payment status:</strong> <?php echo payroll_pay_badge($it['payment_status']); ?>
        <?php if ($pays): ?><ul class="mb-0 mt-1"><?php foreach ($pays as $p): ?><li><?php echo h(payroll_fmt_date($p['paid_date'])); ?> — <?php echo h(payroll_money($p['amount'])); ?> via <?php echo h($methods[$p['payment_method']] ?? $p['payment_method']); ?><?php echo $p['reference_no'] ? ' (ref. ' . h($p['reference_no']) . ')' : ''; ?></li><?php endforeach; ?></ul>
        <?php else: ?> <span class="text-muted">— no payment recorded yet</span><?php endif; ?></div>
    <div class="text-muted" style="font-size:.75rem">Confidential. Computer-generated payslip; for questions contact HR/Payroll. Figures that rely on sample contribution/tax tables are for demonstration only.</div>
</div>
</body>
</html>
