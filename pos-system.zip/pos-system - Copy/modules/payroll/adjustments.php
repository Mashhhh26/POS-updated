<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/payroll.php';
require_permission('view_payroll');
verify_csrf();
$db = getDB();
payroll_ensure_schema($db);
$success_message = null;
$error_message = null;
$S = payroll_settings($db);
$uid = (int)$_SESSION['user_id'];
$canRequest = hasPermission('process_payroll');
$canDecide = hasPermission('approve_payroll');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'request') {
            require_permission('process_payroll');
            $itemId = (int)($_POST['item_id'] ?? 0);
            $type = $_POST['adj_type'] ?? '';
            $desc = trim($_POST['description'] ?? '');
            $reason = trim($_POST['reason'] ?? '');
            $amt = $_POST['amount'] ?? '';
            if (!in_array($type, ['earning', 'deduction'], true)) throw new Exception('Choose earning or deduction.');
            if (strlen($desc) < 3 || strlen($desc) > 150) throw new Exception('Description is required (3-150 characters).');
            if (strlen($reason) < 10) throw new Exception('Explain the reason for the correction (at least 10 characters).');
            if (!valid_money($amt, false)) throw new Exception('Amount must be more than 0 with at most 2 decimals.');
            $q = $db->prepare("SELECT i.*, r.status AS run_status, r.id AS rid, e.first_name, e.last_name FROM payroll_items i JOIN payroll_runs r ON r.id=i.run_id JOIN employees e ON e.id=i.employee_id WHERE i.id=?");
            $q->execute([$itemId]);
            $it = $q->fetch();
            if (!$it || !in_array($it['run_status'], ['finalized', 'partially_paid', 'paid'], true)) throw new Exception('Corrections can only be requested for finalized payroll.');
            if ($type === 'deduction' && (float)$amt > (float)$it['net_pay']) throw new Exception('This deduction would make the net pay negative.');
            $db->prepare("INSERT INTO payroll_adjustments(run_id,item_id,adj_type,description,amount,reason,requested_by) VALUES(?,?,?,?,?,?,?)")
               ->execute([$it['rid'], $itemId, $type, $desc, (float)$amt, $reason, $uid]);
            logActivity("Payroll: correction requested for {$it['first_name']} {$it['last_name']} (run #{$it['rid']}): $type '$desc' " . payroll_money($amt) . " - $reason");
            foreach (payroll_users_with_permission($db, 'approve_payroll', $uid) as $u) notify_user((int)$u['id'], 'Payroll correction awaiting approval', "A correction for {$it['first_name']} {$it['last_name']} needs approval.", BASE_PATH . 'modules/payroll/adjustments.php');
            payroll_redirect('adjustments.php', 'Correction request submitted for approval. Figures stay unchanged until it is approved.');
        } elseif ($action === 'decide') {
            require_permission('approve_payroll');
            $aid = (int)($_POST['adjustment_id'] ?? 0);
            $decision = $_POST['decision'] ?? '';
            $note = trim($_POST['note'] ?? '');
            if (!in_array($decision, ['approve', 'reject'], true)) throw new Exception('Invalid decision.');
            if ($decision === 'reject' && strlen($note) < 5) throw new Exception('Please give a reason for rejecting (at least 5 characters).');

            $db->beginTransaction();
            $aq = $db->prepare("SELECT * FROM payroll_adjustments WHERE id=? FOR UPDATE");
            $aq->execute([$aid]);
            $adj = $aq->fetch();
            if (!$adj || $adj['status'] !== 'pending') throw new Exception('This correction was already decided.');
            if ((int)$adj['requested_by'] === $uid && count(payroll_users_with_permission($db, 'approve_payroll', $uid)) > 0) throw new Exception('You requested this correction, so another authorized approver must decide it.');

            if ($decision === 'reject') {
                $db->prepare("UPDATE payroll_adjustments SET status='rejected', decided_by=?, decided_at=NOW(), decision_note=? WHERE id=?")->execute([$uid, substr($note, 0, 500), $aid]);
                $db->commit();
                logActivity("Payroll: correction #$aid REJECTED - $note");
                notify_user((int)$adj['requested_by'], 'Payroll correction rejected', 'Your correction request was rejected: ' . $note, BASE_PATH . 'modules/payroll/adjustments.php');
                payroll_redirect('adjustments.php', 'Correction rejected.');
            }

            $iq = $db->prepare("SELECT i.*, r.status AS run_status FROM payroll_items i JOIN payroll_runs r ON r.id=i.run_id WHERE i.id=? FOR UPDATE");
            $iq->execute([$adj['item_id']]);
            $it = $iq->fetch();
            if (!$it || !in_array($it['run_status'], ['finalized', 'partially_paid', 'paid'], true)) throw new Exception('The payroll is no longer in a state that accepts corrections.');
            $before = round((float)$it['net_pay'], 2);
            if ($adj['adj_type'] === 'earning') {
                $db->prepare("INSERT INTO payroll_earnings(item_id,earning_type,description,amount,source,adjustment_id,created_by) VALUES(?, 'adjustment', ?, ?, 'adjustment', ?, ?)")->execute([$adj['item_id'], 'Adjustment: ' . $adj['description'], $adj['amount'], $aid, $uid]);
            } else {
                $db->prepare("INSERT INTO payroll_deductions(item_id,deduction_type,description,amount,source,adjustment_id,created_by) VALUES(?, 'adjustment', ?, ?, 'adjustment', ?, ?)")->execute([$adj['item_id'], 'Adjustment: ' . $adj['description'], $adj['amount'], $aid, $uid]);
            }
            payroll_recalc_item_totals($db, (int)$adj['item_id']);
            $nq = $db->prepare("SELECT net_pay FROM payroll_items WHERE id=?");
            $nq->execute([$adj['item_id']]);
            $after = round((float)$nq->fetchColumn(), 2);
            if ($after < 0) throw new Exception('Approving this would make the net pay negative.');
            $db->prepare("UPDATE payroll_adjustments SET status='approved', decided_by=?, decided_at=NOW(), decision_note=?, net_before=?, net_after=? WHERE id=?")->execute([$uid, substr($note, 0, 500), $before, $after, $aid]);
            payroll_update_run_totals($db, (int)$adj['run_id']);
            $db->prepare("UPDATE payslips SET revision=revision+1, email_status=CASE WHEN email_status='sent' THEN 'pending' ELSE email_status END WHERE item_id=?")->execute([$adj['item_id']]);
            payroll_refresh_payment_status($db, (int)$adj['item_id']);
            payroll_log_approval($db, (int)$adj['run_id'], 'adjustment_approved', $it['run_status'], $it['run_status'], "#$aid {$adj['adj_type']} '{$adj['description']}' " . payroll_money($adj['amount']) . ": net " . payroll_money($before) . ' -> ' . payroll_money($after));
            $db->commit();
            logActivity("Payroll: correction #$aid APPROVED ({$adj['adj_type']} " . payroll_money($adj['amount']) . "), net " . payroll_money($before) . ' -> ' . payroll_money($after));

            // Notify the requester and the affected employee
            notify_user((int)$adj['requested_by'], 'Payroll correction approved', "Correction #$aid was approved.", BASE_PATH . 'modules/payroll/adjustments.php');
            $c = payroll_employee_contact($db, (int)$it['employee_id']);
            if ($c && $c['user_id']) notify_user((int)$c['user_id'], 'Payroll correction approved', 'A correction was applied to your payslip.', BASE_PATH . 'modules/payroll/payslips.php?mine=1');
            if ($c && $S['notify_adjustment_approved'] === '1' && filter_var($c['email'] ?? '', FILTER_VALIDATE_EMAIL)) {
                $lid = payroll_queue_email($db, $c['email'], 'Payroll correction approved',
                    payroll_email_html('Payroll correction approved', ['Hello ' . $c['first_name'] . ', an approved correction was applied to your payslip.', 'Your payslip has been updated and any balance will be paid through a recorded payment.'], payroll_portal_url('modules/payroll/payslips.php?mine=1'), 'View my payslips'),
                    'adjustment_approved', 'payroll_adjustments', $aid);
                payroll_dispatch_email($db, $lid);
            }
            payroll_redirect('adjustments.php', 'Correction approved and applied. A new approval record and audit entry were saved.');
        }
    } catch (Throwable $e) {
        if ($db->inTransaction()) $db->rollBack();
        $error_message = $e->getMessage();
    }
}

$adjs = $db->query("SELECT a.*, p.period_name, e.first_name, e.last_name, u1.full_name AS requester, u2.full_name AS decider
    FROM payroll_adjustments a JOIN payroll_items i ON i.id=a.item_id JOIN employees e ON e.id=i.employee_id
    JOIN payroll_runs r ON r.id=a.run_id JOIN payroll_periods p ON p.id=r.period_id
    LEFT JOIN users u1 ON u1.id=a.requested_by LEFT JOIN users u2 ON u2.id=a.decided_by ORDER BY a.id DESC LIMIT 200")->fetchAll();
$targets = $canRequest ? $db->query("SELECT i.id, i.net_pay, e.first_name, e.last_name, p.period_name FROM payroll_items i JOIN payroll_runs r ON r.id=i.run_id JOIN payroll_periods p ON p.id=r.period_id JOIN employees e ON e.id=i.employee_id WHERE r.status IN ('finalized','partially_paid','paid') ORDER BY p.start_date DESC, e.last_name LIMIT 500")->fetchAll() : [];

$pageTitle = 'Payroll Corrections & Adjustments';
$pageIcon = 'fa-pen-to-square';
include __DIR__ . '/_layout_top.php';
?>
<div class="alert alert-info small">Finalized payroll is never edited directly. A correction is requested, approved by an authorized approver, then applied as a separate adjustment line with before/after figures, an approval record and an audit log entry.</div>
<?php if ($canRequest): ?>
<div class="card shadow-sm mb-4"><div class="card-header bg-white"><strong>Request a correction</strong></div><div class="card-body">
<form method="POST" class="row g-2" data-confirm="Submit this correction request for approval?"><?php echo csrf_field(); ?><input type="hidden" name="action" value="request">
    <div class="col-md-5"><label class="form-label small mb-0">Employee / period</label><select name="item_id" class="form-select" required><option value="">Choose…</option><?php foreach ($targets as $t): ?><option value="<?php echo (int)$t['id']; ?>"><?php echo h($t['period_name'] . ' — ' . $t['first_name'] . ' ' . $t['last_name'] . ' (net ' . payroll_money($t['net_pay']) . ')'); ?></option><?php endforeach; ?></select></div>
    <div class="col-md-2"><label class="form-label small mb-0">Type</label><select name="adj_type" class="form-select"><option value="earning">Add earning</option><option value="deduction">Add deduction</option></select></div>
    <div class="col-md-3"><label class="form-label small mb-0">Description</label><input type="text" name="description" class="form-control" maxlength="150" required></div>
    <div class="col-md-2"><label class="form-label small mb-0">Amount ₱</label><input type="number" step="0.01" min="0.01" name="amount" class="form-control" required></div>
    <div class="col-md-10"><label class="form-label small mb-0">Reason (required)</label><input type="text" name="reason" class="form-control" maxlength="500" required></div>
    <div class="col-md-2 d-flex align-items-end"><button class="btn btn-primary w-100">Submit</button></div>
</form></div></div>
<?php endif; ?>
<div class="card shadow-sm"><div class="table-responsive"><table class="table table-hover align-middle mb-0">
<thead class="table-light"><tr><th>#</th><th>Employee / period</th><th>Correction</th><th class="text-end">Amount</th><th>Requested</th><th>Status</th><th>Net before → after</th><th></th></tr></thead><tbody>
<?php if (!$adjs): ?><tr><td colspan="8" class="text-center text-muted py-4">No corrections yet.</td></tr><?php endif; ?>
<?php foreach ($adjs as $a): ?>
<tr>
    <td><?php echo (int)$a['id']; ?></td>
    <td><strong><?php echo h($a['first_name'] . ' ' . $a['last_name']); ?></strong><div class="small text-muted"><?php echo h($a['period_name']); ?></div></td>
    <td><?php echo $a['adj_type'] === 'earning' ? '<span class="badge bg-success">Earning</span>' : '<span class="badge bg-danger">Deduction</span>'; ?> <?php echo h($a['description']); ?><div class="small text-muted"><?php echo h($a['reason']); ?></div></td>
    <td class="text-end"><?php echo h(payroll_money($a['amount'])); ?></td>
    <td class="small"><?php echo h($a['requester'] ?: '—'); ?><br><?php echo h(date('M d, Y', strtotime($a['requested_at']))); ?></td>
    <td><?php echo $a['status'] === 'approved' ? '<span class="badge bg-success">Approved</span>' : ($a['status'] === 'rejected' ? '<span class="badge bg-danger">Rejected</span>' : '<span class="badge bg-warning text-dark">Pending</span>'); ?><?php if ($a['decider']): ?><div class="small text-muted">by <?php echo h($a['decider']); ?></div><?php endif; ?><?php if ($a['decision_note']): ?><div class="small text-muted"><?php echo h($a['decision_note']); ?></div><?php endif; ?></td>
    <td class="small"><?php echo $a['net_before'] !== null ? h(payroll_money($a['net_before'])) . ' → ' . h(payroll_money($a['net_after'])) : '—'; ?></td>
    <td class="text-end"><?php if ($a['status'] === 'pending' && $canDecide): ?>
        <form method="POST" class="d-flex gap-1"><?php echo csrf_field(); ?><input type="hidden" name="action" value="decide"><input type="hidden" name="adjustment_id" value="<?php echo (int)$a['id']; ?>">
            <input type="text" name="note" class="form-control form-control-sm" placeholder="Note" maxlength="500" style="min-width:120px">
            <button name="decision" value="approve" class="btn btn-sm btn-success" onclick="return confirm('Approve and apply this correction?')">Approve</button>
            <button name="decision" value="reject" class="btn btn-sm btn-outline-danger" onclick="return confirm('Reject this correction?')">Reject</button>
        </form><?php endif; ?></td>
</tr>
<?php endforeach; ?>
</tbody></table></div></div>
<?php include __DIR__ . '/_layout_bottom.php';
