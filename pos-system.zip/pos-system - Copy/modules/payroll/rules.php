<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/payroll.php';
require_permission('configure_payroll');
verify_csrf();
$db = getDB();
payroll_ensure_schema($db);
$success_message = null;
$error_message = null;
$leaveTypes = ['sick', 'vacation', 'emergency', 'maternity', 'paternity', 'bereavement'];

function rules_num($v, float $min, float $max): ?float {
    if ($v === null || $v === '' || !is_numeric($v)) return null;
    $n = (float)$v;
    return ($n >= $min && $n <= $max) ? $n : null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'save_settings') {
            $name = trim($_POST['company_name'] ?? '');
            $addr = trim($_POST['company_address'] ?? '');
            $ss = $_POST['shift_start'] ?? '';
            $se = $_POST['shift_end'] ?? '';
            if ($name === '' || strlen($name) > 100) throw new Exception('Company name is required (max 100 characters).');
            if (strlen($addr) > 200) throw new Exception('Company address is too long.');
            if (!preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $ss) || !preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $se) || $se <= $ss) throw new Exception('Shift times must be valid and the shift must end after it starts.');
            $grace = rules_num($_POST['grace_minutes'] ?? null, 0, 120);
            $hours = rules_num($_POST['standard_hours_per_day'] ?? null, 1, 24);
            $factor = rules_num($_POST['days_per_month_factor'] ?? null, 1, 31);
            $mult = rules_num($_POST['ot_multiplier'] ?? null, 1, 3);
            if ($grace === null || $hours === null || $factor === null || $mult === null) throw new Exception('Grace minutes (0-120), hours/day (1-24), days/month factor (1-31) and OT multiplier (1-3) must be valid numbers.');
            $wd = array_values(array_unique(array_filter(array_map('intval', (array)($_POST['weekdays'] ?? [])), function ($d) { return $d >= 1 && $d <= 7; })));
            if (!$wd) throw new Exception('Select at least one working day.');
            sort($wd);
            $unpaid = array_values(array_intersect((array)($_POST['unpaid_leave'] ?? []), $leaveTypes));
            $vals = [
                'company_name' => $name, 'company_address' => $addr, 'shift_start' => $ss, 'shift_end' => $se,
                'grace_minutes' => (string)(int)$grace, 'standard_hours_per_day' => (string)$hours, 'days_per_month_factor' => (string)$factor,
                'working_weekdays' => implode(',', $wd), 'ot_multiplier' => (string)$mult, 'unpaid_leave_types' => implode(',', $unpaid),
                'notify_finalized' => isset($_POST['notify_finalized']) ? '1' : '0',
                'notify_payslip_available' => isset($_POST['notify_payslip_available']) ? '1' : '0',
                'notify_payment_recorded' => isset($_POST['notify_payment_recorded']) ? '1' : '0',
                'notify_adjustment_approved' => isset($_POST['notify_adjustment_approved']) ? '1' : '0',
            ];
            $up = $db->prepare("INSERT INTO payroll_settings(setting_key,setting_value,updated_by) VALUES(?,?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value), updated_by=VALUES(updated_by)");
            foreach ($vals as $k => $v) $up->execute([$k, $v, $_SESSION['user_id']]);
            logActivity('Payroll: settings updated (' . json_encode($vals) . ')');
            payroll_redirect('rules.php', 'Payroll settings saved.');
        } elseif ($action === 'add_rule') {
            $type = $_POST['rule_type'] ?? '';
            $label = trim($_POST['label'] ?? '');
            $eff = $_POST['effective_from'] ?? '';
            if (!in_array($type, ['sss', 'philhealth', 'pagibig', 'tax'], true)) throw new Exception('Choose a rule type.');
            if ($label === '' || strlen($label) > 100) throw new Exception('Label is required (max 100 characters).');
            if (!payroll_is_date($eff)) throw new Exception('Effective date is not valid.');
            $rate = rules_num($_POST['rate_percent'] ?? '0', 0, 100);
            $fixed = rules_num($_POST['fixed_amount'] ?? '0', 0, 99999999);
            if ($rate === null || $fixed === null) throw new Exception('Rate must be 0-100 and fixed amount must be 0 or more.');
            $rf = 0.0; $rt = null; $minb = null; $maxb = null;
            if ($type === 'tax') {
                $rf = rules_num($_POST['range_from'] ?? '', 0, 999999999);
                if ($rf === null) throw new Exception('Tax brackets need a valid "from" amount.');
                if (trim($_POST['range_to'] ?? '') !== '') {
                    $rt = rules_num($_POST['range_to'], 0, 999999999);
                    if ($rt === null || $rt <= $rf) throw new Exception('Bracket "to" must be greater than "from" (leave empty for the top bracket).');
                }
            } else {
                if (trim($_POST['min_base'] ?? '') !== '') { $minb = rules_num($_POST['min_base'], 0, 999999999); if ($minb === null) throw new Exception('Minimum base is not valid.'); }
                if (trim($_POST['max_base'] ?? '') !== '') { $maxb = rules_num($_POST['max_base'], 0, 999999999); if ($maxb === null) throw new Exception('Maximum base is not valid.'); }
                if ($minb !== null && $maxb !== null && $maxb < $minb) throw new Exception('Maximum base cannot be lower than minimum base.');
            }
            $db->prepare("INSERT INTO payroll_rules(rule_type,label,effective_from,range_from,range_to,rate_percent,fixed_amount,min_base,max_base,notes,created_by) VALUES(?,?,?,?,?,?,?,?,?,?,?)")
               ->execute([$type, $label, $eff, $rf, $rt, $rate, $fixed, $minb, $maxb, substr(trim($_POST['notes'] ?? ''), 0, 255), $_SESSION['user_id']]);
            logActivity("Payroll: added $type rule '$label' effective $eff (rate $rate%, fixed $fixed)");
            payroll_redirect('rules.php', 'Rule added. It applies to payroll periods ending on/after the effective date.');
        } elseif ($action === 'toggle_rule') {
            $rid = (int)($_POST['rule_id'] ?? 0);
            $db->prepare("UPDATE payroll_rules SET is_active=1-is_active WHERE id=?")->execute([$rid]);
            logActivity("Payroll: toggled rule #$rid active flag");
            payroll_redirect('rules.php', 'Rule updated.');
        }
    } catch (Throwable $e) {
        $error_message = $e->getMessage();
    }
}

$S = payroll_settings($db, true);
$wdSel = array_map('intval', explode(',', $S['working_weekdays']));
$unpaidSel = array_filter(array_map('trim', explode(',', $S['unpaid_leave_types'])), 'strlen');
$rules = $db->query("SELECT * FROM payroll_rules ORDER BY FIELD(rule_type,'sss','philhealth','pagibig','tax'), effective_from DESC, range_from ASC, id DESC")->fetchAll();

$pageTitle = 'Payroll Rates & Settings';
$pageIcon = 'fa-sliders';
include __DIR__ . '/_layout_top.php';
?>
<div class="alert alert-warning">
    <i class="fas fa-triangle-exclamation me-1"></i>
    <strong>Sample values only.</strong> The seeded SSS, PhilHealth, Pag-IBIG and withholding-tax rows are demo figures. Rules are effective-dated: add a new row with a new effective date instead of editing history, and verify every figure against the official tables before real use.
</div>

<div class="row g-4">
<div class="col-lg-5">
<form method="POST" class="card shadow-sm" data-confirm="Save payroll settings? They apply to the next calculation.">
    <?php echo csrf_field(); ?><input type="hidden" name="action" value="save_settings">
    <div class="card-header bg-white"><strong>Payroll settings</strong></div>
    <div class="card-body">
        <div class="mb-2"><label class="form-label">Company name (payslip)</label><input type="text" name="company_name" class="form-control" maxlength="100" value="<?php echo h($S['company_name']); ?>" required></div>
        <div class="mb-3"><label class="form-label">Company address</label><input type="text" name="company_address" class="form-control" maxlength="200" value="<?php echo h($S['company_address']); ?>"></div>
        <div class="row g-2 mb-3">
            <div class="col-6"><label class="form-label">Shift start</label><input type="time" name="shift_start" class="form-control" value="<?php echo h($S['shift_start']); ?>" required></div>
            <div class="col-6"><label class="form-label">Shift end</label><input type="time" name="shift_end" class="form-control" value="<?php echo h($S['shift_end']); ?>" required></div>
            <div class="col-6"><label class="form-label">Late grace (minutes)</label><input type="number" name="grace_minutes" min="0" max="120" class="form-control" value="<?php echo h($S['grace_minutes']); ?>"></div>
            <div class="col-6"><label class="form-label">Paid hours / day</label><input type="number" step="0.25" name="standard_hours_per_day" min="1" max="24" class="form-control" value="<?php echo h($S['standard_hours_per_day']); ?>"></div>
            <div class="col-6"><label class="form-label">Days / month factor</label><input type="number" step="0.01" name="days_per_month_factor" min="1" max="31" class="form-control" value="<?php echo h($S['days_per_month_factor']); ?>"><div class="form-text">26.08 for Mon–Sat weeks, 21.75 for Mon–Fri. Match your working days below.</div></div>
            <div class="col-6"><label class="form-label">Overtime multiplier</label><input type="number" step="0.01" name="ot_multiplier" min="1" max="3" class="form-control" value="<?php echo h($S['ot_multiplier']); ?>"></div>
        </div>
        <label class="form-label d-block">Working days</label>
        <div class="mb-3"><?php foreach ([1 => 'Mon', 2 => 'Tue', 3 => 'Wed', 4 => 'Thu', 5 => 'Fri', 6 => 'Sat', 7 => 'Sun'] as $n => $l): ?>
            <div class="form-check form-check-inline"><input class="form-check-input" type="checkbox" name="weekdays[]" value="<?php echo $n; ?>" id="wd<?php echo $n; ?>"<?php echo in_array($n, $wdSel, true) ? ' checked' : ''; ?>><label class="form-check-label" for="wd<?php echo $n; ?>"><?php echo $l; ?></label></div>
        <?php endforeach; ?></div>
        <label class="form-label d-block">Leave types treated as <u>unpaid</u></label>
        <div class="mb-3"><?php foreach ($leaveTypes as $lt): ?>
            <div class="form-check form-check-inline"><input class="form-check-input" type="checkbox" name="unpaid_leave[]" value="<?php echo $lt; ?>" id="ul_<?php echo $lt; ?>"<?php echo in_array($lt, $unpaidSel, true) ? ' checked' : ''; ?>><label class="form-check-label" for="ul_<?php echo $lt; ?>"><?php echo ucfirst($lt); ?></label></div>
        <?php endforeach; ?><div class="form-text">Approved leave of other types is paid.</div></div>
        <label class="form-label d-block">Email notifications</label>
        <?php foreach (['notify_finalized' => 'Payroll finalized → payroll/HR staff', 'notify_payslip_available' => 'Payslip available → employee', 'notify_payment_recorded' => 'Payment recorded → employee', 'notify_adjustment_approved' => 'Correction approved → staff + employee'] as $k => $l): ?>
            <div class="form-check"><input class="form-check-input" type="checkbox" name="<?php echo $k; ?>" id="<?php echo $k; ?>"<?php echo $S[$k] === '1' ? ' checked' : ''; ?>><label class="form-check-label" for="<?php echo $k; ?>"><?php echo h($l); ?></label></div>
        <?php endforeach; ?>
        <button class="btn btn-primary mt-3"><i class="fas fa-save me-1"></i> Save settings</button>
    </div>
</form>
</div>

<div class="col-lg-7">
<div class="card shadow-sm mb-4"><div class="card-header bg-white"><strong>Add a rule / bracket</strong></div><div class="card-body">
<form method="POST" class="row g-2">
    <?php echo csrf_field(); ?><input type="hidden" name="action" value="add_rule">
    <div class="col-md-4"><label class="form-label small mb-0">Type</label><select name="rule_type" class="form-select"><option value="sss">SSS</option><option value="philhealth">PhilHealth</option><option value="pagibig">Pag-IBIG</option><option value="tax">Withholding tax (monthly bracket)</option></select></div>
    <div class="col-md-5"><label class="form-label small mb-0">Label</label><input type="text" name="label" class="form-control" maxlength="100" required></div>
    <div class="col-md-3"><label class="form-label small mb-0">Effective from</label><input type="date" name="effective_from" class="form-control" required></div>
    <div class="col-md-3"><label class="form-label small mb-0">Employee rate %</label><input type="number" step="0.0001" min="0" max="100" name="rate_percent" class="form-control" value="0"></div>
    <div class="col-md-3"><label class="form-label small mb-0">Fixed amount ₱</label><input type="number" step="0.01" min="0" name="fixed_amount" class="form-control" value="0"></div>
    <div class="col-md-3"><label class="form-label small mb-0">Min base (contrib.)</label><input type="number" step="0.01" min="0" name="min_base" class="form-control"></div>
    <div class="col-md-3"><label class="form-label small mb-0">Max base (contrib.)</label><input type="number" step="0.01" min="0" name="max_base" class="form-control"></div>
    <div class="col-md-3"><label class="form-label small mb-0">Tax: from ₱ / month</label><input type="number" step="0.01" min="0" name="range_from" class="form-control"></div>
    <div class="col-md-3"><label class="form-label small mb-0">Tax: up to ₱ (blank = open)</label><input type="number" step="0.01" min="0" name="range_to" class="form-control"></div>
    <div class="col-md-6"><label class="form-label small mb-0">Notes / source</label><input type="text" name="notes" class="form-control" maxlength="255"></div>
    <div class="col-12 form-text">Contributions = rate × monthly basic (clamped between min/max base) + fixed amount, spread over the pay periods in a month. Tax = fixed amount + rate × (taxable monthly income − bracket "from"); taxable income here = monthly basic − employee contributions.</div>
    <div class="col-12"><button class="btn btn-primary">Add rule</button></div>
</form></div></div>

<div class="card shadow-sm"><div class="card-header bg-white"><strong>Configured rules</strong></div>
<div class="table-responsive"><table class="table table-sm align-middle mb-0">
<thead class="table-light"><tr><th>Type</th><th>Effective</th><th>Rate</th><th>Fixed</th><th>Base / Range</th><th>Status</th><th></th></tr></thead><tbody>
<?php foreach ($rules as $r): ?>
<tr class="<?php echo $r['is_active'] ? '' : 'text-muted'; ?>">
    <td><strong><?php echo h(strtoupper($r['rule_type'])); ?></strong><div class="small text-muted"><?php echo h($r['label']); ?></div></td>
    <td><?php echo h(payroll_fmt_date($r['effective_from'])); ?></td>
    <td><?php echo h(rtrim(rtrim(number_format((float)$r['rate_percent'], 4, '.', ''), '0'), '.')); ?>%</td>
    <td><?php echo h(payroll_money($r['fixed_amount'])); ?></td>
    <td class="small"><?php if ($r['rule_type'] === 'tax'): ?><?php echo h(payroll_money($r['range_from'])); ?> – <?php echo $r['range_to'] === null ? 'and above' : h(payroll_money($r['range_to'])); ?><?php else: ?>min <?php echo $r['min_base'] === null ? '—' : h(payroll_money($r['min_base'])); ?> / max <?php echo $r['max_base'] === null ? '—' : h(payroll_money($r['max_base'])); ?><?php endif; ?></td>
    <td><?php echo $r['is_active'] ? '<span class="badge bg-success">Active</span>' : '<span class="badge bg-secondary">Inactive</span>'; ?></td>
    <td class="text-end"><form method="POST" data-confirm="<?php echo $r['is_active'] ? 'Deactivate' : 'Activate'; ?> this rule?"><?php echo csrf_field(); ?><input type="hidden" name="action" value="toggle_rule"><input type="hidden" name="rule_id" value="<?php echo (int)$r['id']; ?>"><button class="btn btn-sm btn-outline-secondary"><?php echo $r['is_active'] ? 'Deactivate' : 'Activate'; ?></button></form></td>
</tr>
<?php endforeach; ?>
</tbody></table></div></div>
</div>
</div>
<?php include __DIR__ . '/_layout_bottom.php';
