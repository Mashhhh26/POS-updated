<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/payroll.php';
require_permission('view_payroll');
verify_csrf();
$db = getDB();
payroll_ensure_schema($db);
$success_message = null;
$error_message = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'create_period') {
            require_permission('process_payroll');
            $name = trim($_POST['period_name'] ?? '');
            $start = $_POST['start_date'] ?? '';
            $end = $_POST['end_date'] ?? '';
            $pay = $_POST['pay_date'] ?? '';
            $deadline = trim($_POST['deadline_date'] ?? '');
            $sched = $_POST['pay_schedule'] ?? '';
            if ($name === '' || strlen($name) > 100) throw new Exception('Period name is required (max 100 characters).');
            if (!in_array($sched, ['weekly', 'semi_monthly', 'monthly'], true)) throw new Exception('Choose a valid pay schedule.');
            if (!payroll_is_date($start) || !payroll_is_date($end) || !payroll_is_date($pay)) throw new Exception('Start, end and pay dates must be valid dates.');
            if ($end < $start) throw new Exception('End date cannot be before the start date.');
            if ($pay < $start) throw new Exception('Pay date cannot be before the cutoff start.');
            if ($deadline !== '' && !payroll_is_date($deadline)) throw new Exception('Payroll deadline is not a valid date.');
            $ov = $db->prepare("SELECT COUNT(*) FROM payroll_periods WHERE pay_schedule=? AND start_date<=? AND end_date>=?");
            $ov->execute([$sched, $end, $start]);
            if ((int)$ov->fetchColumn() > 0) throw new Exception('This overlaps an existing ' . payroll_schedule_label($sched) . ' period.');
            $db->prepare("INSERT INTO payroll_periods(period_name,start_date,end_date,pay_date,pay_schedule,deadline_date,created_by) VALUES(?,?,?,?,?,?,?)")
               ->execute([$name, $start, $end, $pay, $sched, $deadline !== '' ? $deadline : null, $_SESSION['user_id']]);
            logActivity("Payroll: created period '$name' ($start to $end, $sched)");
            payroll_redirect('periods.php', "Payroll period '$name' created.");
        } elseif ($action === 'create_run') {
            require_permission('process_payroll');
            $pid = (int)($_POST['period_id'] ?? 0);
            $pq = $db->prepare("SELECT * FROM payroll_periods WHERE id=?");
            $pq->execute([$pid]);
            $period = $pq->fetch();
            if (!$period) throw new Exception('Period not found.');
            $ex = $db->prepare("SELECT COUNT(*) FROM payroll_runs WHERE period_id=? AND status<>'cancelled'");
            $ex->execute([$pid]);
            if ((int)$ex->fetchColumn() > 0) throw new Exception('This period already has an active payroll run.');
            $db->prepare("INSERT INTO payroll_runs(period_id,status,prepared_by) VALUES(?, 'draft', ?)")->execute([$pid, $_SESSION['user_id']]);
            $runId = (int)$db->lastInsertId();
            payroll_log_approval($db, $runId, 'created', null, 'draft', 'Payroll run opened');
            logActivity("Payroll: opened run #$runId for period '{$period['period_name']}'");
            payroll_redirect('run.php', 'Payroll run opened. Next: collect time records.', null, ['id' => $runId]);
        }
    } catch (Throwable $e) {
        $error_message = $e->getMessage();
    }
}

$periods = $db->query("SELECT p.*, r.id AS run_id, r.status AS run_status, r.total_gross, r.total_net, r.finalized_at,
        (SELECT COUNT(*) FROM payroll_items i WHERE i.run_id=r.id) AS emp_count, u.full_name AS creator
    FROM payroll_periods p
    LEFT JOIN payroll_runs r ON r.id=(SELECT MAX(id) FROM payroll_runs WHERE period_id=p.id)
    LEFT JOIN users u ON u.id=p.created_by
    ORDER BY p.start_date DESC, p.id DESC LIMIT 200")->fetchAll();

$stat = ['open' => 0, 'unpaid' => 0, 'paid' => 0];
foreach ($periods as $p) {
    $st = $p['run_status'];
    if (in_array($st, ['draft', 'for_review', 'for_approval', 'approved'], true)) $stat['open']++;
    elseif (in_array($st, ['finalized', 'partially_paid'], true)) $stat['unpaid']++;
    elseif ($st === 'paid') $stat['paid']++;
}
$canProcess = hasPermission('process_payroll');

$pageTitle = 'Payroll Periods';
$pageIcon = 'fa-coins';
$pageActions = $canProcess ? '<button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#periodModal"><i class="fas fa-plus-circle me-1"></i> New Payroll Period</button>' : '';
include __DIR__ . '/_layout_top.php';
?>
<div class="alert alert-warning small">
    <i class="fas fa-triangle-exclamation me-1"></i>
    Government contribution and tax tables are <strong>sample values for demo use</strong>. Validate them in <em>Rates &amp; Settings</em> before processing real salaries.
</div>

<div class="row g-3 mb-4">
    <div class="col-md-4"><div class="card shadow-sm"><div class="card-body"><div class="text-muted small">In progress (Draft → Approved)</div><div class="fs-3 fw-bold"><?php echo $stat['open']; ?></div></div></div></div>
    <div class="col-md-4"><div class="card shadow-sm"><div class="card-body"><div class="text-muted small">Finalized, awaiting payment</div><div class="fs-3 fw-bold"><?php echo $stat['unpaid']; ?></div></div></div></div>
    <div class="col-md-4"><div class="card shadow-sm"><div class="card-body"><div class="text-muted small">Fully paid</div><div class="fs-3 fw-bold"><?php echo $stat['paid']; ?></div></div></div></div>
</div>

<div class="card shadow-sm">
    <div class="card-header bg-white"><strong>Payroll periods &amp; history</strong></div>
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light"><tr>
                <th>Period</th><th>Coverage</th><th>Pay date</th><th>Schedule</th><th class="text-end">Employees</th><th class="text-end">Gross</th><th class="text-end">Net</th><th>Status</th><th></th>
            </tr></thead>
            <tbody>
            <?php if (!$periods): ?>
                <tr><td colspan="9" class="text-center text-muted py-4">No payroll periods yet.</td></tr>
            <?php endif; ?>
            <?php foreach ($periods as $p): ?>
                <tr>
                    <td><strong><?php echo h($p['period_name']); ?></strong><?php if ($p['deadline_date']): ?><div class="small text-muted">Deadline <?php echo h(payroll_fmt_date($p['deadline_date'])); ?></div><?php endif; ?></td>
                    <td><?php echo h(payroll_fmt_date($p['start_date'])); ?> – <?php echo h(payroll_fmt_date($p['end_date'])); ?></td>
                    <td><?php echo h(payroll_fmt_date($p['pay_date'])); ?></td>
                    <td><?php echo h(payroll_schedule_label($p['pay_schedule'])); ?></td>
                    <td class="text-end"><?php echo $p['run_id'] ? (int)$p['emp_count'] : '—'; ?></td>
                    <td class="text-end"><?php echo $p['run_id'] ? h(payroll_money($p['total_gross'])) : '—'; ?></td>
                    <td class="text-end"><?php echo $p['run_id'] ? h(payroll_money($p['total_net'])) : '—'; ?></td>
                    <td><?php echo $p['run_id'] ? payroll_status_badge($p['run_status']) : '<span class="badge bg-light text-dark border">No run yet</span>'; ?></td>
                    <td class="text-end">
                        <?php if ($p['run_id']): ?>
                            <a class="btn btn-sm btn-outline-primary" href="run.php?id=<?php echo (int)$p['run_id']; ?>"><i class="fas fa-folder-open me-1"></i> Open</a>
                        <?php endif; ?>
                        <?php if ($canProcess && (!$p['run_id'] || $p['run_status'] === 'cancelled')): ?>
                            <form method="POST" class="d-inline" data-confirm="Open a new payroll run for this period?">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="action" value="create_run">
                                <input type="hidden" name="period_id" value="<?php echo (int)$p['id']; ?>">
                                <button class="btn btn-sm btn-primary"><i class="fas fa-play me-1"></i> Open payroll run</button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php if ($canProcess): ?>
<div class="modal fade" id="periodModal" tabindex="-1">
  <div class="modal-dialog modal-lg"><div class="modal-content">
    <form method="POST">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="action" value="create_period">
      <div class="modal-header"><h5 class="modal-title">New Payroll Period</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body">
        <div class="row g-3">
          <div class="col-12"><div class="p-2 border rounded bg-light small">
            <strong>Quick fill:</strong>
            <div class="row g-2 mt-1">
              <div class="col-md-6"><input type="month" id="pm" class="form-control form-control-sm"></div>
              <div class="col-md-6"><select id="pt" class="form-select form-select-sm"><option value="">Choose cutoff…</option><option value="first">1st – 15th (semi-monthly)</option><option value="second">16th – end of month (semi-monthly)</option><option value="whole">Whole month (monthly)</option></select></div>
            </div>
          </div></div>
          <div class="col-md-8"><label class="form-label">Period name *</label><input type="text" name="period_name" id="f_name" class="form-control" maxlength="100" required></div>
          <div class="col-md-4"><label class="form-label">Pay schedule *</label>
            <select name="pay_schedule" id="f_sched" class="form-select" required>
              <option value="semi_monthly">Semi-monthly</option><option value="monthly">Monthly</option><option value="weekly">Weekly</option>
            </select></div>
          <div class="col-md-3"><label class="form-label">Cutoff start *</label><input type="date" name="start_date" id="f_start" class="form-control" required></div>
          <div class="col-md-3"><label class="form-label">Cutoff end *</label><input type="date" name="end_date" id="f_end" class="form-control" required></div>
          <div class="col-md-3"><label class="form-label">Pay date *</label><input type="date" name="pay_date" id="f_pay" class="form-control" required></div>
          <div class="col-md-3"><label class="form-label">Payroll deadline</label><input type="date" name="deadline_date" class="form-control"></div>
        </div>
      </div>
      <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary">Create period</button></div>
    </form>
  </div></div>
</div>
<?php
$pageScript = <<<'JS'
<script>
(function(){
  var m=document.getElementById('pm'), t=document.getElementById('pt');
  function pad(n){return String(n).padStart(2,'0');}
  function fill(){
    if(!m.value||!t.value)return;
    var p=m.value.split('-'), y=parseInt(p[0],10), mo=parseInt(p[1],10), last=new Date(y,mo,0).getDate();
    var s,e,sch,label;
    if(t.value==='first'){s=1;e=15;sch='semi_monthly';label='1st cutoff';}
    else if(t.value==='second'){s=16;e=last;sch='semi_monthly';label='2nd cutoff';}
    else {s=1;e=last;sch='monthly';label='Monthly';}
    var mn=new Date(y,mo-1,1).toLocaleString('en',{month:'long'});
    document.getElementById('f_name').value=mn+' '+y+' - '+label;
    document.getElementById('f_sched').value=sch;
    document.getElementById('f_start').value=y+'-'+pad(mo)+'-'+pad(s);
    document.getElementById('f_end').value=y+'-'+pad(mo)+'-'+pad(e);
    document.getElementById('f_pay').value=y+'-'+pad(mo)+'-'+pad(e);
  }
  m.addEventListener('change',fill); t.addEventListener('change',fill);
})();
</script>
JS;
endif;
include __DIR__ . '/_layout_bottom.php';
