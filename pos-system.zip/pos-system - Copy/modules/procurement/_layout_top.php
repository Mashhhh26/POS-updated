<?php
if (!defined('BASE_PATH') || !isset($pageTitle)) { http_response_code(403); exit('Forbidden'); }
// Shared page shell for the payroll pages. Expects $pageTitle and $pageIcon.
$success_message = $success_message ?? (isset($_GET['ok']) ? $_GET['ok'] : null);
$error_message = $error_message ?? (isset($_GET['err']) ? $_GET['err'] : null);
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light" data-pos-theme="light" data-pos-palette="indigo">
<head>
<script>
(function(){try{var t=localStorage.getItem('pos_theme');var p=localStorage.getItem('pos_palette');if(t==='dark'||t==='light')document.documentElement.setAttribute('data-pos-theme',t);if(['indigo','blue','emerald','violet','rose','amber'].indexOf(p)!==-1)document.documentElement.setAttribute('data-pos-palette',p);}catch(e){}})();
</script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo h($pageTitle); ?> - Procurement</title>
    <link href="<?php echo BASE_PATH; ?>assets/vendor/bootstrap/bootstrap.min.css?v=20261010" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo BASE_PATH; ?>assets/vendor/fontawesome/all.min.css?v=20261010">
    <link rel="stylesheet" href="<?php echo BASE_PATH; ?>assets/css/custom.css?v=20261010">
</head>
<body>
    <?php include BASE_PATH . 'includes/header.php'; ?>
    <div class="d-flex">
        <?php include BASE_PATH . 'includes/sidebar.php'; ?>
        <div class="main-content flex-grow-1 p-4">
            <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
                <h4 class="mb-0"><i class="fas <?php echo h($pageIcon); ?> me-2 text-primary"></i> <?php echo h($pageTitle); ?></h4>
                <?php if (!empty($pageActions)) echo $pageActions; ?>
            </div>
            <?php if ($success_message): ?>
                <div id="flash-message" data-type="success" data-message="<?php echo h($success_message); ?>"></div>
            <?php endif; ?>
            <?php if ($error_message): ?>
                <div id="flash-message" data-type="error" data-message="<?php echo h($error_message); ?>"></div>
            <?php endif; ?>
