<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/supplier_portal.php';
require_permission('manage_supplier_accounts');
verify_csrf();
$db = getDB();
sp_ensure_schema($db);
$success_message = null;
$error_message = null;

$userCols = $db->query("SHOW COLUMNS FROM users")->fetchAll(PDO::FETCH_COLUMN);
$hasStatusCol = in_array('account_status', $userCols, true);
$hasReasonCol = in_array('deactivation_reason', $userCols, true);

// Invitation links are shown once (never stored, never emailed together with a password).
$invite = $_SESSION['sp_invite'] ?? null;
unset($_SESSION['sp_invite']);

function sa_owned_user(PDO $db, int $userId, int $supplierId) {
    $q = $db->prepare("SELECT u.* FROM supplier_accounts a JOIN users u ON u.id=a.user_id WHERE a.user_id=? AND a.supplier_id=?");
    $q->execute([$userId, $supplierId]);
    return $q->fetch();
}

function sa_send_invite(PDO $db, array $user, string $raw, string $company, bool $isReset): bool {
    $url = sp_portal_url('set_password.php?token=' . $raw);
    $sub = $isReset ? 'Reset your supplier portal password' : 'Your supplier portal account is ready';
    $paras = $isReset
        ? ['Hello ' . $user['full_name'] . ', a password reset was requested for your supplier portal account (' . $user['username'] . ').', 'Use the button below within 72 hours to choose a new password.']
        : ['Hello ' . $user['full_name'] . ', a supplier portal account was created for ' . $company . '.', 'Your username is ' . $user['username'] . '. Use the link below within 72 hours to choose your password.'];
    $res = send_hr_email($user['email'], $sub, sp_email_html($sub, $paras, $url, 'Set my password'));
    return !empty($res['ok']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $supplierId = (int)($_POST['supplier_id'] ?? 0);
    try {
        $sq = $db->prepare("SELECT * FROM suppliers WHERE id=?");
        $sq->execute([$supplierId]);
        $supplier = $sq->fetch();
        if (!$supplier) throw new Exception('Supplier not found.');

        if ($action === 'create_account') {
            $username = strtolower(trim($_POST['username'] ?? ''));
            $fullName = trim($_POST['full_name'] ?? '');
            $email = trim($_POST['email'] ?? '');
            if (!preg_match('/^[a-z0-9._-]{4,40}$/', $username)) throw new Exception('Username must be 4-40 characters: letters, numbers, dot, dash or underscore.');
            if (strlen($fullName) < 2 || strlen($fullName) > 100) throw new Exception('Full name is required (2-100 characters).');
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) throw new Exception('A valid email address is required for the invitation.');
            $dup = $db->prepare("SELECT COUNT(*) FROM users WHERE username=?");
            $dup->execute([$username]);
            if ((int)$dup->fetchColumn() > 0) throw new Exception('That username is already taken.');
            $rid = $db->query("SELECT id FROM roles WHERE role_name='Supplier' LIMIT 1")->fetchColumn();
            if (!$rid) throw new Exception('The Supplier role is missing. Reload this page and try again.');

            $db->beginTransaction();
            $placeholder = password_hash(bin2hex(random_bytes(24)), PASSWORD_DEFAULT);   // unknown to everyone until the invite is used
            if ($hasStatusCol) {
                $db->prepare("INSERT INTO users(username,password,email,full_name,role_id,is_active,account_status) VALUES(?,?,?,?,?,1,'active')")->execute([$username, $placeholder, $email, $fullName, $rid]);
            } else {
                $db->prepare("INSERT INTO users(username,password,email,full_name,role_id,is_active) VALUES(?,?,?,?,?,1)")->execute([$username, $placeholder, $email, $fullName, $rid]);
            }
            $uid = (int)$db->lastInsertId();
            $db->prepare("INSERT INTO supplier_accounts(user_id,supplier_id,created_by) VALUES(?,?,?)")->execute([$uid, $supplierId, $_SESSION['user_id']]);
            $raw = sp_create_token($db, $uid, 'activate', (int)$_SESSION['user_id']);
            $db->commit();

            $emailed = sa_send_invite($db, ['full_name' => $fullName, 'username' => $username, 'email' => $email], $raw, $supplier['company_name'], false);
            $_SESSION['sp_invite'] = ['name' => $fullName, 'username' => $username, 'link' => sp_portal_url('set_password.php?token=' . $raw), 'emailed' => $emailed];
            logActivity("Supplier portal: created account '$username' for {$supplier['company_name']}");
            sa_redirect('Portal account created. Share the invitation link below if the email did not arrive.');
        } elseif ($action === 'reissue') {
            $uid = (int)($_POST['user_id'] ?? 0);
            $user = sa_owned_user($db, $uid, $supplierId);
            if (!$user) throw new Exception('Account not found.');
            if (!$user['is_active']) throw new Exception('Reactivate the account before sending a new link.');
            $raw = sp_create_token($db, $uid, 'reset', (int)$_SESSION['user_id']);
            $emailed = sa_send_invite($db, $user, $raw, $supplier['company_name'], true);
            $_SESSION['sp_invite'] = ['name' => $user['full_name'], 'username' => $user['username'], 'link' => sp_portal_url('set_password.php?token=' . $raw), 'emailed' => $emailed];
            logActivity("Supplier portal: issued a new password link for '{$user['username']}'");
            sa_redirect('New password link created.');
        } elseif ($action === 'deactivate') {
            $uid = (int)($_POST['user_id'] ?? 0);
            $reason = trim($_POST['reason'] ?? '');
            $user = sa_owned_user($db, $uid, $supplierId);
            if (!$user) throw new Exception('Account not found.');
            if (strlen($reason) < 5) throw new Exception('A reason is required to deactivate an account (at least 5 characters).');
            $sets = 'is_active=0';
            $params = [];
            if ($hasStatusCol) $sets .= ", account_status='deactivated'";
            if ($hasReasonCol) { $sets .= ', deactivation_reason=?'; $params[] = substr($reason, 0, 255); }
            $params[] = $uid;
            $db->prepare("UPDATE users SET $sets WHERE id=?")->execute($params);
            $db->prepare("UPDATE password_tokens SET used_at=NOW() WHERE user_id=? AND used_at IS NULL")->execute([$uid]);
            if (filter_var($user['email'], FILTER_VALIDATE_EMAIL)) {
                send_hr_email($user['email'], 'Your supplier portal account was deactivated', sp_email_html('Account deactivated', ['Hello ' . $user['full_name'] . ', your supplier portal account (' . $user['username'] . ') has been deactivated.', 'Reason: ' . $reason, 'Contact the procurement team if you believe this is a mistake.']));
            }
            logActivity("Supplier portal: deactivated '{$user['username']}' - $reason");
            sa_redirect('Account deactivated. The supplier was notified by email.');
        } elseif ($action === 'reactivate') {
            $uid = (int)($_POST['user_id'] ?? 0);
            $user = sa_owned_user($db, $uid, $supplierId);
            if (!$user) throw new Exception('Account not found.');
            $sets = 'is_active=1';
            if ($hasStatusCol) $sets .= ", account_status='active'";
            if ($hasReasonCol) $sets .= ', deactivation_reason=NULL';
            $db->prepare("UPDATE users SET $sets WHERE id=?")->execute([$uid]);
            if (filter_var($user['email'], FILTER_VALIDATE_EMAIL)) {
                send_hr_email($user['email'], 'Your supplier portal account is active again', sp_email_html('Account activated', ['Hello ' . $user['full_name'] . ', your supplier portal account (' . $user['username'] . ') is active again.'], sp_portal_url('login.php'), 'Go to login'));
            }
            logActivity("Supplier portal: reactivated '{$user['username']}'");
            sa_redirect('Account reactivated.');
        }
    } catch (Throwable $e) {
        if ($db->inTransaction()) $db->rollBack();
        $error_message = $e->getMessage();
    }
}

function sa_redirect(string $ok): void {
    header('Location: supplier_accounts.php?ok=' . urlencode($ok));
    exit();
}

$suppliers = $db->query("SELECT id, supplier_code, company_name, contact_person, email, is_active FROM suppliers ORDER BY company_name")->fetchAll();
$accRows = $db->query("SELECT a.supplier_id, u.id AS user_id, u.username, u.full_name, u.email, u.is_active,
        (SELECT COUNT(*) FROM password_tokens t WHERE t.user_id=u.id AND t.used_at IS NULL AND t.expires_at>NOW()) AS invite_open
    FROM supplier_accounts a JOIN users u ON u.id=a.user_id ORDER BY u.username")->fetchAll();
$accounts = [];
foreach ($accRows as $r) $accounts[(int)$r['supplier_id']][] = $r;
if (isset($_GET['ok'])) $success_message = $_GET['ok'];

$pageTitle = 'Supplier Portal Accounts';
$pageIcon = 'fa-id-badge';
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light" data-pos-theme="light" data-pos-palette="indigo">
<head>
<script>(function(){try{var t=localStorage.getItem('pos_theme');var p=localStorage.getItem('pos_palette');if(t==='dark'||t==='light')document.documentElement.setAttribute('data-pos-theme',t);if(['indigo','blue','emerald','violet','rose','amber'].indexOf(p)!==-1)document.documentElement.setAttribute('data-pos-palette',p);}catch(e){}})();</script>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supplier Portal Accounts</title>
    <link href="<?php echo BASE_PATH; ?>assets/vendor/bootstrap/bootstrap.min.css?v=20261010" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo BASE_PATH; ?>assets/vendor/fontawesome/all.min.css?v=20261010">
    <link rel="stylesheet" href="<?php echo BASE_PATH; ?>assets/css/custom.css?v=20261010">
</head>
<body>
<?php include BASE_PATH . 'includes/header.php'; ?>
<div class="d-flex">
<?php include BASE_PATH . 'includes/sidebar.php'; ?>
<div class="main-content flex-grow-1 p-4">
    <div class="d-flex justify-content-between align-items-center mb-4"><h4 class="mb-0"><i class="fas fa-id-badge me-2 text-primary"></i> Supplier Portal Accounts</h4></div>
    <?php if ($success_message): ?><div id="flash-message" data-type="success" data-message="<?php echo h($success_message); ?>"></div><?php endif; ?>
    <?php if ($error_message): ?><div id="flash-message" data-type="error" data-message="<?php echo h($error_message); ?>"></div><?php endif; ?>

    <?php if ($invite): ?>
    <div class="alert alert-success">
        <strong><i class="fas fa-link me-1"></i> Invitation link for <?php echo h($invite['name']); ?> (<?php echo h($invite['username']); ?>)</strong>
        <div class="small mb-2"><?php echo $invite['emailed'] ? 'It was emailed to the supplier.' : 'The email could not be sent (SMTP not configured?). Send this link to the supplier yourself.'; ?> It is valid for 72 hours, works once, and is shown only now.</div>
        <input type="text" class="form-control" readonly value="<?php echo h($invite['link']); ?>" onclick="this.select()">
    </div>
    <?php endif; ?>

    <div class="alert alert-info small">Suppliers never receive a password. Creating an account sends a one-time link where they choose their own password. Accounts can only see purchase orders issued to their own supplier.</div>

    <div class="card"><div class="table-responsive"><table class="table align-middle mb-0">
        <thead><tr><th>Supplier</th><th>Contact</th><th>Portal accounts</th><th></th></tr></thead><tbody>
        <?php if (!$suppliers): ?><tr><td colspan="4" class="text-center text-muted py-4">No suppliers yet.</td></tr><?php endif; ?>
        <?php foreach ($suppliers as $s): $list = $accounts[(int)$s['id']] ?? []; ?>
        <tr>
            <td><strong><?php echo h($s['company_name']); ?></strong><div class="small text-muted"><?php echo h($s['supplier_code']); ?><?php echo $s['is_active'] ? '' : ' · inactive supplier'; ?></div></td>
            <td class="small"><?php echo h($s['contact_person'] ?: '—'); ?><div class="text-muted"><?php echo h($s['email'] ?: 'no email'); ?></div></td>
            <td>
                <?php if (!$list): ?><span class="text-muted small">No portal account</span><?php endif; ?>
                <?php foreach ($list as $a): ?>
                <div class="d-flex flex-wrap align-items-center gap-2 mb-1">
                    <span class="fw-semibold"><?php echo h($a['username']); ?></span>
                    <span class="small text-muted"><?php echo h($a['email']); ?></span>
                    <?php if (!$a['is_active']): ?><span class="badge bg-secondary">Deactivated</span>
                    <?php elseif ((int)$a['invite_open'] > 0): ?><span class="badge bg-warning text-dark">Invite pending</span>
                    <?php else: ?><span class="badge bg-success">Active</span><?php endif; ?>
                    <?php if ($a['is_active']): ?>
                        <form method="POST" class="d-inline" onsubmit="return confirm('Create a new password link for this account?')"><?php echo csrf_field(); ?><input type="hidden" name="action" value="reissue"><input type="hidden" name="supplier_id" value="<?php echo (int)$s['id']; ?>"><input type="hidden" name="user_id" value="<?php echo (int)$a['user_id']; ?>"><button class="btn btn-sm btn-outline-secondary">New link / reset</button></form>
                        <button type="button" class="btn btn-sm btn-outline-danger" onclick="openDeactivate(<?php echo (int)$s['id']; ?>,<?php echo (int)$a['user_id']; ?>,<?php echo h(json_encode($a['username'])); ?>)">Deactivate</button>
                    <?php else: ?>
                        <form method="POST" class="d-inline" onsubmit="return confirm('Reactivate this account?')"><?php echo csrf_field(); ?><input type="hidden" name="action" value="reactivate"><input type="hidden" name="supplier_id" value="<?php echo (int)$s['id']; ?>"><input type="hidden" name="user_id" value="<?php echo (int)$a['user_id']; ?>"><button class="btn btn-sm btn-outline-success">Reactivate</button></form>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </td>
            <td class="text-end"><?php if ($s['is_active']): ?><button class="btn btn-sm btn-primary" onclick="openCreate(<?php echo (int)$s['id']; ?>,<?php echo h(json_encode($s['company_name'])); ?>,<?php echo h(json_encode(strtolower(preg_replace('/[^a-z0-9]/i', '', (string)$s['supplier_code'])))); ?>,<?php echo h(json_encode($s['contact_person'] ?: $s['company_name'])); ?>,<?php echo h(json_encode($s['email'] ?: '')); ?>)"><i class="fas fa-user-plus me-1"></i> Create account</button><?php endif; ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody></table></div></div>
</div></div>

<div class="modal fade" id="createModal" tabindex="-1"><div class="modal-dialog"><div class="modal-content">
    <form method="POST"><?php echo csrf_field(); ?><input type="hidden" name="action" value="create_account"><input type="hidden" name="supplier_id" id="c_sid">
    <div class="modal-header"><h5 class="modal-title">Create portal account <span class="text-muted small" id="c_company"></span></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
    <div class="modal-body">
        <div class="mb-3"><label class="form-label">Username *</label><input type="text" name="username" id="c_user" class="form-control" pattern="[a-z0-9._-]{4,40}" required></div>
        <div class="mb-3"><label class="form-label">Contact full name *</label><input type="text" name="full_name" id="c_name" class="form-control" maxlength="100" required></div>
        <div class="mb-1"><label class="form-label">Email for the invitation *</label><input type="email" name="email" id="c_email" class="form-control" maxlength="100" required></div>
        <div class="form-text">An invitation link is emailed; the supplier chooses their own password.</div>
    </div>
    <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary">Create &amp; send invite</button></div>
    </form></div></div></div>

<div class="modal fade" id="deactModal" tabindex="-1"><div class="modal-dialog"><div class="modal-content">
    <form method="POST"><?php echo csrf_field(); ?><input type="hidden" name="action" value="deactivate"><input type="hidden" name="supplier_id" id="d_sid"><input type="hidden" name="user_id" id="d_uid">
    <div class="modal-header"><h5 class="modal-title">Deactivate <span id="d_name"></span></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
    <div class="modal-body"><label class="form-label">Reason (required) *</label><input type="text" name="reason" class="form-control" maxlength="255" minlength="5" required><div class="form-text">The supplier is notified by email and can no longer log in.</div></div>
    <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button class="btn btn-danger">Deactivate</button></div>
    </form></div></div></div>

<script src="<?php echo BASE_PATH; ?>assets/vendor/sweetalert2/sweetalert2.all.min.js?v=20261010"></script>
<script src="<?php echo BASE_PATH; ?>assets/vendor/bootstrap/bootstrap.bundle.min.js?v=20261010"></script>
<script src="<?php echo BASE_PATH; ?>assets/js/script.js?v=20261010"></script>
<script>
function openCreate(id, company, code, name, email) {
    document.getElementById('c_sid').value = id;
    document.getElementById('c_company').textContent = '— ' + company;
    document.getElementById('c_user').value = code.length >= 4 ? code : (code + 'sup').slice(0, 40);
    document.getElementById('c_name').value = name;
    document.getElementById('c_email').value = email;
    new bootstrap.Modal(document.getElementById('createModal')).show();
}
function openDeactivate(sid, uid, uname) {
    document.getElementById('d_sid').value = sid;
    document.getElementById('d_uid').value = uid;
    document.getElementById('d_name').textContent = uname;
    new bootstrap.Modal(document.getElementById('deactModal')).show();
}
</script>
</body>
</html>
