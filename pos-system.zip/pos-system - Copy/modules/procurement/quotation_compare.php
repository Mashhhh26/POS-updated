<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/supplier_portal.php';
require_permission('view_rfqs');
verify_csrf();
$db = getDB();
sp_ensure_schema($db);
$canManage = hasPermission('manage_rfqs');
$success_message = null;
$error_message = null;
$rfqId = (int)($_POST['rfq_id'] ?? $_GET['rfq_id'] ?? 0);

function qc_back(int $id, string $ok): void { header('Location: quotation_compare.php?rfq_id=' . $id . '&ok=' . urlencode($ok)); exit(); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    try {
        require_permission('manage_rfqs');
        if ($action === 'close_submissions') {
            $u = $db->prepare("UPDATE rfqs SET status='evaluating' WHERE id=? AND status='sent'");
            $u->execute([$rfqId]);
            if ($u->rowCount() === 0) throw new Exception('Only an open RFQ can be closed for evaluation.');
            $db->prepare("UPDATE rfq_suppliers SET status='no_response' WHERE rfq_id=? AND status='invited'")->execute([$rfqId]);
            logActivity("RFQ #$rfqId: supplier submissions closed for evaluation");
            qc_back($rfqId, 'Submissions closed. You can now compare and select a supplier.');
        } elseif ($action === 'select_supplier') {
            $qid = (int)($_POST['quotation_id'] ?? 0);
            $reason = trim($_POST['reason'] ?? '');
            if (strlen($reason) < 10) throw new Exception('Record the reason for this decision (at least 10 characters).');
            $db->beginTransaction();
            $r = $db->prepare("SELECT * FROM rfqs WHERE id=? FOR UPDATE");
            $r->execute([$rfqId]);
            $rfq = $r->fetch();
            if (!$rfq || !in_array($rfq['status'], ['sent', 'evaluating'], true)) throw new Exception('This RFQ is not open for a selection decision.');
            $q = $db->prepare("SELECT q.*, s.company_name FROM quotations q JOIN suppliers s ON s.id=q.supplier_id WHERE q.id=? AND q.rfq_id=? AND q.status IN ('received','evaluating') FOR UPDATE");
            $q->execute([$qid, $rfqId]);
            $win = $q->fetch();
            if (!$win) throw new Exception('Choose one of the submitted quotations.');
            $db->prepare("UPDATE quotations SET status='accepted' WHERE id=?")->execute([$qid]);
            $db->prepare("UPDATE quotations SET status='rejected' WHERE rfq_id=? AND id<>? AND status IN ('received','evaluating')")->execute([$rfqId, $qid]);
            $db->prepare("UPDATE rfqs SET status='awarded', selected_quotation_id=?, selected_supplier_id=?, selection_reason=?, selected_by=?, selected_at=NOW() WHERE id=?")
               ->execute([$qid, $win['supplier_id'], substr($reason, 0, 500), $_SESSION['user_id'], $rfqId]);
            $db->prepare("UPDATE rfq_suppliers SET status='no_response' WHERE rfq_id=? AND status='invited'")->execute([$rfqId]);
            $others = $db->prepare("SELECT q.supplier_id FROM quotations q WHERE q.rfq_id=? AND q.id<>?");
            $others->execute([$rfqId, $qid]);
            $otherIds = $others->fetchAll(PDO::FETCH_COLUMN);
            $db->commit();
            logActivity("RFQ {$rfq['rfq_number']}: supplier selected - {$win['company_name']} (quotation #{$win['quotation_number']}). Reason: $reason");
            sp_notify_supplier($db, (int)$win['supplier_id'], 'Quotation selected', 'Your quotation for ' . $rfq['rfq_number'] . ' was selected. A purchase order will follow.', 'modules/supplier_portal/rfq.php?id=' . $rfqId,
                'Your quotation was selected: ' . $rfq['rfq_number'], ['Your quotation for ' . $rfq['rfq_number'] . ' was selected.', 'A purchase order will be issued to you shortly.']);
            foreach ($otherIds as $oid) {
                sp_notify_supplier($db, (int)$oid, 'Quotation not selected', 'Thank you for quoting on ' . $rfq['rfq_number'] . '. It was not selected this time.', 'modules/supplier_portal/rfq.php?id=' . $rfqId,
                    'RFQ result: ' . $rfq['rfq_number'], ['Thank you for quoting on ' . $rfq['rfq_number'] . '.', 'Your quotation was not selected this time.']);
            }
            qc_back($rfqId, 'Decision recorded: ' . $win['company_name'] . ' selected. Next: create the purchase order in Purchase Orders.');
        }
    } catch (Throwable $e) {
        if ($db->inTransaction()) $db->rollBack();
        $error_message = $e->getMessage();
    }
}

$rfqList = $db->query("SELECT id, rfq_number, title, status FROM rfqs ORDER BY id DESC LIMIT 200")->fetchAll();
$rfq = null; $items = []; $quotes = []; $matrix = []; $reqTotal = 0;
if ($rfqId) {
    $r = $db->prepare("SELECT r.*, u.full_name AS selected_by_name FROM rfqs r LEFT JOIN users u ON u.id=r.selected_by WHERE r.id=?");
    $r->execute([$rfqId]);
    $rfq = $r->fetch();
}
if ($rfq) {
    $items = sp_rfq_items($db, $rfq['requisition_id'] ? (int)$rfq['requisition_id'] : null);
    foreach ($items as $it) $reqTotal += (int)$it['quantity'];
    $qs = $db->prepare("SELECT q.*, s.company_name FROM quotations q JOIN suppliers s ON s.id=q.supplier_id WHERE q.rfq_id=? ORDER BY q.total_amount ASC");
    $qs->execute([$rfqId]);
    $quotes = $qs->fetchAll();
    foreach ($quotes as $k => $q) {
        $qi = $db->prepare("SELECT * FROM quotation_items WHERE quotation_id=?");
        $qi->execute([$q['id']]);
        $map = []; $qtySum = 0;
        foreach ($qi->fetchAll() as $row) {
            $qtySum += (int)$row['quantity'];
            if (!empty($row['rfq_item_id'])) $map['id:' . $row['rfq_item_id']] = $row;
            $map['d:' . strtolower(trim((string)$row['item_description']))] = $row;
        }
        $matrix[$q['id']] = $map;
        $quotes[$k]['coverage'] = $reqTotal > 0 ? min(100, round($qtySum / $reqTotal * 100)) : null;
    }
}
$minTotal = $quotes ? min(array_column($quotes, 'total_amount')) : null;
$minLead = $quotes ? min(array_column($quotes, 'delivery_lead_time')) : null;
$open = $rfq && in_array($rfq['status'], ['sent', 'evaluating'], true);
if (isset($_GET['ok'])) $success_message = $_GET['ok'];

$pageTitle = 'Quotation Comparison';
$pageIcon = 'fa-scale-balanced';
$pageActions = '<form method="GET" class="d-flex gap-2"><select name="rfq_id" class="form-select" onchange="this.form.submit()"><option value="">Choose an RFQ…</option>' . implode('', array_map(function ($x) use ($rfqId) { return '<option value="' . (int)$x['id'] . '"' . ((int)$x['id'] === $rfqId ? ' selected' : '') . '>' . h($x['rfq_number'] . ' — ' . ($x['title'] ?: 'RFQ') . ' (' . $x['status'] . ')') . '</option>'; }, $rfqList)) . '</select></form>';
include __DIR__ . '/_layout_top.php';
?>
<?php if (!$rfq): ?>
<div class="card"><div class="card-body text-center text-muted py-5"><i class="fas fa-scale-balanced fa-2x mb-2 d-block"></i>Choose an RFQ above to compare the supplier quotations side by side.</div></div>
<?php else: ?>
<div class="card mb-4"><div class="card-body d-flex flex-wrap justify-content-between gap-3 align-items-center">
    <div><h5 class="mb-1"><?php echo h($rfq['rfq_number']); ?> — <?php echo h($rfq['title'] ?: 'Request for quotation'); ?></h5>
        <div class="small text-muted">Deadline <?php echo $rfq['submission_deadline'] ? h(date('M d, Y H:i', strtotime($rfq['submission_deadline']))) : 'none'; ?> · <?php echo count($quotes); ?> quotation(s) · <span class="badge bg-<?php echo $rfq['status'] === 'awarded' ? 'success' : 'primary'; ?>"><?php echo h($rfq['status']); ?></span></div>
        <?php if ($rfq['status'] === 'awarded'): ?><div class="small mt-1"><strong>Decision:</strong> <?php echo h($rfq['selection_reason']); ?> <span class="text-muted">— <?php echo h($rfq['selected_by_name'] ?: ''); ?>, <?php echo h(sp_fmt_date($rfq['selected_at'])); ?></span></div><?php endif; ?></div>
    <div class="d-flex gap-2">
        <?php if ($canManage && $rfq['status'] === 'sent'): ?><form method="POST" data-confirm="Close supplier submissions for this RFQ? Suppliers will no longer be able to quote."><?php echo csrf_field(); ?><input type="hidden" name="action" value="close_submissions"><input type="hidden" name="rfq_id" value="<?php echo $rfqId; ?>"><button class="btn btn-outline-secondary"><i class="fas fa-lock me-1"></i> Close submissions</button></form><?php endif; ?>
        <a class="btn btn-outline-primary" href="rfqs.php">RFQ management</a>
        <?php if ($rfq['status'] === 'awarded'): ?><a class="btn btn-primary" href="purchase_orders.php"><i class="fas fa-file-signature me-1"></i> Create purchase order</a><?php endif; ?>
    </div>
</div></div>

<?php if (!$quotes): ?><div class="alert alert-info">No quotations received yet.</div><?php else: ?>
<form method="POST" data-confirm="Record this supplier-selection decision? All other quotations will be marked not selected and the suppliers notified.">
<?php echo csrf_field(); ?><input type="hidden" name="action" value="select_supplier"><input type="hidden" name="rfq_id" value="<?php echo $rfqId; ?>">
<div class="card mb-4"><div class="card-header"><h5 class="mb-0">Side-by-side comparison</h5></div><div class="table-responsive"><table class="table align-middle mb-0">
    <thead><tr><?php if ($open && $canManage): ?><th></th><?php endif; ?><th>Supplier</th><th class="text-end">Total</th><th class="text-center">Coverage</th><th class="text-center">Lead time</th><th>Warranty</th><th>Payment terms</th><th class="text-center">Valid</th><th class="text-center">Score T/C</th><th>Source</th><th>Status</th></tr></thead><tbody>
    <?php foreach ($quotes as $q): $sel = (int)($rfq['selected_quotation_id'] ?? 0) === (int)$q['id']; ?>
    <tr class="<?php echo $sel ? 'table-success' : ''; ?>">
        <?php if ($open && $canManage): ?><td><?php if (in_array($q['status'], ['received', 'evaluating'], true)): ?><input class="form-check-input" type="radio" name="quotation_id" value="<?php echo (int)$q['id']; ?>" required><?php endif; ?></td><?php endif; ?>
        <td><strong><?php echo h($q['company_name']); ?></strong><div class="small text-muted"><?php echo h($q['quotation_number']); ?><?php echo (int)$q['revision_no'] > 0 ? ' · rev ' . (int)$q['revision_no'] : ''; ?></div></td>
        <td class="text-end fw-semibold"><?php echo h(sp_money($q['total_amount'])); ?><?php if ($minTotal !== null && (float)$q['total_amount'] === (float)$minTotal && count($quotes) > 1): ?> <span class="badge bg-success">lowest</span><?php endif; ?></td>
        <td class="text-center"><?php echo $q['coverage'] === null ? '—' : (int)$q['coverage'] . '%'; ?></td>
        <td class="text-center"><?php echo (int)$q['delivery_lead_time']; ?> d<?php if ((int)$q['delivery_lead_time'] === (int)$minLead && count($quotes) > 1): ?> <span class="badge bg-info">fastest</span><?php endif; ?></td>
        <td class="small"><?php echo h($q['warranty'] ?: '—'); ?></td><td class="small"><?php echo h($q['payment_terms'] ?: '—'); ?></td>
        <td class="text-center small"><?php echo (int)$q['validity_days']; ?> d</td>
        <td class="text-center small"><?php echo $q['technical_compliance'] !== null ? h(rtrim(rtrim(number_format((float)$q['technical_compliance'], 1), '0'), '.')) : '—'; ?> / <?php echo $q['commercial_score'] !== null ? h(rtrim(rtrim(number_format((float)$q['commercial_score'], 1), '0'), '.')) : '—'; ?></td>
        <td><?php echo ($q['submitted_via'] ?? 'internal') === 'portal' ? '<span class="badge bg-primary">Supplier portal</span>' : '<span class="badge bg-secondary">Entered by staff</span>'; ?></td>
        <td><span class="badge bg-<?php echo $q['status'] === 'accepted' ? 'success' : ($q['status'] === 'rejected' ? 'secondary' : 'info'); ?>"><?php echo h($q['status']); ?></span></td>
    </tr>
    <?php if ($q['notes']): ?><tr><td colspan="<?php echo ($open && $canManage) ? 11 : 10; ?>" class="small text-muted border-0 pt-0"><i class="fas fa-note-sticky me-1"></i> <?php echo h($q['notes']); ?></td></tr><?php endif; ?>
    <?php endforeach; ?>
    </tbody></table></div></div>

<?php if ($items): ?>
<div class="card mb-4"><div class="card-header"><h5 class="mb-0">Item-by-item unit prices</h5></div><div class="table-responsive"><table class="table align-middle mb-0">
    <thead><tr><th>Item</th><th class="text-center">Needed</th><?php foreach ($quotes as $q): ?><th class="text-end"><?php echo h($q['company_name']); ?></th><?php endforeach; ?></tr></thead><tbody>
    <?php foreach ($items as $it):
        $cells = []; $min = null;
        foreach ($quotes as $q) {
            $row = $matrix[$q['id']]['id:' . $it['id']] ?? ($matrix[$q['id']]['d:' . strtolower(trim((string)$it['item_description']))] ?? null);
            $cells[] = $row;
            if ($row && ($min === null || (float)$row['unit_price'] < $min)) $min = (float)$row['unit_price'];
        } ?>
    <tr><td><?php echo h($it['item_description']); ?></td><td class="text-center"><?php echo (int)$it['quantity']; ?></td>
        <?php foreach ($cells as $row): ?><td class="text-end"><?php if ($row): ?><span class="<?php echo (float)$row['unit_price'] === $min && count($quotes) > 1 ? 'text-success fw-bold' : ''; ?>"><?php echo h(sp_money($row['unit_price'])); ?></span><div class="small text-muted">qty <?php echo (int)$row['quantity']; ?><?php echo $row['lead_time'] !== null ? ' · ' . (int)$row['lead_time'] . 'd' : ''; ?></div><?php else: ?><span class="text-muted">not quoted</span><?php endif; ?></td><?php endforeach; ?></tr>
    <?php endforeach; ?>
    </tbody></table></div></div>
<?php endif; ?>

<?php if ($open && $canManage): ?>
<div class="card pos-form-center"><div class="card-header"><h5 class="mb-0"><i class="fas fa-gavel me-2 text-primary"></i> Record the supplier-selection decision</h5></div><div class="card-body">
    <label class="form-label">Why this supplier? (price, quality, delivery, risk) *</label>
    <textarea name="reason" rows="3" minlength="10" maxlength="500" class="form-control mb-3" required></textarea>
    <div class="text-center"><button class="btn btn-primary"><i class="fas fa-check me-1"></i> Select supplier</button></div>
    <div class="small text-muted text-center mt-2">Only authorized buyers (RFQ management permission) can record this decision. It is saved with your name and time.</div>
</div></div>
<?php endif; ?>
</form>
<?php endif; ?>
<?php endif; ?>
<?php include __DIR__ . '/_layout_bottom.php';
