<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/supplier_portal.php';
require_permission('view_pos');
verify_csrf();
$db = getDB();
sp_ensure_schema($db);

$from = $_GET['from'] ?? date('Y-m-d', strtotime('-90 days'));
$to = $_GET['to'] ?? date('Y-m-d');
if (!sp_is_date($from)) $from = date('Y-m-d', strtotime('-90 days'));
if (!sp_is_date($to)) $to = date('Y-m-d');
if ($to < $from) $to = $from;

$spendSql = "SELECT s.company_name, COUNT(po.id) AS pos, COALESCE(SUM(po.grand_total),0) AS value,
        COALESCE(SUM(po.status IN ('fulfilled','closed')),0) AS completed,
        COALESCE(SUM(po.status IN ('fulfilled','closed') AND po.expected_delivery_date IS NOT NULL),0) AS timed,
        COALESCE(SUM(po.status IN ('fulfilled','closed') AND po.expected_delivery_date IS NOT NULL
            AND DATE((SELECT MAX(gr.receipt_date) FROM goods_receipts gr WHERE gr.po_id=po.id)) <= po.expected_delivery_date),0) AS on_time
    FROM purchase_orders po JOIN suppliers s ON s.id=po.supplier_id
    WHERE po.status NOT IN ('draft','pending_approval','cancelled','rejected') AND DATE(po.created_at) BETWEEN ? AND ?
    GROUP BY s.id, s.company_name ORDER BY value DESC";
$spendQ = $db->prepare($spendSql);
$spendQ->execute([$from, $to]);
$spend = $spendQ->fetchAll();

if (($_GET['export'] ?? '') === 'spend') {
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="procurement_spend_' . $from . '_to_' . $to . '.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Supplier', 'POs', 'Value', 'Completed', 'On-time %']);
    foreach ($spend as $r) {
        $name = preg_match('/^[=+\-@]/', (string)$r['company_name']) ? "'" . $r['company_name'] : $r['company_name'];
        fputcsv($out, [$name, $r['pos'], $r['value'], $r['completed'], $r['timed'] ? round($r['on_time'] / $r['timed'] * 100) : '']);
    }
    fclose($out);
    exit();
}

$st = $db->prepare("SELECT status, COUNT(*) AS c, COALESCE(SUM(grand_total),0) AS v FROM purchase_orders WHERE DATE(created_at) BETWEEN ? AND ? GROUP BY status ORDER BY c DESC");
$st->execute([$from, $to]);
$byStatus = $st->fetchAll();
$totPos = array_sum(array_column($byStatus, 'c'));
$totVal = array_sum(array_column($spend, 'value'));

$dq = $db->prepare("SELECT s.company_name, d.disc_type, COUNT(*) AS c, COALESCE(SUM(d.quantity),0) AS q FROM receiving_discrepancies d JOIN suppliers s ON s.id=d.supplier_id WHERE DATE(d.created_at) BETWEEN ? AND ? GROUP BY s.id, s.company_name, d.disc_type ORDER BY c DESC");
$dq->execute([$from, $to]);
$discs = $dq->fetchAll();
$openDisc = (int)$db->query("SELECT COUNT(*) FROM receiving_discrepancies WHERE status<>'resolved'")->fetchColumn();

$rq = $db->prepare("SELECT COUNT(DISTINCT r.id) AS rfqs, COUNT(rs.id) AS invited, COALESCE(SUM(rs.status='responded'),0) AS responded,
        AVG(CASE WHEN rs.responded_at IS NOT NULL THEN TIMESTAMPDIFF(HOUR, rs.invited_at, rs.responded_at) END) AS avg_hours
    FROM rfqs r LEFT JOIN rfq_suppliers rs ON rs.rfq_id=r.id WHERE DATE(r.created_at) BETWEEN ? AND ?");
$rq->execute([$from, $to]);
$rfqStat = $rq->fetch();
$respRate = (int)$rfqStat['invited'] > 0 ? round($rfqStat['responded'] / $rfqStat['invited'] * 100) : null;

$pageTitle = 'Procurement Reports';
$pageIcon = 'fa-chart-column';
$pageActions = '<a class="btn btn-outline-primary" href="procurement_reports.php?from=' . h($from) . '&to=' . h($to) . '&export=spend"><i class="fas fa-file-csv me-1"></i> Export spend (CSV)</a>';
include __DIR__ . '/_layout_top.php';
?>
<div class="card mb-4"><div class="card-body"><form method="GET" class="row g-2 align-items-end">
    <div class="col-md-3"><label class="form-label">From</label><input type="date" name="from" class="form-control" value="<?php echo h($from); ?>"></div>
    <div class="col-md-3"><label class="form-label">To</label><input type="date" name="to" class="form-control" value="<?php echo h($to); ?>"></div>
    <div class="col-md-2"><button class="btn btn-primary w-100">Apply</button></div>
    <div class="col-md-4 text-muted small">Purchase orders created in this period.</div>
</form></div></div>

<div class="row g-3 mb-4">
    <?php foreach ([['Purchase orders', $totPos, 'fa-file-signature'], ['Total PO value', sp_money($totVal), 'fa-peso-sign'], ['RFQ response rate', $respRate === null ? '—' : $respRate . '%', 'fa-reply'], ['Open discrepancies', $openDisc, 'fa-triangle-exclamation']] as $k): ?>
    <div class="col-xl-3 col-md-6"><div class="card h-100"><div class="card-body d-flex align-items-center gap-3"><span class="icon-bubble"><i class="fas <?php echo $k[2]; ?>"></i></span><div><div class="metric-label"><?php echo h($k[0]); ?></div><div class="metric-value"><?php echo h((string)$k[1]); ?></div></div></div></div></div>
    <?php endforeach; ?>
</div>

<div class="card mb-4"><div class="card-header"><h5 class="mb-0">Spend & delivery performance by supplier</h5></div><div class="table-responsive"><table class="table align-middle mb-0">
    <thead><tr><th>Supplier</th><th class="text-end">POs</th><th class="text-end">Value</th><th class="text-end">Completed</th><th class="text-end">On-time delivery</th></tr></thead><tbody>
    <?php if (!$spend): ?><tr><td colspan="5" class="text-center text-muted py-4">No purchase orders in this period.</td></tr><?php endif; ?>
    <?php foreach ($spend as $r): ?><tr><td><strong><?php echo h($r['company_name']); ?></strong></td><td class="text-end"><?php echo (int)$r['pos']; ?></td><td class="text-end"><?php echo h(sp_money($r['value'])); ?></td><td class="text-end"><?php echo (int)$r['completed']; ?></td><td class="text-end"><?php echo $r['timed'] ? round($r['on_time'] / $r['timed'] * 100) . '%' : '—'; ?></td></tr><?php endforeach; ?>
    </tbody></table></div></div>

<div class="row g-4">
    <div class="col-lg-5"><div class="card h-100"><div class="card-header"><h5 class="mb-0">PO status</h5></div><div class="table-responsive"><table class="table mb-0"><thead><tr><th>Status</th><th class="text-end">POs</th><th class="text-end">Value</th></tr></thead><tbody>
        <?php foreach ($byStatus as $r): ?><tr><td><?php echo h(ucfirst(str_replace('_', ' ', $r['status']))); ?></td><td class="text-end"><?php echo (int)$r['c']; ?></td><td class="text-end"><?php echo h(sp_money($r['v'])); ?></td></tr><?php endforeach; ?>
        <?php if (!$byStatus): ?><tr><td colspan="3" class="text-center text-muted py-3">None.</td></tr><?php endif; ?>
    </tbody></table></div></div></div>
    <div class="col-lg-7"><div class="card h-100"><div class="card-header"><h5 class="mb-0">Receiving discrepancies by supplier</h5></div><div class="table-responsive"><table class="table mb-0"><thead><tr><th>Supplier</th><th>Type</th><th class="text-end">Cases</th><th class="text-end">Units</th></tr></thead><tbody>
        <?php foreach ($discs as $r): ?><tr><td><?php echo h($r['company_name']); ?></td><td><?php echo h(sp_disc_type_label($r['disc_type'])); ?></td><td class="text-end"><?php echo (int)$r['c']; ?></td><td class="text-end"><?php echo (int)$r['q']; ?></td></tr><?php endforeach; ?>
        <?php if (!$discs): ?><tr><td colspan="4" class="text-center text-muted py-3">No discrepancies in this period.</td></tr><?php endif; ?>
    </tbody></table></div></div></div>
</div>
<div class="small text-muted mt-3">RFQs created: <?php echo (int)$rfqStat['rfqs']; ?> · invitations: <?php echo (int)$rfqStat['invited']; ?> · average time to respond: <?php echo $rfqStat['avg_hours'] !== null ? round($rfqStat['avg_hours']) . ' h' : '—'; ?></div>
<?php include __DIR__ . '/_layout_bottom.php';
