<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/supplier_portal.php';
require_permission('view_pos');
verify_csrf();
$db = getDB();
sp_ensure_schema($db);
$success_message = null;
$error_message = null;
$tab = ($_GET['tab'] ?? 'pending') === 'history' ? 'history' : 'pending';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $crId = (int)($_POST['request_id'] ?? 0);
    $note = trim($_POST['note'] ?? '');
    try {
        require_permission('approve_purchase_orders');   // PO revisions need an authorized approver
        if ($action === 'reject') {
            if (strlen($note) < 5) throw new Exception('Give a reason for rejecting (at least 5 characters).');
            $db->beginTransaction();
            $q = $db->prepare("SELECT cr.*, po.po_number FROM po_change_requests cr JOIN purchase_orders po ON po.id=cr.po_id WHERE cr.id=? FOR UPDATE");
            $q->execute([$crId]);
            $cr = $q->fetch();
            if (!$cr || $cr['status'] !== 'pending') throw new Exception('This request was already decided.');
            $db->prepare("UPDATE po_change_requests SET status='rejected', decided_by=?, decided_at=NOW(), decision_note=? WHERE id=?")->execute([$_SESSION['user_id'], substr($note, 0, 500), $crId]);
            sp_log_event($db, (int)$cr['po_id'], (int)$cr['supplier_id'], 'procurement', 'change_rejected', substr($note, 0, 300));
            $db->commit();
            logActivity("PO change request #$crId rejected - $note");
            sp_notify_supplier($db, (int)$cr['supplier_id'], 'Change request rejected', 'Your change request for ' . $cr['po_number'] . ' was rejected: ' . $note, 'modules/supplier_portal/order.php?id=' . $cr['po_id'], 'Change request decision: ' . $cr['po_number'], ['Your change request for ' . $cr['po_number'] . ' was not approved.', 'Reason: ' . $note]);
            header('Location: po_revisions.php?ok=' . urlencode('Change request rejected.')); exit();
        } elseif ($action === 'approve') {
            $db->beginTransaction();
            $q = $db->prepare("SELECT * FROM po_change_requests WHERE id=? FOR UPDATE");
            $q->execute([$crId]);
            $cr = $q->fetch();
            if (!$cr || $cr['status'] !== 'pending') throw new Exception('This request was already decided.');
            $p = $db->prepare("SELECT * FROM purchase_orders WHERE id=? FOR UPDATE");
            $p->execute([$cr['po_id']]);
            $po = $p->fetch();
            if (!$po || !in_array($po['status'], ['sent', 'acknowledged', 'partially_received'], true)) throw new Exception('The purchase order is no longer open for revision (status: ' . ($po['status'] ?? 'unknown') . ').');
            $before = sp_snapshot_po($db, (int)$po['id']);
            $parts = [];
            if ($cr['new_delivery_date']) {
                $db->prepare("UPDATE purchase_orders SET delivery_date=?, expected_delivery_date=? WHERE id=?")->execute([$cr['new_delivery_date'], $cr['new_delivery_date'], $po['id']]);
                $parts[] = 'Delivery date ' . ($po['delivery_date'] ?: 'none') . ' to ' . $cr['new_delivery_date'];
            }
            if ($cr['new_payment_terms']) {
                $db->prepare("UPDATE purchase_orders SET payment_terms=? WHERE id=?")->execute([$cr['new_payment_terms'], $po['id']]);
                $parts[] = 'Payment terms ' . ($po['payment_terms'] ?: 'none') . ' to ' . $cr['new_payment_terms'];
            }
            foreach (json_decode((string)$cr['items_json'], true) ?: [] as $ch) {
                $i = $db->prepare("SELECT * FROM po_items WHERE id=? AND po_id=? FOR UPDATE");
                $i->execute([(int)$ch['item_id'], $po['id']]);
                $it = $i->fetch();
                if (!$it) throw new Exception('A line item in this request no longer exists.');
                if ((int)$ch['quantity'] < (int)$it['received_quantity']) throw new Exception('"' . $it['item_description'] . '" already has ' . (int)$it['received_quantity'] . ' accepted units, so the quantity cannot go below that.');
                $db->prepare("UPDATE po_items SET quantity=?, unit_price=? WHERE id=?")->execute([(int)$ch['quantity'], (float)$ch['unit_price'], $it['id']]);
                $desc = substr((string)$it['item_description'], 0, 40);
                if ((int)$ch['quantity'] !== (int)$it['quantity']) $parts[] = $desc . ' qty ' . (int)$it['quantity'] . ' to ' . (int)$ch['quantity'];
                if (round((float)$ch['unit_price'], 2) !== round((float)$it['unit_price'], 2)) $parts[] = $desc . ' price ' . number_format((float)$it['unit_price'], 2) . ' to ' . number_format((float)$ch['unit_price'], 2);
            }
            sp_recalc_po_totals($db, (int)$po['id']);
            $rev = sp_record_revision($db, (int)$po['id'], $before, implode('; ', $parts) . ' (supplier request #' . $crId . ')', $crId);
            sp_reeval_po_status($db, (int)$po['id']);
            $db->prepare("UPDATE po_change_requests SET status='approved', decided_by=?, decided_at=NOW(), decision_note=?, revision_no=? WHERE id=?")->execute([$_SESSION['user_id'], substr($note, 0, 500), $rev, $crId]);
            sp_log_event($db, (int)$po['id'], (int)$cr['supplier_id'], 'procurement', 'revision_approved', 'Revision ' . $rev . ': ' . implode('; ', $parts));
            $db->commit();
            logActivity("PO {$po['po_number']} revised to revision $rev (change request #$crId approved)");
            sp_notify_supplier($db, (int)$cr['supplier_id'], 'Purchase order revised', $po['po_number'] . ' was revised (revision ' . $rev . ') as you requested.', 'modules/supplier_portal/order.php?id=' . $po['id'], 'PO revised: ' . $po['po_number'] . ' (rev ' . $rev . ')', [$po['po_number'] . ' was revised as you requested (revision ' . $rev . ').', 'Changes: ' . implode('; ', $parts)]);
            header('Location: po_revisions.php?tab=history&ok=' . urlencode('Approved. ' . $po['po_number'] . ' is now revision ' . $rev . '.')); exit();
        }
    } catch (Throwable $e) {
        if ($db->inTransaction()) $db->rollBack();
        $error_message = $e->getMessage();
    }
}
if (isset($_GET['ok'])) $success_message = $_GET['ok'];
$canDecide = hasPermission('approve_purchase_orders');

$pending = $db->query("SELECT cr.*, po.po_number, po.delivery_date, po.payment_terms, po.grand_total, s.company_name, u.full_name AS requester
    FROM po_change_requests cr JOIN purchase_orders po ON po.id=cr.po_id JOIN suppliers s ON s.id=cr.supplier_id LEFT JOIN users u ON u.id=cr.requested_by
    WHERE cr.status='pending' ORDER BY cr.id ASC")->fetchAll();
$history = $db->query("SELECT r.*, po.po_number, s.company_name, u.full_name AS approver FROM po_revisions r JOIN purchase_orders po ON po.id=r.po_id JOIN suppliers s ON s.id=po.supplier_id LEFT JOIN users u ON u.id=r.approved_by ORDER BY r.id DESC LIMIT 200")->fetchAll();
$decided = $db->query("SELECT cr.*, po.po_number, s.company_name FROM po_change_requests cr JOIN purchase_orders po ON po.id=cr.po_id JOIN suppliers s ON s.id=cr.supplier_id WHERE cr.status IN ('rejected','withdrawn') ORDER BY cr.id DESC LIMIT 30")->fetchAll();

$pageTitle = 'PO Revisions';
$pageIcon = 'fa-code-compare';
include __DIR__ . '/_layout_top.php';
?>
<div class="card mb-3"><div class="card-body d-flex gap-2">
    <a class="btn btn-sm <?php echo $tab === 'pending' ? 'btn-primary' : 'btn-outline-secondary'; ?>" href="po_revisions.php?tab=pending">Change requests <?php echo count($pending) ? '<span class="badge bg-danger ms-1">' . count($pending) . '</span>' : ''; ?></a>
    <a class="btn btn-sm <?php echo $tab === 'history' ? 'btn-primary' : 'btn-outline-secondary'; ?>" href="po_revisions.php?tab=history">Revision history</a>
</div></div>

<?php if ($tab === 'pending'): ?>
<?php if (!$canDecide): ?><div class="alert alert-info small">You can view change requests. Approving or rejecting needs the “approve purchase orders” permission.</div><?php endif; ?>
<?php if (!$pending): ?><div class="card"><div class="card-body text-center text-muted py-5"><i class="fas fa-circle-check fa-2x text-success mb-2 d-block"></i>No change requests are waiting.</div></div><?php endif; ?>
<?php foreach ($pending as $c):
    $it = $db->prepare("SELECT id, item_description, quantity, unit_price, received_quantity FROM po_items WHERE po_id=? ORDER BY id");
    $it->execute([$c['po_id']]);
    $cur = []; foreach ($it->fetchAll() as $row) $cur[(int)$row['id']] = $row;
    $chs = json_decode((string)$c['items_json'], true) ?: []; ?>
<div class="card mb-4"><div class="card-header d-flex flex-wrap justify-content-between gap-2"><div><strong><?php echo h($c['po_number']); ?></strong> <span class="text-muted">· <?php echo h($c['company_name']); ?> · requested <?php echo h(date('M d, H:i', strtotime($c['created_at']))); ?> by <?php echo h($c['requester'] ?: 'supplier'); ?></span></div><a class="btn btn-sm btn-outline-primary" href="po_view.php?id=<?php echo (int)$c['po_id']; ?>">View PO</a></div>
<div class="card-body">
    <div class="mb-3"><span class="metric-label">Supplier's reason</span><div><?php echo h($c['reason']); ?></div></div>
    <table class="table table-sm align-middle"><thead><tr><th>What changes</th><th>Now</th><th>Requested</th></tr></thead><tbody>
        <?php if ($c['new_delivery_date']): ?><tr><td>Delivery date</td><td><?php echo h(sp_fmt_date($c['delivery_date'])); ?></td><td class="fw-semibold"><?php echo h(sp_fmt_date($c['new_delivery_date'])); ?></td></tr><?php endif; ?>
        <?php if ($c['new_payment_terms']): ?><tr><td>Payment terms</td><td><?php echo h($c['payment_terms'] ?: '—'); ?></td><td class="fw-semibold"><?php echo h($c['new_payment_terms']); ?></td></tr><?php endif; ?>
        <?php foreach ($chs as $ch): $row = $cur[(int)$ch['item_id']] ?? null; if (!$row) continue; ?>
        <tr><td><?php echo h($row['item_description']); ?><div class="small text-muted">accepted so far: <?php echo (int)$row['received_quantity']; ?></div></td><td><?php echo (int)$row['quantity']; ?> × <?php echo h(sp_money($row['unit_price'])); ?></td><td class="fw-semibold"><?php echo (int)$ch['quantity']; ?> × <?php echo h(sp_money($ch['unit_price'])); ?></td></tr>
        <?php endforeach; ?>
    </tbody></table>
    <?php if ($canDecide): ?>
    <form method="POST" class="row g-2"><?php echo csrf_field(); ?><input type="hidden" name="request_id" value="<?php echo (int)$c['id']; ?>">
        <div class="col-md-8"><input type="text" name="note" maxlength="500" class="form-control" placeholder="Decision note (required when rejecting)"></div>
        <div class="col-md-4 d-flex gap-2"><button name="action" value="approve" class="btn btn-success flex-fill" onclick="return confirm('Approve and apply this revision to the purchase order?')">Approve</button><button name="action" value="reject" class="btn btn-outline-danger flex-fill" onclick="return confirm('Reject this change request?')">Reject</button></div>
    </form>
    <?php endif; ?>
</div></div>
<?php endforeach; ?>
<?php if ($decided): ?><div class="card"><div class="card-header"><h5 class="mb-0">Recently declined / withdrawn</h5></div><div class="table-responsive"><table class="table mb-0"><thead><tr><th>PO</th><th>Supplier</th><th>Reason</th><th>Outcome</th></tr></thead><tbody>
    <?php foreach ($decided as $d): ?><tr><td><?php echo h($d['po_number']); ?></td><td><?php echo h($d['company_name']); ?></td><td class="small"><?php echo h($d['reason']); ?><?php if ($d['decision_note']): ?><div class="text-muted">Decision: <?php echo h($d['decision_note']); ?></div><?php endif; ?></td><td><span class="badge bg-<?php echo $d['status'] === 'rejected' ? 'danger' : 'secondary'; ?>"><?php echo h($d['status']); ?></span></td></tr><?php endforeach; ?>
</tbody></table></div></div><?php endif; ?>

<?php else: ?>
<div class="card"><div class="table-responsive"><table class="table align-middle mb-0">
    <thead><tr><th>PO</th><th>Rev</th><th>Supplier</th><th>What changed</th><th class="text-end">Total before → after</th><th>Source</th><th>Approved by</th><th>When</th></tr></thead><tbody>
    <?php if (!$history): ?><tr><td colspan="8" class="text-center text-muted py-4">No revisions yet.</td></tr><?php endif; ?>
    <?php foreach ($history as $r): $b = json_decode((string)$r['before_json'], true); $a = json_decode((string)$r['after_json'], true); ?>
    <tr><td><a href="po_view.php?id=<?php echo (int)$r['po_id']; ?>"><strong><?php echo h($r['po_number']); ?></strong></a></td><td><span class="badge bg-info">Rev <?php echo (int)$r['revision_no']; ?></span></td><td><?php echo h($r['company_name']); ?></td>
        <td class="small"><?php echo h($r['summary']); ?></td>
        <td class="text-end small"><?php echo h(sp_money($b['po']['grand_total'] ?? 0)); ?> → <strong><?php echo h(sp_money($a['po']['grand_total'] ?? 0)); ?></strong></td>
        <td><?php echo $r['change_request_id'] ? '<span class="badge bg-primary">Supplier request</span>' : '<span class="badge bg-warning text-dark">Discrepancy</span>'; ?></td>
        <td class="small"><?php echo h($r['approver'] ?: '—'); ?></td><td class="small"><?php echo h(date('M d, Y H:i', strtotime($r['created_at']))); ?></td></tr>
    <?php endforeach; ?>
    </tbody></table></div></div>
<?php endif; ?>
<?php include __DIR__ . '/_layout_bottom.php';
