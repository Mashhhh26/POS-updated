<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/supplier_portal.php';
require_permission('view_pos');
verify_csrf();
$db = getDB();
sp_ensure_schema($db);
$success_message = null;
$error_message = null;
$canAct = hasPermission('manage_pos');
$canApprove = hasPermission('approve_purchase_orders');
$resolutions = ['replacement' => 'Replacement from supplier', 'credit_note' => 'Credit note', 'refund' => 'Refund', 'return_to_supplier' => 'Return to supplier', 'short_close' => 'Accept shortage (short-close)'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $did = (int)($_POST['disc_id'] ?? 0);
    try {
        require_permission('manage_pos');
        $dq = $db->prepare("SELECT d.*, po.po_number FROM receiving_discrepancies d JOIN purchase_orders po ON po.id=d.po_id WHERE d.id=?");
        $dq->execute([$did]);
        $disc = $dq->fetch();
        if (!$disc) throw new Exception('Discrepancy not found.');

        if ($action === 'add_evidence') {
            $docId = sp_store_upload($db, $_FILES['file'] ?? [], ['supplier_id' => (int)$disc['supplier_id'], 'po_id' => (int)$disc['po_id'], 'discrepancy_id' => $did, 'doc_type' => 'discrepancy_evidence', 'by' => 'internal', 'note' => trim($_POST['note'] ?? '')]);
            logActivity("Discrepancy #$did: evidence document #$docId added");
            sp_notify_supplier($db, (int)$disc['supplier_id'], 'Discrepancy evidence added', 'Procurement added evidence to a receiving discrepancy on ' . $disc['po_number'] . '.', 'modules/supplier_portal/order.php?id=' . $disc['po_id']);
            header('Location: discrepancies.php?ok=' . urlencode('Evidence uploaded.')); exit();
        } elseif ($action === 'resolve') {
            $res = $_POST['resolution'] ?? '';
            $note = trim($_POST['note'] ?? '');
            $amt = trim($_POST['amount'] ?? '');
            if (!isset($resolutions[$res])) throw new Exception('Choose a resolution.');
            if (strlen($note) < 10) throw new Exception('Document the resolution (at least 10 characters).');
            if ($amt !== '' && !valid_money($amt, true)) throw new Exception('The amount is not valid.');
            if (in_array($res, ['credit_note', 'refund'], true) && $amt === '') throw new Exception('Enter the credit / refund amount.');
            if ($res !== 'replacement') require_permission('approve_purchase_orders');   // changes the PO quantities/value

            $db->beginTransaction();
            $lk = $db->prepare("SELECT * FROM receiving_discrepancies WHERE id=? FOR UPDATE");
            $lk->execute([$did]);
            $d = $lk->fetch();
            if (!$d || $d['status'] === 'resolved') throw new Exception('This discrepancy is already resolved.');
            if ($res === 'replacement') {
                $db->prepare("UPDATE receiving_discrepancies SET status='awaiting_replacement', resolution='replacement', resolution_note=? WHERE id=?")->execute([substr($note, 0, 500), $did]);
                $msg = 'Replacement requested. It resolves automatically when the replacement is received and accepted.';
            } else {
                $p = $db->prepare("SELECT * FROM purchase_orders WHERE id=? FOR UPDATE");
                $p->execute([$d['po_id']]);
                $po = $p->fetch();
                if (!in_array($po['status'], ['acknowledged', 'partially_received'], true)) throw new Exception('The purchase order is ' . $po['status'] . ', so its quantities can no longer be short-closed.');
                $before = sp_snapshot_po($db, (int)$po['id']);
                if ($d['po_item_id']) {
                    $i = $db->prepare("SELECT * FROM po_items WHERE id=? AND po_id=? FOR UPDATE");
                    $i->execute([$d['po_item_id'], $po['id']]);
                    $it = $i->fetch();
                    if ($it) {
                        $newQty = max((int)$it['received_quantity'], (int)$it['quantity'] - (int)$d['quantity']);
                        $db->prepare("UPDATE po_items SET quantity=? WHERE id=?")->execute([$newQty, $it['id']]);
                    }
                }
                sp_recalc_po_totals($db, (int)$po['id']);
                $rev = sp_record_revision($db, (int)$po['id'], $before, 'Short-closed ' . (int)$d['quantity'] . ' unit(s) after discrepancy #' . $did . ' (' . $resolutions[$res] . ')', null);
                $newStatus = sp_reeval_po_status($db, (int)$po['id']);
                $db->prepare("UPDATE receiving_discrepancies SET status='resolved', resolution=?, resolution_amount=?, resolution_note=?, resolved_by=?, resolved_at=NOW() WHERE id=?")
                   ->execute([$res, $amt !== '' ? (float)$amt : null, substr($note, 0, 500), $_SESSION['user_id'], $did]);
                sp_log_event($db, (int)$po['id'], (int)$d['supplier_id'], 'procurement', 'discrepancy_resolved', $resolutions[$res] . ': ' . substr($note, 0, 300));
                $msg = 'Resolved. PO revised to revision ' . $rev . ($newStatus === 'fulfilled' ? ' and is now fulfilled.' : '.');
            }
            $db->commit();
            if (!empty($_FILES['file']['name'])) {
                try { sp_store_upload($db, $_FILES['file'], ['supplier_id' => (int)$disc['supplier_id'], 'po_id' => (int)$disc['po_id'], 'discrepancy_id' => $did, 'doc_type' => 'discrepancy_evidence', 'by' => 'internal', 'note' => 'Resolution documentation']); }
                catch (Throwable $ue) { $msg .= ' (the attachment was not saved: ' . $ue->getMessage() . ')'; }
            }
            logActivity("Discrepancy #$did resolved: {$resolutions[$res]} - $note");
            sp_notify_supplier($db, (int)$disc['supplier_id'], 'Discrepancy update', 'Discrepancy on ' . $disc['po_number'] . ': ' . $resolutions[$res] . '. ' . $note, 'modules/supplier_portal/order.php?id=' . $disc['po_id'],
                'Receiving discrepancy update: ' . $disc['po_number'], ['The receiving discrepancy on ' . $disc['po_number'] . ' was handled: ' . $resolutions[$res] . '.', $note]);
            header('Location: discrepancies.php?ok=' . urlencode($msg)); exit();
        }
    } catch (Throwable $e) {
        if ($db->inTransaction()) $db->rollBack();
        $error_message = $e->getMessage();
    }
}
if (isset($_GET['ok'])) $success_message = $_GET['ok'];

$f = $_GET['f'] ?? 'open';
if (!in_array($f, ['open', 'awaiting', 'resolved', 'all'], true)) $f = 'open';
$where = ['open' => "d.status IN ('open','supplier_notified')", 'awaiting' => "d.status='awaiting_replacement'", 'resolved' => "d.status='resolved'", 'all' => '1=1'][$f];
$rows = $db->query("SELECT d.*, po.po_number, s.company_name, i.item_description, u.full_name AS reporter
    FROM receiving_discrepancies d JOIN purchase_orders po ON po.id=d.po_id JOIN suppliers s ON s.id=d.supplier_id
    LEFT JOIN po_items i ON i.id=d.po_item_id LEFT JOIN users u ON u.id=d.created_by WHERE $where ORDER BY d.id DESC LIMIT 100")->fetchAll();
$counts = $db->query("SELECT SUM(status IN ('open','supplier_notified')) o, SUM(status='awaiting_replacement') a, SUM(status='resolved') r FROM receiving_discrepancies")->fetch();

$pageTitle = 'Discrepancy Management';
$pageIcon = 'fa-triangle-exclamation';
include __DIR__ . '/_layout_top.php';
$tabs = ['open' => 'Open (' . (int)$counts['o'] . ')', 'awaiting' => 'Awaiting replacement (' . (int)$counts['a'] . ')', 'resolved' => 'Resolved (' . (int)$counts['r'] . ')', 'all' => 'All'];
?>
<div class="card mb-3"><div class="card-body d-flex flex-wrap gap-2"><?php foreach ($tabs as $k => $l): ?><a class="btn btn-sm <?php echo $k === $f ? 'btn-primary' : 'btn-outline-secondary'; ?>" href="discrepancies.php?f=<?php echo $k; ?>"><?php echo h($l); ?></a><?php endforeach; ?></div></div>
<div class="alert alert-info small">Rejected, damaged and missing items never enter inventory and stay outstanding on the PO. Resolve each one with documentation: a <strong>replacement</strong> keeps the quantity open until it is received; any other resolution <strong>short-closes</strong> the PO quantity (recorded as a PO revision, needs the “approve purchase orders” permission).</div>
<?php if (!$rows): ?><div class="card"><div class="card-body text-center text-muted py-5"><i class="fas fa-circle-check fa-2x text-success mb-2 d-block"></i>No discrepancies in this view.</div></div><?php endif; ?>
<?php foreach ($rows as $d):
    $docs = $db->prepare("SELECT * FROM supplier_documents WHERE discrepancy_id=? ORDER BY id DESC");
    $docs->execute([$d['id']]);
    $docs = $docs->fetchAll(); ?>
<div class="card mb-3"><div class="card-body">
    <div class="d-flex flex-wrap justify-content-between gap-2 mb-2">
        <div><strong><?php echo (int)$d['quantity']; ?> × <?php echo h($d['item_description'] ?: 'item'); ?></strong> <span class="text-muted">— <?php echo h(sp_disc_type_label($d['disc_type'])); ?></span>
            <div class="small text-muted"><a href="po_view.php?id=<?php echo (int)$d['po_id']; ?>"><?php echo h($d['po_number']); ?></a> · <?php echo h($d['company_name']); ?> · reported <?php echo h(date('M d, Y', strtotime($d['created_at']))); ?> by <?php echo h($d['reporter'] ?: 'staff'); ?></div></div>
        <div><?php echo sp_disc_status_badge($d['status']); ?></div>
    </div>
    <div class="small mb-2"><strong>Documentation:</strong> <?php echo h($d['description']); ?></div>
    <?php if ($d['supplier_response']): ?><div class="small mb-2 p-2 rounded-3" style="background:var(--pos-surface-2)"><strong>Supplier replied</strong> (<?php echo h(date('M d, H:i', strtotime($d['supplier_responded_at']))); ?>): <?php echo h($d['supplier_response']); ?></div><?php endif; ?>
    <?php if ($d['resolution']): ?><div class="small mb-2"><strong>Resolution:</strong> <?php echo h($resolutions[$d['resolution']] ?? $d['resolution']); ?><?php echo $d['resolution_amount'] !== null ? ' (' . h(sp_money($d['resolution_amount'])) . ')' : ''; ?> — <?php echo h($d['resolution_note']); ?></div><?php endif; ?>
    <?php foreach ($docs as $x): ?><a class="soft-row small" href="../supplier_portal/download.php?id=<?php echo (int)$x['id']; ?>"><i class="fas fa-paperclip"></i><?php echo h($x['original_name']); ?><span class="ms-auto text-muted"><?php echo $x['uploaded_by_type'] === 'supplier' ? 'supplier' : 'staff'; ?></span></a><?php endforeach; ?>
    <?php if ($canAct && $d['status'] !== 'resolved'): ?>
    <div class="row g-3 mt-1">
        <div class="col-lg-7"><form method="POST" enctype="multipart/form-data" class="row g-2" data-confirm="Record this resolution? Non-replacement resolutions short-close the PO quantity."><?php echo csrf_field(); ?><input type="hidden" name="action" value="resolve"><input type="hidden" name="disc_id" value="<?php echo (int)$d['id']; ?>">
            <div class="col-md-6"><select name="resolution" class="form-select form-select-sm" required><option value="">Resolution…</option><?php foreach ($resolutions as $k => $l): if ($k !== 'replacement' && !$canApprove) continue; ?><option value="<?php echo $k; ?>"><?php echo h($l); ?></option><?php endforeach; ?></select></div>
            <div class="col-md-6"><input type="number" step="0.01" min="0" name="amount" class="form-control form-control-sm" placeholder="Credit / refund amount ₱"></div>
            <div class="col-12"><input type="text" name="note" minlength="10" maxlength="500" class="form-control form-control-sm" placeholder="Documentation of the resolution *" required></div>
            <div class="col-md-8"><input type="file" name="file" class="form-control form-control-sm" accept=".pdf,.jpg,.jpeg,.png,.doc,.docx,.xls,.xlsx"></div>
            <div class="col-md-4"><button class="btn btn-sm btn-primary w-100">Resolve</button></div></form>
            <?php if (!$canApprove): ?><div class="form-text">Only “replacement” is available to you; other resolutions need an authorized approver.</div><?php endif; ?></div>
        <div class="col-lg-5"><form method="POST" enctype="multipart/form-data" class="row g-2"><?php echo csrf_field(); ?><input type="hidden" name="action" value="add_evidence"><input type="hidden" name="disc_id" value="<?php echo (int)$d['id']; ?>">
            <div class="col-12"><input type="file" name="file" class="form-control form-control-sm" accept=".pdf,.jpg,.jpeg,.png,.doc,.docx,.xls,.xlsx" required></div>
            <div class="col-8"><input type="text" name="note" maxlength="255" class="form-control form-control-sm" placeholder="Evidence note"></div>
            <div class="col-4"><button class="btn btn-sm btn-outline-primary w-100">Add evidence</button></div></form></div>
    </div>
    <?php endif; ?>
</div></div>
<?php endforeach; ?>
<?php include __DIR__ . '/_layout_bottom.php';
