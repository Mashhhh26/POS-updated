<?php
// Public page: set (or reset) a password from a one-time emailed link.
session_start();
require_once 'config/database.php';
require_once 'config/supplier_portal.php';
verify_csrf();
$db = getDB();
sp_ensure_schema($db);

$raw = trim($_GET['token'] ?? ($_POST['token'] ?? ''));
$tok = sp_find_token($db, $raw);
$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $tok) {
    $p1 = $_POST['password'] ?? '';
    $p2 = $_POST['confirm'] ?? '';
    if ($p1 !== $p2) {
        $error = 'The two passwords do not match.';
    } elseif (($e = sp_valid_password($p1)) !== null) {
        $error = $e;
    } else {
        $db->beginTransaction();
        try {
            $db->prepare("UPDATE users SET password=? WHERE id=?")->execute([password_hash($p1, PASSWORD_DEFAULT), $tok['user_id']]);
            $db->prepare("UPDATE password_tokens SET used_at=NOW() WHERE user_id=? AND used_at IS NULL")->execute([$tok['user_id']]);
            $db->commit();
            header('Location: login.php?activated=1');
            exit();
        } catch (Throwable $e) {
            if ($db->inTransaction()) $db->rollBack();
            $error = 'Could not save your password. Please try again.';
        }
    }
}
?><!doctype html>
<html lang="en" data-pos-theme="light" data-pos-palette="indigo">
<head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Set your password</title>
    <link rel="stylesheet" href="assets/vendor/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="assets/vendor/fontawesome/all.min.css">
    <link rel="stylesheet" href="assets/css/custom.css?v=20261010">
</head>
<body>
<main class="container py-5" style="max-width:520px">
    <div class="card"><div class="card-body p-4">
    <?php if (!$tok): ?>
        <div class="text-center">
            <i class="fas fa-link-slash fa-2x text-muted mb-3"></i>
            <h5>This link is invalid or has expired</h5>
            <p class="text-muted small">Ask the procurement team to send you a new invitation link.</p>
            <a class="btn btn-primary" href="login.php">Go to login</a>
        </div>
    <?php else: ?>
        <div class="text-center mb-3"><i class="fas fa-key fa-2x text-primary mb-2"></i><h5 class="mb-1">Set your password</h5><div class="small text-muted">Account: <strong><?php echo h($tok['username']); ?></strong></div></div>
        <?php if ($error): ?><div class="alert alert-danger small"><?php echo h($error); ?></div><?php endif; ?>
        <form method="POST" autocomplete="off">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="token" value="<?php echo h($raw); ?>">
            <div class="mb-3"><label class="form-label">New password</label><input type="password" name="password" class="form-control" minlength="10" required autofocus></div>
            <div class="mb-3"><label class="form-label">Confirm password</label><input type="password" name="confirm" class="form-control" minlength="10" required><div class="form-text">At least 10 characters, with letters and numbers.</div></div>
            <button class="btn btn-primary w-100">Save password</button>
        </form>
    <?php endif; ?>
    </div></div>
</main>
</body>
</html>
