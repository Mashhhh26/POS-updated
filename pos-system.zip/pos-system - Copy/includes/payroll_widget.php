<?php
// Dashboard payroll widget. Expects $payrollWidget (see payroll_dashboard_data()).
if (empty($payrollWidget) || (empty($payrollWidget['staff']) && empty($payrollWidget['mine']))) return;
$pw = $payrollWidget;
$pwRoot = BASE_PATH . 'modules/payroll/';
$pwCols = (!empty($pw['staff']) && !empty($pw['mine'])) ? 'col-xl-3 col-md-6' : 'col-lg-4 col-md-6';
?>
<div class="section-title">
    <h5><i class="fas fa-coins me-2 text-primary"></i> Payroll</h5>
    <?php if (!empty($pw['staff'])): ?><a class="btn btn-sm btn-outline-primary" href="<?php echo $pwRoot; ?>periods.php"><i class="fas fa-arrow-right me-1"></i> Open payroll</a><?php endif; ?>
</div>
<div class="row g-3 mb-4">
<?php if (!empty($pw['staff'])): $cur = $pw['current']; ?>
    <div class="<?php echo $pwCols; ?>">
        <div class="card h-100"><div class="card-body">
            <div class="d-flex align-items-center gap-3 mb-3">
                <span class="icon-bubble"><i class="fas fa-wallet"></i></span>
                <div><div class="metric-label">Current payroll</div>
                <?php if ($cur): ?><div class="fw-semibold"><?php echo h($cur['period_name']); ?></div><?php else: ?><div class="text-muted">No payroll yet</div><?php endif; ?></div>
            </div>
            <?php if ($cur): ?>
                <div class="mb-2"><?php echo payroll_status_badge($cur['status']); ?> <span class="small text-muted ms-1">Pay date <?php echo h(payroll_fmt_date($cur['pay_date'])); ?></span></div>
                <div class="metric-value mb-2"><?php echo h(payroll_money($cur['total_net'])); ?> <span class="small text-muted fw-normal">net</span></div>
                <?php if (in_array($cur['status'], ['finalized', 'partially_paid', 'paid'], true) && (int)$cur['emp_count'] > 0): $pct = (int)round(((int)$cur['paid_count'] / (int)$cur['emp_count']) * 100); ?>
                    <div class="progress mb-1"><div class="progress-bar" style="width:<?php echo $pct; ?>%"></div></div>
                    <div class="small text-muted mb-3"><?php echo (int)$cur['paid_count']; ?> of <?php echo (int)$cur['emp_count']; ?> employees paid</div>
                <?php else: ?>
                    <div class="small text-muted mb-3"><?php echo (int)$cur['emp_count']; ?> employee(s) in this run</div>
                <?php endif; ?>
                <a class="btn btn-sm btn-primary" href="<?php echo $pwRoot; ?>run.php?id=<?php echo (int)$cur['id']; ?>">Open run</a>
            <?php elseif (!empty($pw['can_process'])): ?>
                <p class="small text-muted">Create a payroll period to begin.</p>
                <a class="btn btn-sm btn-primary" href="<?php echo $pwRoot; ?>periods.php">New payroll period</a>
            <?php endif; ?>
        </div></div>
    </div>

    <div class="<?php echo $pwCols; ?>">
        <div class="card h-100"><div class="card-body">
            <div class="d-flex align-items-center gap-3 mb-3">
                <span class="icon-bubble"><i class="fas fa-list-check"></i></span>
                <div><div class="metric-label">Pending payroll</div><div class="fw-semibold">Needs your action</div></div>
            </div>
            <?php if (!$pw['actions'] && !$pw['adj_pending'] && !$pw['mail_issues']): ?>
                <div class="text-center text-muted py-3"><i class="fas fa-circle-check fa-2x mb-2 text-success"></i><div class="small">All clear. Nothing waiting on you.</div></div>
            <?php endif; ?>
            <?php foreach ($pw['actions'] as $a): ?>
                <a class="soft-row" href="<?php echo h($a['url']); ?>"><span class="count-pill <?php echo h($a['tone']); ?>"><?php echo (int)$a['count']; ?></span><span class="small fw-semibold"><?php echo h($a['label']); ?></span><i class="fas fa-chevron-right ms-auto small text-muted"></i></a>
            <?php endforeach; ?>
            <?php if (!empty($pw['adj_pending'])): ?>
                <a class="soft-row" href="<?php echo $pwRoot; ?>adjustments.php"><span class="count-pill warn"><?php echo (int)$pw['adj_pending']; ?></span><span class="small fw-semibold">Corrections awaiting approval</span><i class="fas fa-chevron-right ms-auto small text-muted"></i></a>
            <?php endif; ?>
            <?php if (!empty($pw['mail_issues'])): ?>
                <a class="soft-row" href="<?php echo $pwRoot; ?>emails.php"><span class="count-pill bad"><?php echo (int)$pw['mail_issues']; ?></span><span class="small fw-semibold">Emails failed to send</span><i class="fas fa-chevron-right ms-auto small text-muted"></i></a>
            <?php endif; ?>
        </div></div>
    </div>

    <div class="<?php echo $pwCols; ?>">
        <div class="card h-100"><div class="card-body">
            <div class="d-flex align-items-center gap-3 mb-3">
                <span class="icon-bubble"><i class="fas fa-clock-rotate-left"></i></span>
                <div><div class="metric-label">Last payroll</div>
                <?php if ($pw['last_paid']): ?><div class="fw-semibold"><?php echo h($pw['last_paid']['period_name']); ?></div><?php else: ?><div class="text-muted">None paid yet</div><?php endif; ?></div>
            </div>
            <?php if ($pw['last_paid']): ?>
                <div class="metric-value mb-1"><?php echo h(payroll_money($pw['last_paid']['total_net'])); ?></div>
                <div class="small text-muted mb-3">Paid out for pay date <?php echo h(payroll_fmt_date($pw['last_paid']['pay_date'])); ?></div>
            <?php endif; ?>
            <div class="soft-row"><span class="small text-muted">Unpaid balance</span><strong class="ms-auto"><?php echo h(payroll_money($pw['unpaid_balance'])); ?></strong></div>
            <div class="soft-row"><span class="small text-muted">Next pay date</span><strong class="ms-auto"><?php echo $pw['next_pay'] ? h(payroll_fmt_date($pw['next_pay']['pay_date'])) : '—'; ?></strong></div>
        </div></div>
    </div>
<?php endif; ?>

<?php if (!empty($pw['mine'])): $m = $pw['mine']; ?>
    <div class="<?php echo $pwCols; ?>">
        <div class="card h-100"><div class="card-body">
            <div class="d-flex align-items-center gap-3 mb-3">
                <span class="icon-bubble"><i class="fas fa-file-invoice-dollar"></i></span>
                <div><div class="metric-label">My latest payslip</div><div class="fw-semibold"><?php echo h($m['period_name']); ?></div></div>
            </div>
            <div class="metric-value mb-1"><?php echo h(payroll_money($m['net_pay'])); ?> <span class="small text-muted fw-normal">net</span></div>
            <div class="small text-muted mb-3">Pay date <?php echo h(payroll_fmt_date($m['pay_date'])); ?> · <?php echo payroll_pay_badge($m['payment_status']); ?></div>
            <a class="btn btn-sm btn-primary" href="<?php echo $pwRoot; ?>payslip.php?id=<?php echo (int)$m['id']; ?>">View payslip</a>
            <a class="btn btn-sm btn-outline-secondary" href="<?php echo $pwRoot; ?>payslips.php?mine=1">All</a>
        </div></div>
    </div>
<?php endif; ?>
</div>
