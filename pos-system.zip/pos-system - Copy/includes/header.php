<?php
if (!defined('BASE_PATH')) {
    require_once dirname(__DIR__) . '/config/database.php';
}
$siteTitle = 'POS System';

$__unreadNotifCount = 0;
if (isset($_SESSION['user_id'])) {
    try {
        $__ndb = getDB();
        ensure_notifications_table($__ndb);
        $__ncstmt = $__ndb->prepare("SELECT COUNT(*) FROM notifications WHERE user_id=? AND is_read=0");
        $__ncstmt->execute([$_SESSION['user_id']]);
        $__unreadNotifCount = (int)$__ncstmt->fetchColumn();
    } catch (Throwable $e) {
        $__unreadNotifCount = 0;
    }
}
?>
<meta name="csrf-token" content="<?php echo h(csrf_token()); ?>">
<nav class="navbar navbar-expand-lg navbar-dark shadow-sm pos-topbar">
    <div class="container-fluid px-3 px-lg-4">
        <a class="navbar-brand fw-bold d-flex align-items-center" href="<?php echo BASE_PATH; ?>index.php">
            <i class="fas fa-store me-2"></i><?php echo htmlspecialchars($siteTitle); ?>
        </a>
        <button class="navbar-toggler border-0 shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-1">
                <li class="nav-item">
                    <span class="nav-link text-white-50">
                        <i class="fas fa-user-circle me-1"></i>
                        <?php echo htmlspecialchars($_SESSION['full_name'] ?? 'Guest'); ?>
                        <span class="badge bg-light text-dark ms-1"><?php echo htmlspecialchars($_SESSION['role'] ?? 'Unknown'); ?></span>
                    </span>
                </li>
                <?php if (isset($_SESSION['user_id'])): ?>
                <li class="nav-item dropdown">
                    <button class="btn btn-light btn-sm position-relative ms-lg-1" type="button" id="notifBell" data-bs-toggle="dropdown" aria-expanded="false" title="Notifications">
                        <i class="fas fa-bell"></i>
                        <span id="notifBadge" class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger<?php echo $__unreadNotifCount > 0 ? '' : ' d-none'; ?>" style="font-size:.65rem;">
                            <?php echo $__unreadNotifCount > 99 ? '99+' : $__unreadNotifCount; ?>
                        </span>
                    </button>
                    <div class="dropdown-menu dropdown-menu-end p-0 shadow" style="width:340px;max-width:90vw;" id="notifDropdown">
                        <div class="d-flex justify-content-between align-items-center px-3 py-2 border-bottom">
                            <span class="fw-semibold small"><i class="fas fa-bell me-1 text-primary"></i> Notifications</span>
                            <button type="button" class="btn btn-link btn-sm p-0 small" id="notifMarkAll">Mark all read</button>
                        </div>
                        <div id="notifList" style="max-height:360px;overflow-y:auto;">
                            <div class="text-center text-muted small py-4"><i class="fas fa-spinner fa-spin"></i> Loading…</div>
                        </div>
                    </div>
                </li>
                <?php endif; ?>
                <li class="nav-item dropdown">
                    <button class="btn btn-light btn-sm dropdown-toggle ms-lg-1" type="button" data-bs-toggle="dropdown" aria-expanded="false" title="Theme settings">
                        <i class="fas fa-palette me-1"></i><span class="d-none d-sm-inline">Theme</span>
                    </button>
                    <div class="dropdown-menu dropdown-menu-end theme-menu">
                        <div class="theme-label">Appearance</div>
                        <button class="theme-choice" type="button" onclick="setThemeMode('light')"><i class="fas fa-sun fa-fw"></i> Light mode</button>
                        <button class="theme-choice" type="button" onclick="setThemeMode('dark')"><i class="fas fa-moon fa-fw"></i> Dark mode</button>
                        <div class="dropdown-divider"></div>
                        <div class="theme-label">Accent color</div>
                        <?php foreach ([['indigo','Indigo'],['blue','Ocean Blue'],['emerald','Emerald'],['violet','Violet'],['rose','Rose'],['amber','Amber']] as $theme): ?>
                            <button class="theme-choice" type="button" data-palette="<?php echo $theme[0]; ?>">
                                <span class="theme-dot <?php echo $theme[0]; ?>"></span><?php echo $theme[1]; ?><i class="fas fa-check check"></i>
                            </button>
                        <?php endforeach; ?>
                    </div>
                </li>
                <li class="nav-item">
                    <button onclick="toggleTheme()" class="btn btn-outline-light btn-sm ms-lg-1" title="Toggle dark/light mode">
                        <i class="fas fa-moon" id="themeIcon"></i>
                    </button>
                </li>
                <li class="nav-item">
                    <a href="<?php echo BASE_PATH; ?>logout.php" class="btn btn-danger btn-sm ms-lg-1">
                        <i class="fas fa-sign-out-alt me-1"></i> Logout
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<script>
(function(){try{var t=localStorage.getItem('pos_theme');var p=localStorage.getItem('pos_palette');if(t==='dark'||t==='light')document.documentElement.setAttribute('data-pos-theme',t);if(['indigo','blue','emerald','violet','rose','amber'].indexOf(p)!==-1)document.documentElement.setAttribute('data-pos-palette',p);}catch(e){}})();
</script>
<div id="themeTransition" aria-hidden="true"></div>

<link href="<?php echo BASE_PATH; ?>assets/vendor/bootstrap/bootstrap.min.css?v=20261010" rel="stylesheet">
<link rel="stylesheet" href="<?php echo BASE_PATH; ?>assets/vendor/fontawesome/all.min.css?v=20261010">
<link rel="stylesheet" href="<?php echo BASE_PATH; ?>assets/css/custom.css?v=20261010">
<script src="<?php echo BASE_PATH; ?>assets/vendor/sweetalert2/sweetalert2.all.min.js?v=20261010"></script>
<script src="<?php echo BASE_PATH; ?>assets/vendor/bootstrap/bootstrap.bundle.min.js?v=20261010"></script>
<script src="<?php echo BASE_PATH; ?>assets/js/script.js?v=20261010"></script>
<?php if (isset($_SESSION['user_id'])): ?>
<script>
(function(){
    const API = <?php echo json_encode(BASE_PATH . 'modules/notifications_api.php'); ?>;
    const CSRF = <?php echo json_encode(csrf_token()); ?>;
    const bell = document.getElementById('notifBell');
    const dropdown = document.getElementById('notifDropdown');
    const list = document.getElementById('notifList');
    const badge = document.getElementById('notifBadge');
    const markAllBtn = document.getElementById('notifMarkAll');
    if (!bell) return;

    function timeAgo(diff) {
        diff = Math.max(0, parseInt(diff, 10) || 0);
        if (diff < 60) return 'just now';
        if (diff < 3600) return Math.floor(diff / 60) + 'm ago';
        if (diff < 86400) return Math.floor(diff / 3600) + 'h ago';
        return Math.floor(diff / 86400) + 'd ago';
    }

    function setBadge(n) {
        if (!badge) return;
        if (n > 0) { badge.textContent = n > 99 ? '99+' : n; badge.classList.remove('d-none'); }
        else { badge.classList.add('d-none'); }
    }

    function render(items) {
        if (!items.length) {
            list.innerHTML = '<div class="text-center text-muted small py-4"><i class="fas fa-bell-slash mb-2 d-block" style="font-size:1.4rem;"></i>No notifications yet</div>';
            return;
        }
        list.innerHTML = items.map(n => {
            const unread = n.is_read == 0;
            const href = n.link || '#';
            return '<a href="' + href.replace(/"/g, '&quot;') + '" class="d-block text-decoration-none text-reset px-3 py-2 border-bottom notif-item" data-id="' + n.id + '" style="background:' + (unread ? 'rgba(var(--pos-primary-rgb),.06)' : 'transparent') + ';">'
                + '<div class="d-flex justify-content-between align-items-start gap-2">'
                + '<span class="fw-semibold small">' + (unread ? '<i class="fas fa-circle text-primary me-1" style="font-size:.5rem;"></i>' : '') + escapeHtml(n.title) + '</span>'
                + '<span class="text-muted" style="font-size:.7rem;white-space:nowrap;">' + timeAgo(n.age_sec) + '</span>'
                + '</div>'
                + '<div class="small text-muted mt-1">' + escapeHtml(n.message) + '</div>'
                + '</a>';
        }).join('');

        list.querySelectorAll('.notif-item').forEach(el => {
            el.addEventListener('click', function(e) {
                const id = this.dataset.id;
                const href = this.getAttribute('href');
                fetch(API, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: 'action=mark_read&id=' + encodeURIComponent(id) + '&csrf_token=' + encodeURIComponent(CSRF) }).catch(()=>{});
                if (!href || href === '#') e.preventDefault();
            });
        });
    }

    function escapeHtml(s) {
        return String(s).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
    }

    function load() {
        fetch(API + '?action=list').then(r => r.json()).then(data => {
            if (!data.ok) return;
            render(data.items || []);
            setBadge(data.unread || 0);
        }).catch(() => {
            list.innerHTML = '<div class="text-center text-muted small py-4">Unable to load notifications.</div>';
        });
    }

    bell.addEventListener('click', load);
    if (markAllBtn) {
        markAllBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            fetch(API, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: 'action=mark_all_read&csrf_token=' + encodeURIComponent(CSRF) })
                .then(() => load()).catch(()=>{});
        });
    }

    // Poll every 60s for a fresh unread count without opening the dropdown.
    setInterval(function(){
        fetch(API + '?action=list').then(r => r.json()).then(data => { if (data.ok) setBadge(data.unread || 0); }).catch(()=>{});
    }, 60000);
})();
</script>
<?php endif; ?>
