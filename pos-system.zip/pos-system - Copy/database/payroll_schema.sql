-- NEXCORE Payroll schema. Single source of truth: config/payroll.php runs this
-- file automatically if the payroll tables are missing, and the same DDL is
-- appended to pos_system.sql. Statements are separated by a semicolon at end of line.

CREATE TABLE IF NOT EXISTS payroll_settings (
  setting_key VARCHAR(60) NOT NULL,
  setting_value VARCHAR(255) NOT NULL DEFAULT '',
  updated_by INT NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (setting_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS payroll_rules (
  id INT NOT NULL AUTO_INCREMENT,
  rule_type ENUM('sss','philhealth','pagibig','tax') NOT NULL,
  label VARCHAR(100) NOT NULL,
  effective_from DATE NOT NULL,
  effective_to DATE NULL,
  range_from DECIMAL(14,2) NOT NULL DEFAULT 0,
  range_to DECIMAL(14,2) NULL,
  rate_percent DECIMAL(8,4) NOT NULL DEFAULT 0,
  fixed_amount DECIMAL(14,2) NOT NULL DEFAULT 0,
  min_base DECIMAL(14,2) NULL,
  max_base DECIMAL(14,2) NULL,
  notes VARCHAR(255) NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_by INT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY rule_lookup (rule_type, effective_from)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS employee_salary (
  id INT NOT NULL AUTO_INCREMENT,
  employee_id INT NOT NULL,
  salary_type ENUM('monthly','daily','hourly') NOT NULL DEFAULT 'monthly',
  basic_salary DECIMAL(12,2) NOT NULL,
  pay_schedule ENUM('weekly','semi_monthly','monthly') NOT NULL DEFAULT 'semi_monthly',
  effective_from DATE NOT NULL,
  applies_sss TINYINT(1) NOT NULL DEFAULT 1,
  applies_philhealth TINYINT(1) NOT NULL DEFAULT 1,
  applies_pagibig TINYINT(1) NOT NULL DEFAULT 1,
  applies_tax TINYINT(1) NOT NULL DEFAULT 1,
  ot_eligible TINYINT(1) NOT NULL DEFAULT 1,
  notes VARCHAR(255) NULL,
  created_by INT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY emp_effective (employee_id, effective_from)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS employee_recurring_items (
  id INT NOT NULL AUTO_INCREMENT,
  employee_id INT NOT NULL,
  kind ENUM('earning','deduction') NOT NULL,
  item_name VARCHAR(80) NOT NULL,
  amount DECIMAL(12,2) NOT NULL,
  effective_from DATE NOT NULL,
  effective_to DATE NULL,
  documentation VARCHAR(255) NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_by INT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY emp_kind (employee_id, kind)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS payroll_periods (
  id INT NOT NULL AUTO_INCREMENT,
  period_name VARCHAR(100) NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  pay_date DATE NOT NULL,
  pay_schedule ENUM('weekly','semi_monthly','monthly') NOT NULL DEFAULT 'semi_monthly',
  deadline_date DATE NULL,
  notes VARCHAR(255) NULL,
  created_by INT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_period (start_date, end_date, pay_schedule)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS payroll_runs (
  id INT NOT NULL AUTO_INCREMENT,
  period_id INT NOT NULL,
  status ENUM('draft','for_review','for_approval','approved','finalized','partially_paid','paid','cancelled') NOT NULL DEFAULT 'draft',
  prepared_by INT NULL,
  submitted_at DATETIME NULL,
  reviewed_by INT NULL,
  reviewed_at DATETIME NULL,
  review_note VARCHAR(500) NULL,
  approved_by INT NULL,
  approved_at DATETIME NULL,
  approval_note VARCHAR(500) NULL,
  finalized_by INT NULL,
  finalized_at DATETIME NULL,
  cancelled_by INT NULL,
  cancelled_at DATETIME NULL,
  cancel_reason VARCHAR(500) NULL,
  total_gross DECIMAL(14,2) NOT NULL DEFAULT 0,
  total_deductions DECIMAL(14,2) NOT NULL DEFAULT 0,
  total_net DECIMAL(14,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY period_id (period_id),
  KEY status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS payroll_items (
  id INT NOT NULL AUTO_INCREMENT,
  run_id INT NOT NULL,
  employee_id INT NOT NULL,
  salary_id INT NULL,
  salary_type ENUM('monthly','daily','hourly') NOT NULL DEFAULT 'monthly',
  basic_salary DECIMAL(12,2) NOT NULL DEFAULT 0,
  monthly_basic DECIMAL(14,2) NOT NULL DEFAULT 0,
  daily_equiv DECIMAL(14,4) NOT NULL DEFAULT 0,
  hourly_equiv DECIMAL(14,4) NOT NULL DEFAULT 0,
  scheduled_days DECIMAL(6,2) NOT NULL DEFAULT 0,
  days_present DECIMAL(6,2) NOT NULL DEFAULT 0,
  paid_leave_days DECIMAL(6,2) NOT NULL DEFAULT 0,
  unpaid_leave_days DECIMAL(6,2) NOT NULL DEFAULT 0,
  absent_days DECIMAL(6,2) NOT NULL DEFAULT 0,
  late_minutes INT NOT NULL DEFAULT 0,
  undertime_minutes INT NOT NULL DEFAULT 0,
  ot_hours DECIMAL(7,2) NOT NULL DEFAULT 0,
  detected_json TEXT NULL,
  issues TEXT NULL,
  validated TINYINT(1) NOT NULL DEFAULT 0,
  validated_by INT NULL,
  validated_at DATETIME NULL,
  validation_note VARCHAR(255) NULL,
  basic_pay DECIMAL(14,2) NOT NULL DEFAULT 0,
  gross_pay DECIMAL(14,2) NOT NULL DEFAULT 0,
  total_deductions DECIMAL(14,2) NOT NULL DEFAULT 0,
  net_pay DECIMAL(14,2) NOT NULL DEFAULT 0,
  calculated_at DATETIME NULL,
  amount_paid DECIMAL(14,2) NOT NULL DEFAULT 0,
  payment_status ENUM('unpaid','partial','paid') NOT NULL DEFAULT 'unpaid',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_run_emp (run_id, employee_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS payroll_earnings (
  id INT NOT NULL AUTO_INCREMENT,
  item_id INT NOT NULL,
  earning_type VARCHAR(40) NOT NULL,
  description VARCHAR(150) NOT NULL,
  amount DECIMAL(14,2) NOT NULL,
  source ENUM('auto','manual','adjustment') NOT NULL DEFAULT 'auto',
  adjustment_id INT NULL,
  created_by INT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY item_id (item_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS payroll_deductions (
  id INT NOT NULL AUTO_INCREMENT,
  item_id INT NOT NULL,
  deduction_type VARCHAR(40) NOT NULL,
  description VARCHAR(150) NOT NULL,
  amount DECIMAL(14,2) NOT NULL,
  source ENUM('auto','manual','adjustment') NOT NULL DEFAULT 'auto',
  adjustment_id INT NULL,
  created_by INT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY item_id (item_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS payroll_payments (
  id INT NOT NULL AUTO_INCREMENT,
  run_id INT NOT NULL,
  item_id INT NOT NULL,
  amount DECIMAL(14,2) NOT NULL,
  payment_method ENUM('cash','bank_transfer','ewallet','cheque','other') NOT NULL DEFAULT 'bank_transfer',
  reference_no VARCHAR(80) NULL,
  paid_date DATE NOT NULL,
  notes VARCHAR(255) NULL,
  idem_key VARCHAR(80) NULL,
  recorded_by INT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_idem (idem_key),
  KEY item_id (item_id),
  KEY run_id (run_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS payslips (
  id INT NOT NULL AUTO_INCREMENT,
  item_id INT NOT NULL,
  run_id INT NOT NULL,
  employee_id INT NOT NULL,
  reference_no VARCHAR(40) NOT NULL,
  revision INT NOT NULL DEFAULT 0,
  generated_by INT NULL,
  generated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  email_status ENUM('pending','sent','failed','skipped') NOT NULL DEFAULT 'pending',
  emailed_at DATETIME NULL,
  last_viewed_at DATETIME NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_item (item_id),
  UNIQUE KEY uniq_ref (reference_no),
  KEY employee_id (employee_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS payroll_adjustments (
  id INT NOT NULL AUTO_INCREMENT,
  run_id INT NOT NULL,
  item_id INT NOT NULL,
  adj_type ENUM('earning','deduction') NOT NULL,
  description VARCHAR(150) NOT NULL,
  amount DECIMAL(14,2) NOT NULL,
  reason VARCHAR(500) NOT NULL,
  status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  requested_by INT NULL,
  requested_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  decided_by INT NULL,
  decided_at DATETIME NULL,
  decision_note VARCHAR(500) NULL,
  net_before DECIMAL(14,2) NULL,
  net_after DECIMAL(14,2) NULL,
  PRIMARY KEY (id),
  KEY run_id (run_id),
  KEY status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS payroll_approvals (
  id INT NOT NULL AUTO_INCREMENT,
  run_id INT NOT NULL,
  action VARCHAR(40) NOT NULL,
  from_status VARCHAR(30) NULL,
  to_status VARCHAR(30) NULL,
  user_id INT NULL,
  remarks VARCHAR(500) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY run_id (run_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS email_logs (
  id INT NOT NULL AUTO_INCREMENT,
  recipient VARCHAR(150) NOT NULL,
  subject VARCHAR(200) NOT NULL,
  body MEDIUMTEXT NULL,
  event_type VARCHAR(40) NOT NULL,
  ref_table VARCHAR(40) NULL,
  ref_id INT NULL,
  status ENUM('pending','sent','failed') NOT NULL DEFAULT 'pending',
  error_message VARCHAR(255) NULL,
  attempts INT NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_attempt_at DATETIME NULL,
  PRIMARY KEY (id),
  KEY status (status),
  KEY ref (ref_table, ref_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
