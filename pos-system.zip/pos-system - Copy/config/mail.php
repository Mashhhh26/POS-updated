<?php
/**
 * HRMS SMTP mail service.
 *
 * Credentials are intentionally NOT stored in the database. Create
 * config/mail.local.php from mail.local.php.example and fill it in locally.
 * PHPMailer is optional (found automatically in several folders); without it a built-in SMTP client is used.
 */
if (!defined('BASE_PATH')) {
    require_once __DIR__ . '/database.php';
}

$localMailConfig = __DIR__ . '/mail.local.php';
if (is_file($localMailConfig)) {
    require_once $localMailConfig;
}

if (!defined('MAIL_HOST')) define('MAIL_HOST', 'smtp.gmail.com');
if (!defined('MAIL_PORT')) define('MAIL_PORT', 587);
if (!defined('MAIL_ENCRYPTION')) define('MAIL_ENCRYPTION', 'tls');
if (!defined('MAIL_USERNAME')) define('MAIL_USERNAME', '');
if (!defined('MAIL_PASSWORD')) define('MAIL_PASSWORD', '');
if (!defined('MAIL_FROM_ADDRESS')) define('MAIL_FROM_ADDRESS', MAIL_USERNAME);
if (!defined('MAIL_FROM_NAME')) define('MAIL_FROM_NAME', 'POS System HRMS');
if (!defined('MAIL_DEBUG')) define('MAIL_DEBUG', false);
if (!defined('MAIL_VERIFY_PEER')) define('MAIL_VERIFY_PEER', true);

// ------------------------------------------------------------------
// PHPMailer discovery. It is NOT bundled (separate download), so look in every
// common place: the documented folder, Composer's layout, and the folder names
// you get from extracting the GitHub zip.
// ------------------------------------------------------------------
function mailer_search_dirs(): array {
    $v = __DIR__ . '/../vendor';
    return [
        $v . '/phpmailer/src',
        $v . '/phpmailer/phpmailer/src',          // Composer: composer require phpmailer/phpmailer
        $v . '/PHPMailer/src',
        $v . '/PHPMailer-master/src',
        $v . '/phpmailer-master/src',
        $v . '/PHPMailer-6.9.1/src',
        __DIR__ . '/../lib/phpmailer/src',
        __DIR__ . '/../phpmailer/src',
    ];
}

function mailer_src_dir(): ?string {
    static $found = false;
    if ($found !== false) return $found;
    $dirs = mailer_search_dirs();
    foreach (array_merge(glob(__DIR__ . '/../vendor/*/src', GLOB_ONLYDIR) ?: [], glob(__DIR__ . '/../vendor/*/*/src', GLOB_ONLYDIR) ?: []) as $g) $dirs[] = $g;
    foreach ($dirs as $d) {
        if (is_file($d . '/PHPMailer.php') && is_file($d . '/SMTP.php') && is_file($d . '/Exception.php')) {
            return $found = realpath($d) ?: $d;
        }
    }
    return $found = null;
}

function mailer_available(): bool {
    return mailer_src_dir() !== null;
}

function smtp_credentials_ok(): bool {
    return MAIL_HOST !== '' && MAIL_USERNAME !== '' && MAIL_PASSWORD !== '' && MAIL_FROM_ADDRESS !== '';
}

// "Configured" now means the credentials are filled in. PHPMailer is optional because
// a built-in SMTP client is used when it is not installed.
function smtp_is_configured(): bool {
    return smtp_credentials_ok();
}

// Everything the Settings page needs to tell the admin exactly what is wrong.
function mail_diagnostics(): array {
    $cfgDir = realpath(__DIR__) ?: __DIR__;
    $cfgFile = $cfgDir . DIRECTORY_SEPARATOR . 'mail.local.php';
    $hasCfg = is_file($cfgFile);
    $similar = [];
    foreach (glob($cfgDir . '/mail.local*') ?: [] as $f) {
        if (basename($f) !== 'mail.local.php' && basename($f) !== 'mail.local.php.example') $similar[] = basename($f);
    }
    $problems = [];
    if (!$hasCfg) {
        $problems[] = 'config/mail.local.php was not found. It must be exactly here: ' . $cfgFile
            . ($similar ? ' (found "' . implode('", "', $similar) . '" instead - rename it to mail.local.php; Windows often hides a trailing .txt)' : '')
            . '. If you recently extracted a new version of the system, copy your old mail.local.php into the new config folder - it is not part of the zip.';
    } else {
        if (MAIL_HOST === '') $problems[] = 'MAIL_HOST is empty.';
        if (MAIL_USERNAME === '') $problems[] = 'MAIL_USERNAME is empty.';
        if (MAIL_PASSWORD === '') $problems[] = 'MAIL_PASSWORD is empty.';
        if (MAIL_FROM_ADDRESS === '') $problems[] = 'MAIL_FROM_ADDRESS is empty.';
        if (MAIL_USERNAME === 'your-account@gmail.com' || MAIL_PASSWORD === 'your-app-password') $problems[] = 'mail.local.php still contains the example placeholders (your-account@gmail.com / your-app-password).';
    }
    $enc = strtolower((string)MAIL_ENCRYPTION);
    if (!extension_loaded('openssl') && ($enc === 'tls' || $enc === 'ssl')) $problems[] = 'The PHP openssl extension is disabled. Enable extension=openssl in php.ini and restart Apache.';
    $dir = mailer_src_dir();
    return [
        'config_path' => $cfgFile, 'config_found' => $hasCfg, 'similar_files' => $similar,
        'phpmailer_dir' => $dir, 'transport' => $dir ? 'PHPMailer' : 'Built-in SMTP client',
        'host' => MAIL_HOST, 'port' => (int)MAIL_PORT, 'encryption' => $enc,
        'openssl' => extension_loaded('openssl'), 'credentials_ok' => smtp_credentials_ok(),
        'problems' => $problems,
    ];
}

function mail_mask(string $text): string {
    foreach ([MAIL_PASSWORD] as $secret) if ($secret !== '') $text = str_replace($secret, '***', $text);
    return $text;
}

// Used when PHPMailer is not installed. Plain SMTP over TCP with STARTTLS (587) or SSL (465), AUTH LOGIN.
function smtp_native_send(string $to, string $subject, string $html): array {
    $host = MAIL_HOST;
    $port = (int)MAIL_PORT;
    $enc = strtolower((string)MAIL_ENCRYPTION);
    $verify = !defined('MAIL_VERIFY_PEER') || MAIL_VERIFY_PEER;
    $ctx = stream_context_create(['ssl' => ['verify_peer' => $verify, 'verify_peer_name' => $verify, 'allow_self_signed' => !$verify, 'peer_name' => $host]]);
    $errno = 0; $errstr = '';
    $fp = @stream_socket_client(($enc === 'ssl' ? 'ssl://' : 'tcp://') . $host . ':' . $port, $errno, $errstr, 15, STREAM_CLIENT_CONNECT, $ctx);
    if (!$fp) {
        return ['ok' => false, 'message' => "Could not connect to $host:$port ($errstr). Check the host/port, your internet connection, and that a firewall/antivirus is not blocking it."];
    }
    stream_set_timeout($fp, 15);
    $read = function () use ($fp) {
        $text = ''; $code = 0;
        while (($line = fgets($fp, 515)) !== false) {
            $text .= $line;
            $code = (int)substr($line, 0, 3);
            if (!isset($line[3]) || $line[3] === ' ') break;   // last line of the reply
        }
        return [$code, trim($text)];
    };
    $send = function ($cmd) use ($fp) { fwrite($fp, $cmd . "\r\n"); };
    $expect = function (array $ok, $step) use ($read) {
        list($code, $text) = $read();
        if (!in_array($code, $ok, true)) throw new Exception($step . ' failed: ' . ($text !== '' ? $text : 'no response from the server (timeout?)'));
    };
    $ehlo = 'EHLO ' . (preg_replace('/[^A-Za-z0-9.-]/', '', (string)gethostname()) ?: 'localhost');
    try {
        $expect([220], 'Server greeting');
        $send($ehlo); $expect([250], 'EHLO');
        if ($enc !== 'ssl' && $enc !== 'none' && $enc !== '') {
            $send('STARTTLS'); $expect([220], 'STARTTLS');
            if (!@stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
                throw new Exception('Could not start TLS encryption. On XAMPP/Windows set openssl.cafile in php.ini, or add define(\'MAIL_VERIFY_PEER\', false); to config/mail.local.php for testing.');
            }
            $send($ehlo); $expect([250], 'EHLO after TLS');
        }
        $send('AUTH LOGIN'); $expect([334], 'AUTH LOGIN');
        $send(base64_encode(MAIL_USERNAME)); $expect([334], 'Username');
        $send(base64_encode(MAIL_PASSWORD)); $expect([235], 'Login (check the username and, for Gmail, use an App Password)');
        $send('MAIL FROM:<' . MAIL_FROM_ADDRESS . '>'); $expect([250], 'MAIL FROM');
        $send('RCPT TO:<' . $to . '>'); $expect([250, 251], 'RCPT TO');
        $send('DATA'); $expect([354], 'DATA');
        $enc64 = function ($t) { return '=?UTF-8?B?' . base64_encode($t) . '?='; };
        $headers = [
            'Date: ' . date('r'),
            'From: ' . $enc64(MAIL_FROM_NAME) . ' <' . MAIL_FROM_ADDRESS . '>',
            'To: <' . $to . '>',
            'Subject: ' . $enc64($subject),
            'Message-ID: <' . bin2hex(random_bytes(8)) . '@' . (preg_replace('/[^A-Za-z0-9.-]/', '', $host) ?: 'localhost') . '>',
            'MIME-Version: 1.0',
            'Content-Type: text/html; charset=UTF-8',
            'Content-Transfer-Encoding: base64',
        ];
        // base64 body never contains a leading dot, so no dot-stuffing is needed
        fwrite($fp, implode("\r\n", $headers) . "\r\n\r\n" . chunk_split(base64_encode($html), 76, "\r\n") . ".\r\n");
        $expect([250], 'Message delivery');
        $send('QUIT');
        fclose($fp);
        return ['ok' => true, 'message' => 'Email sent successfully.'];
    } catch (Throwable $e) {
        if (is_resource($fp)) { @fwrite($fp, "QUIT\r\n"); @fclose($fp); }
        error_log('POS SMTP (built-in) error: ' . mail_mask($e->getMessage()));
        return ['ok' => false, 'message' => 'SMTP send failed: ' . mail_mask($e->getMessage())];
    }
}

function send_hr_email_raw(string $to, string $subject, string $htmlBody, string $altBody = ''): array {
    if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
        return ['ok' => false, 'message' => 'Invalid recipient email address.'];
    }
    if (!smtp_credentials_ok()) {
        $d = mail_diagnostics();
        return ['ok' => false, 'message' => 'SMTP is not configured. ' . ($d['problems'] ? $d['problems'][0] : 'Fill in the credentials in config/mail.local.php.')];
    }

    $dir = mailer_src_dir();
    if ($dir === null) {
        return smtp_native_send($to, $subject, $htmlBody);   // PHPMailer not installed: use the built-in client
    }

    require_once $dir . '/Exception.php';
    require_once $dir . '/PHPMailer.php';
    require_once $dir . '/SMTP.php';

    try {
        $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
        $mail->isSMTP();
        $mail->Host = MAIL_HOST;
        $mail->Port = (int) MAIL_PORT;
        $mail->SMTPAuth = true;
        $mail->Username = MAIL_USERNAME;
        $mail->Password = MAIL_PASSWORD;
        $mail->SMTPSecure = strtolower(MAIL_ENCRYPTION) === 'ssl'
            ? \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS
            : \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        if (defined('MAIL_VERIFY_PEER') && !MAIL_VERIFY_PEER) {
            $mail->SMTPOptions = ['ssl' => ['verify_peer' => false, 'verify_peer_name' => false, 'allow_self_signed' => true]];
        }
        $mail->CharSet = 'UTF-8';
        $mail->SMTPDebug = MAIL_DEBUG ? 2 : 0;
        $mail->Timeout = 15;
        $mail->setFrom(MAIL_FROM_ADDRESS, MAIL_FROM_NAME);
        $mail->addAddress($to);
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $htmlBody;
        $mail->AltBody = $altBody !== '' ? $altBody : trim(strip_tags(str_replace(['<br>', '<br/>', '<br />'], "\n", $htmlBody)));
        $mail->send();
        return ['ok' => true, 'message' => 'Email sent successfully.'];
    } catch (Throwable $e) {
        error_log('POS SMTP error: ' . mail_mask($e->getMessage()));
        return ['ok' => false, 'message' => 'SMTP send failed: ' . mail_mask($e->getMessage())];
    }
}

// Records every outgoing email (sent or failed) in email_logs so delivery status can be
// reviewed and failed emails retried from Payroll > Email Delivery Log.
function mail_log_result(string $to, string $subject, string $html, array $res): void {
    try {
        if (!function_exists('getDB')) return;
        if (!function_exists('payroll_ensure_schema')) require_once __DIR__ . '/payroll.php';
        $db = getDB();
        payroll_ensure_schema($db);
        $ok = !empty($res['ok']);
        $db->prepare("INSERT INTO email_logs(recipient,subject,body,event_type,status,error_message,attempts,last_attempt_at) VALUES(?,?,?,?,?,?,1,NOW())")
           ->execute([substr($to, 0, 150), substr($subject, 0, 200), $html, 'general', $ok ? 'sent' : 'failed', $ok ? null : substr((string)($res['message'] ?? ''), 0, 255)]);
    } catch (Throwable $e) {
        error_log('mail_log_result error: ' . $e->getMessage());
    }
}

// Public entry point used across the app. Pass $log=false only when the caller already
// manages its own email_logs row (payroll_dispatch_email does).
function send_hr_email(string $to, string $subject, string $htmlBody, string $altBody = '', bool $log = true): array {
    $res = send_hr_email_raw($to, $subject, $htmlBody, $altBody);
    if ($log) mail_log_result($to, $subject, $htmlBody, $res);
    return $res;
}
