<?php
/**
 * NEXCORE Payroll engine.
 *
 * - payroll_ensure_schema()  creates the payroll tables (database/payroll_schema.sql) if missing
 * - time records / validation / computation / payments / payslips / email log helpers
 *
 * IMPORTANT: the government contribution + tax tables seeded here are SAMPLE
 * values for demo/school use. They live in the payroll_rules table with
 * effective dates so they can be changed without touching code. Validate them
 * against the current official SSS / PhilHealth / Pag-IBIG / BIR tables before
 * using this for real salaries.
 */
if (!defined('BASE_PATH')) {
    require_once __DIR__ . '/database.php';
}
require_once __DIR__ . '/mail.php';

// ------------------------------------------------------------------
// Labels / formatting
// ------------------------------------------------------------------
function payroll_status_meta(): array {
    return [
        'draft'          => ['Draft', 'secondary'],
        'for_review'     => ['For Review', 'info'],
        'for_approval'   => ['For Approval', 'warning'],
        'approved'       => ['Approved', 'primary'],
        'finalized'      => ['Finalized', 'dark'],
        'partially_paid' => ['Partially Paid', 'warning'],
        'paid'           => ['Paid', 'success'],
        'cancelled'      => ['Cancelled', 'danger'],
    ];
}
function payroll_status_badge(string $s): string {
    $m = payroll_status_meta()[$s] ?? [$s, 'secondary'];
    $txt = ($m[1] === 'warning' || $m[1] === 'info') ? ' text-dark' : '';
    return '<span class="badge bg-' . $m[1] . $txt . '">' . h($m[0]) . '</span>';
}
function payroll_pay_badge(string $s): string {
    $map = ['unpaid' => ['Unpaid', 'secondary'], 'partial' => ['Partial', 'warning text-dark'], 'paid' => ['Paid', 'success']];
    $m = $map[$s] ?? [$s, 'secondary'];
    return '<span class="badge bg-' . $m[1] . '">' . h($m[0]) . '</span>';
}
function payroll_schedule_label(string $s): string {
    $map = ['weekly' => 'Weekly', 'semi_monthly' => 'Semi-monthly', 'monthly' => 'Monthly'];
    return $map[$s] ?? $s;
}
function payroll_money($v): string {
    return '₱' . number_format((float)$v, 2);
}
function payroll_fmt_date(?string $d): string {
    return ($d && $d !== '0000-00-00') ? date('M d, Y', strtotime($d)) : '—';
}
function payroll_is_date($s): bool {
    if (!is_string($s) || !preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $s, $m)) return false;
    return checkdate((int)$m[2], (int)$m[3], (int)$m[1]);
}
function payroll_periods_per_month(string $schedule): float {
    if ($schedule === 'weekly') return 52 / 12;
    if ($schedule === 'semi_monthly') return 2.0;
    return 1.0;
}
function payroll_redirect(string $page, ?string $ok = null, ?string $err = null, array $params = []): void {
    if ($ok !== null) $params['ok'] = $ok;
    if ($err !== null) $params['err'] = $err;
    header('Location: ' . $page . ($params ? '?' . http_build_query($params) : ''));
    exit();
}

// ------------------------------------------------------------------
// Settings + schema bootstrap
// ------------------------------------------------------------------
function payroll_default_settings(): array {
    return [
        'company_name'             => 'NEXCORE',
        'company_address'          => '',
        'shift_start'              => '09:00',
        'shift_end'                => '18:00',
        'grace_minutes'            => '5',
        'standard_hours_per_day'   => '8',
        'days_per_month_factor'    => '26.08',
        'working_weekdays'         => '1,2,3,4,5,6',
        'ot_multiplier'            => '1.25',
        'unpaid_leave_types'       => '',
        'notify_finalized'         => '1',
        'notify_payslip_available' => '1',
        'notify_payment_recorded'  => '1',
        'notify_adjustment_approved' => '1',
    ];
}

function payroll_settings(PDO $db, bool $refresh = false): array {
    static $cache = null;
    if ($cache !== null && !$refresh) return $cache;
    $s = payroll_default_settings();
    try {
        foreach ($db->query("SELECT setting_key, setting_value FROM payroll_settings")->fetchAll() as $r) {
            if (array_key_exists($r['setting_key'], $s)) $s[$r['setting_key']] = $r['setting_value'];
        }
    } catch (Throwable $e) {
        // table not created yet - defaults apply
    }
    $cache = $s;
    return $cache;
}

function payroll_ensure_schema(PDO $db): void {
    static $done = false;
    if ($done) return;
    $done = true;
    try {
        $exists = $db->query("SHOW TABLES LIKE 'payroll_runs'")->fetchColumn();
        if (!$exists) {
            $sql = file_get_contents(__DIR__ . '/../database/payroll_schema.sql');
            foreach (preg_split('/;\s*[\r\n]+/', (string)$sql) as $stmt) {
                $stmt = trim(preg_replace('/^\s*--.*$/m', '', $stmt));
                if ($stmt !== '') $db->exec($stmt);
            }
        }
        // Seed only when settings are missing, so normal page loads stay cheap.
        $have = (int)$db->query("SELECT COUNT(*) FROM payroll_settings")->fetchColumn();
        if ($have < count(payroll_default_settings())) payroll_seed_defaults($db);
    } catch (Throwable $e) {
        error_log('payroll_ensure_schema error: ' . $e->getMessage());
    }
}

function payroll_seed_defaults(PDO $db): void {
    $ins = $db->prepare("INSERT IGNORE INTO payroll_settings(setting_key, setting_value) VALUES(?, ?)");
    foreach (payroll_default_settings() as $k => $v) $ins->execute([$k, $v]);

    if ((int)$db->query("SELECT COUNT(*) FROM payroll_rules")->fetchColumn() === 0) {
        $r = $db->prepare("INSERT INTO payroll_rules(rule_type,label,effective_from,range_from,range_to,rate_percent,fixed_amount,min_base,max_base,notes) VALUES(?,?,?,?,?,?,?,?,?,?)");
        $note = 'SAMPLE VALUE for demo - verify against the current official table before real use';
        $r->execute(['sss', 'SSS employee share (sample)', '2025-01-01', 0, null, 5, 0, 5000, 35000, $note]);
        $r->execute(['philhealth', 'PhilHealth employee share (sample)', '2025-01-01', 0, null, 2.5, 0, 10000, 100000, $note]);
        $r->execute(['pagibig', 'Pag-IBIG employee share (sample)', '2025-01-01', 0, null, 2, 0, null, 10000, $note]);
        $brackets = [
            [0, 20833.33, 0, 0], [20833.33, 33333.33, 0, 15], [33333.33, 66666.67, 1875, 20],
            [66666.67, 166666.67, 8541.67, 25], [166666.67, 666666.67, 33541.67, 30], [666666.67, null, 183541.67, 35],
        ];
        foreach ($brackets as $b) {
            $r->execute(['tax', 'Withholding tax - monthly bracket (sample)', '2025-01-01', $b[0], $b[1], $b[3], $b[2], null, null, $note]);
        }
    }

    $has = (int)$db->query("SELECT COUNT(*) FROM permissions WHERE permission_name='view_payroll'")->fetchColumn();
    if ($has === 0) {
        $perms = [
            'view_payroll' => 'View payroll periods, runs, payslips and payroll history',
            'manage_payroll_setup' => 'Manage employee salary setup and recurring allowances/deductions',
            'process_payroll' => 'Create payroll periods/runs, validate records, calculate and submit payroll',
            'review_payroll' => 'Review submitted payroll runs',
            'approve_payroll' => 'Approve and finalize payroll runs and corrections',
            'record_payroll_payments' => 'Record payroll payments',
            'configure_payroll' => 'Configure contribution/tax rules and payroll settings',
        ];
        $p = $db->prepare("INSERT IGNORE INTO permissions(permission_name,module,description) VALUES(?,?,?)");
        foreach ($perms as $name => $desc) $p->execute([$name, 'payroll', $desc]);
        $grants = [
            'Admin'   => array_keys($perms),
            'HRM'     => ['view_payroll', 'manage_payroll_setup', 'process_payroll', 'review_payroll'],
            'Finance' => ['view_payroll', 'review_payroll', 'approve_payroll', 'record_payroll_payments'],
        ];
        $g = $db->prepare("INSERT IGNORE INTO role_permissions(role_id,permission_id) SELECT r.id,p.id FROM roles r JOIN permissions p ON p.permission_name=? WHERE r.role_name=?");
        foreach ($grants as $role => $list) foreach ($list as $perm) $g->execute([$perm, $role]);
    }
}

// ------------------------------------------------------------------
// Lookups
// ------------------------------------------------------------------
function payroll_current_salary(PDO $db, int $employeeId, string $asOf): ?array {
    $q = $db->prepare("SELECT * FROM employee_salary WHERE employee_id=? AND effective_from<=? ORDER BY effective_from DESC, id DESC LIMIT 1");
    $q->execute([$employeeId, $asOf]);
    $row = $q->fetch();
    return $row ?: null;
}

function payroll_rule_for(PDO $db, string $type, string $asOf): ?array {
    $q = $db->prepare("SELECT * FROM payroll_rules WHERE rule_type=? AND is_active=1 AND effective_from<=? AND (effective_to IS NULL OR effective_to>=?) ORDER BY effective_from DESC, id DESC LIMIT 1");
    $q->execute([$type, $asOf, $asOf]);
    $row = $q->fetch();
    return $row ?: null;
}

function payroll_tax_brackets(PDO $db, string $asOf): array {
    $q = $db->prepare("SELECT MAX(effective_from) FROM payroll_rules WHERE rule_type='tax' AND is_active=1 AND effective_from<=? AND (effective_to IS NULL OR effective_to>=?)");
    $q->execute([$asOf, $asOf]);
    $eff = $q->fetchColumn();
    if (!$eff) return [];
    $b = $db->prepare("SELECT * FROM payroll_rules WHERE rule_type='tax' AND is_active=1 AND effective_from=? ORDER BY range_from ASC");
    $b->execute([$eff]);
    return $b->fetchAll();
}

function payroll_contribution_monthly(?array $rule, float $monthlyBasic): float {
    if (!$rule) return 0.0;
    $base = $monthlyBasic;
    if ($rule['min_base'] !== null) $base = max($base, (float)$rule['min_base']);
    if ($rule['max_base'] !== null) $base = min($base, (float)$rule['max_base']);
    return round($base * ((float)$rule['rate_percent'] / 100) + (float)$rule['fixed_amount'], 2);
}

function payroll_tax_monthly(array $brackets, float $taxable): float {
    foreach ($brackets as $b) {
        $from = (float)$b['range_from'];
        $to = $b['range_to'] === null ? null : (float)$b['range_to'];
        if ($taxable >= $from && ($to === null || $taxable < $to)) {
            return round((float)$b['fixed_amount'] + ((float)$b['rate_percent'] / 100) * ($taxable - $from), 2);
        }
    }
    return 0.0;
}

function payroll_current_employee(PDO $db): ?array {
    if (empty($_SESSION['user_id'])) return null;
    $q = $db->prepare("SELECT * FROM employees WHERE user_id=? LIMIT 1");
    $q->execute([$_SESSION['user_id']]);
    $row = $q->fetch();
    return $row ?: null;
}

// Active users who hold a permission (Admin role always counts).
function payroll_users_with_permission(PDO $db, string $perm, int $excludeUserId = 0): array {
    $q = $db->prepare("SELECT u.id, u.full_name, u.email FROM users u
        WHERE u.is_active=1 AND u.id<>?
          AND (u.role_id=1 OR EXISTS (SELECT 1 FROM role_permissions rp JOIN permissions p ON p.id=rp.permission_id WHERE rp.role_id=u.role_id AND p.permission_name=?))");
    $q->execute([$excludeUserId, $perm]);
    return $q->fetchAll();
}

function payroll_log_approval(PDO $db, int $runId, string $action, ?string $from, ?string $to, ?string $remarks = null): void {
    $db->prepare("INSERT INTO payroll_approvals(run_id,action,from_status,to_status,user_id,remarks) VALUES(?,?,?,?,?,?)")
       ->execute([$runId, $action, $from, $to, $_SESSION['user_id'] ?? null, $remarks]);
}

// ------------------------------------------------------------------
// Step 03/04: collect + validate time records
// ------------------------------------------------------------------
function payroll_minutes(?string $t): ?int {
    if ($t === null || $t === '') return null;
    $p = explode(':', $t);
    return ((int)$p[0]) * 60 + (int)($p[1] ?? 0);
}

function payroll_working_dates(string $start, string $end, array $weekdays, ?string $hireDate): array {
    $out = [];
    $d = new DateTimeImmutable($start);
    $e = new DateTimeImmutable($end);
    while ($d <= $e) {
        $ds = $d->format('Y-m-d');
        if (in_array((int)$d->format('N'), $weekdays, true) && ($hireDate === null || $hireDate === '' || $ds >= $hireDate)) {
            $out[] = $ds;
        }
        $d = $d->modify('+1 day');
    }
    return $out;
}

function payroll_collect_time_records(PDO $db, array $emp, array $period, array $S): array {
    $weekdays = array_map('intval', array_filter(array_map('trim', explode(',', $S['working_weekdays'])), 'strlen'));
    $dates = payroll_working_dates($period['start_date'], $period['end_date'], $weekdays, $emp['hire_date'] ?? null);
    $unpaidTypes = array_values(array_filter(array_map('trim', explode(',', $S['unpaid_leave_types'])), 'strlen'));

    $r = [
        'scheduled_days' => count($dates), 'days_present' => 0.0, 'paid_leave_days' => 0.0,
        'period_days' => count(payroll_working_dates($period['start_date'], $period['end_date'], $weekdays, null)),
        'unpaid_leave_days' => 0.0, 'absent_days' => 0.0, 'late_minutes' => 0,
        'undertime_minutes' => 0, 'ot_hours' => 0.0, 'issues' => [], 'has_user' => !empty($emp['user_id']),
    ];

    // Approved leave, by date
    $leaveByDate = [];
    $lv = $db->prepare("SELECT leave_type, start_date, end_date FROM leaves WHERE employee_id=? AND status='approved' AND end_date>=? AND start_date<=?");
    $lv->execute([$emp['id'], $period['start_date'], $period['end_date']]);
    foreach ($lv->fetchAll() as $l) {
        $d = new DateTimeImmutable(max($l['start_date'], $period['start_date']));
        $e = new DateTimeImmutable(min($l['end_date'], $period['end_date']));
        while ($d <= $e) {
            $leaveByDate[$d->format('Y-m-d')] = $l['leave_type'];
            $d = $d->modify('+1 day');
        }
    }

    // Attendance, by date (attendance is keyed by user account)
    $att = [];
    if ($r['has_user']) {
        $q = $db->prepare("SELECT date, time_in, time_out, status FROM attendance WHERE user_id=? AND date BETWEEN ? AND ?");
        $q->execute([$emp['user_id'], $period['start_date'], $period['end_date']]);
        foreach ($q->fetchAll() as $a) {
            $k = $a['date'];
            if (!isset($att[$k])) {
                $att[$k] = $a;
            } else {
                if ($a['time_in'] !== null && ($att[$k]['time_in'] === null || $a['time_in'] < $att[$k]['time_in'])) $att[$k]['time_in'] = $a['time_in'];
                if ($a['time_out'] !== null && ($att[$k]['time_out'] === null || $a['time_out'] > $att[$k]['time_out'])) $att[$k]['time_out'] = $a['time_out'];
            }
        }
    } else {
        $r['issues'][] = 'No linked user account, so attendance cannot be read. Enter the time records manually when validating.';
    }

    $shiftStart = payroll_minutes($S['shift_start']);
    $shiftEnd = payroll_minutes($S['shift_end']);
    $grace = (int)$S['grace_minutes'];

    foreach ($dates as $ds) {
        if (isset($leaveByDate[$ds])) {
            if (in_array($leaveByDate[$ds], $unpaidTypes, true)) $r['unpaid_leave_days'] += 1;
            else $r['paid_leave_days'] += 1;
            continue;
        }
        if (!$r['has_user']) continue;
        if (!isset($att[$ds])) {
            $r['absent_days'] += 1;
            $r['issues'][] = "No attendance record on $ds (counted as absent - confirm).";
            continue;
        }
        $a = $att[$ds];
        if ($a['status'] === 'absent') {
            $r['absent_days'] += 1;
            $r['issues'][] = "Marked absent on $ds.";
            continue;
        }
        if ($a['status'] === 'half-day') {
            $r['days_present'] += 0.5;
            $r['absent_days'] += 0.5;
            $r['issues'][] = "Half-day on $ds (counted as 0.5 absent - confirm).";
            continue;
        }
        $r['days_present'] += 1;
        $in = payroll_minutes($a['time_in']);
        $out = payroll_minutes($a['time_out']);
        if ($in === null) {
            $r['issues'][] = "Missing time-in on $ds.";
        } elseif ($in - $shiftStart > $grace) {
            $r['late_minutes'] += ($in - $shiftStart);
        }
        if ($out === null) {
            $r['issues'][] = "Missing time-out on $ds (undertime/overtime not computed for that day).";
        } elseif ($out < $shiftEnd) {
            $r['undertime_minutes'] += ($shiftEnd - $out);
        } elseif ($out > $shiftEnd) {
            $r['ot_hours'] += ($out - $shiftEnd) / 60;
        }
    }
    $r['ot_hours'] = round($r['ot_hours'], 2);
    return $r;
}

function payroll_generate_items(PDO $db, int $runId): array {
    $run = $db->prepare("SELECT * FROM payroll_runs WHERE id=?");
    $run->execute([$runId]);
    $run = $run->fetch();
    if (!$run) throw new Exception('Payroll run not found.');
    $per = $db->prepare("SELECT * FROM payroll_periods WHERE id=?");
    $per->execute([$run['period_id']]);
    $period = $per->fetch();
    $S = payroll_settings($db);

    $emps = $db->query("SELECT * FROM employees WHERE status IN ('active','on_leave') ORDER BY last_name, first_name")->fetchAll();
    $result = ['created' => 0, 'refreshed' => 0, 'kept' => 0, 'excluded' => []];

    $find = $db->prepare("SELECT id, validated FROM payroll_items WHERE run_id=? AND employee_id=?");
    $insert = $db->prepare("INSERT INTO payroll_items(run_id,employee_id,salary_id,salary_type,basic_salary,scheduled_days,days_present,paid_leave_days,unpaid_leave_days,absent_days,late_minutes,undertime_minutes,ot_hours,detected_json,issues) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
    $update = $db->prepare("UPDATE payroll_items SET salary_id=?,salary_type=?,basic_salary=?,scheduled_days=?,days_present=?,paid_leave_days=?,unpaid_leave_days=?,absent_days=?,late_minutes=?,undertime_minutes=?,ot_hours=?,detected_json=?,issues=?,calculated_at=NULL WHERE id=?");

    foreach ($emps as $emp) {
        $name = $emp['first_name'] . ' ' . $emp['last_name'];
        if (!empty($emp['hire_date']) && $emp['hire_date'] > $period['end_date']) {
            $result['excluded'][] = [$name, 'Hired after this cutoff'];
            continue;
        }
        $sal = payroll_current_salary($db, (int)$emp['id'], $period['end_date']);
        if (!$sal) {
            $result['excluded'][] = [$name, 'No salary setup yet'];
            continue;
        }
        if ($sal['pay_schedule'] !== $period['pay_schedule']) {
            $result['excluded'][] = [$name, 'Paid ' . payroll_schedule_label($sal['pay_schedule']) . ' (this period is ' . payroll_schedule_label($period['pay_schedule']) . ')'];
            continue;
        }
        $rec = payroll_collect_time_records($db, $emp, $period, $S);
        $json = json_encode($rec);
        $issues = implode("\n", $rec['issues']);
        $find->execute([$runId, $emp['id']]);
        $exists = $find->fetch();
        if (!$exists) {
            $insert->execute([$runId, $emp['id'], $sal['id'], $sal['salary_type'], $sal['basic_salary'], $rec['scheduled_days'], $rec['days_present'], $rec['paid_leave_days'], $rec['unpaid_leave_days'], $rec['absent_days'], $rec['late_minutes'], $rec['undertime_minutes'], $rec['ot_hours'], $json, $issues]);
            $result['created']++;
        } elseif (!(int)$exists['validated']) {
            $update->execute([$sal['id'], $sal['salary_type'], $sal['basic_salary'], $rec['scheduled_days'], $rec['days_present'], $rec['paid_leave_days'], $rec['unpaid_leave_days'], $rec['absent_days'], $rec['late_minutes'], $rec['undertime_minutes'], $rec['ot_hours'], $json, $issues, $exists['id']]);
            $result['refreshed']++;
        } else {
            $result['kept']++;
        }
    }
    return $result;
}

// ------------------------------------------------------------------
// Step 05: calculate payroll
// ------------------------------------------------------------------
function payroll_recalc_item_totals(PDO $db, int $itemId): void {
    $g = $db->prepare("SELECT COALESCE(SUM(amount),0) FROM payroll_earnings WHERE item_id=?");
    $g->execute([$itemId]);
    $d = $db->prepare("SELECT COALESCE(SUM(amount),0) FROM payroll_deductions WHERE item_id=?");
    $d->execute([$itemId]);
    $gross = round((float)$g->fetchColumn(), 2);
    $ded = round((float)$d->fetchColumn(), 2);
    $db->prepare("UPDATE payroll_items SET gross_pay=?, total_deductions=?, net_pay=? WHERE id=?")
       ->execute([$gross, $ded, round($gross - $ded, 2), $itemId]);
}

function payroll_update_run_totals(PDO $db, int $runId): void {
    $db->prepare("UPDATE payroll_runs SET
        total_gross=(SELECT COALESCE(SUM(gross_pay),0) FROM payroll_items WHERE run_id=?),
        total_deductions=(SELECT COALESCE(SUM(total_deductions),0) FROM payroll_items WHERE run_id=?),
        total_net=(SELECT COALESCE(SUM(net_pay),0) FROM payroll_items WHERE run_id=?) WHERE id=?")
       ->execute([$runId, $runId, $runId, $runId]);
}

function payroll_calculate_item(PDO $db, int $itemId, array $S): void {
    $q = $db->prepare("SELECT i.*, r.period_id FROM payroll_items i JOIN payroll_runs r ON r.id=i.run_id WHERE i.id=?");
    $q->execute([$itemId]);
    $it = $q->fetch();
    if (!$it) throw new Exception('Payroll item not found.');
    $p = $db->prepare("SELECT * FROM payroll_periods WHERE id=?");
    $p->execute([$it['period_id']]);
    $period = $p->fetch();
    $s = $db->prepare("SELECT * FROM employee_salary WHERE id=?");
    $s->execute([$it['salary_id']]);
    $sal = $s->fetch();
    if (!$sal) throw new Exception('Salary setup for this item no longer exists.');

    $std = max(1.0, (float)$S['standard_hours_per_day']);
    $factor = max(1.0, (float)$S['days_per_month_factor']);
    $ppm = payroll_periods_per_month($period['pay_schedule']);
    $rate = (float)$sal['basic_salary'];
    $paidDays = max(0.0, (float)$it['scheduled_days'] - (float)$it['absent_days'] - (float)$it['unpaid_leave_days']);

    if ($sal['salary_type'] === 'monthly') {
        $monthly = $rate;
        $daily = $rate / $factor;
        $hourly = $daily / $std;
        // Prorate when the employee was hired part-way through the cutoff
        $det = json_decode((string)$it['detected_json'], true) ?: [];
        $periodDays = (float)($det['period_days'] ?? 0);
        $ratio = ($periodDays > 0 && (float)$it['scheduled_days'] < $periodDays) ? ((float)$it['scheduled_days'] / $periodDays) : 1.0;
        $basicPay = round(($rate / $ppm) * $ratio, 2);
        $basicDesc = 'Basic pay (' . payroll_schedule_label($period['pay_schedule']) . ' cutoff' . ($ratio < 1.0 ? ', prorated ' . rtrim(rtrim(number_format((float)$it['scheduled_days'], 2, '.', ''), '0'), '.') . '/' . rtrim(rtrim(number_format($periodDays, 2, '.', ''), '0'), '.') . ' days' : '') . ')';
    } elseif ($sal['salary_type'] === 'daily') {
        $daily = $rate;
        $monthly = $rate * $factor;
        $hourly = $daily / $std;
        $basicPay = round($rate * $paidDays, 2);
        $basicDesc = 'Basic pay (' . rtrim(rtrim(number_format($paidDays, 2, '.', ''), '0'), '.') . ' days x ' . payroll_money($rate) . ')';
    } else {
        $hourly = $rate;
        $daily = $rate * $std;
        $monthly = $daily * $factor;
        $basicPay = round($rate * $std * $paidDays, 2);
        $basicDesc = 'Basic pay (' . rtrim(rtrim(number_format($paidDays * $std, 2, '.', ''), '0'), '.') . ' hrs x ' . payroll_money($rate) . ')';
    }

    // Wipe previous auto lines (manual + adjustment lines are preserved)
    $db->prepare("DELETE FROM payroll_earnings WHERE item_id=? AND source='auto'")->execute([$itemId]);
    $db->prepare("DELETE FROM payroll_deductions WHERE item_id=? AND source='auto'")->execute([$itemId]);

    $addE = $db->prepare("INSERT INTO payroll_earnings(item_id,earning_type,description,amount,source,created_by) VALUES(?,?,?,?, 'auto', ?)");
    $addD = $db->prepare("INSERT INTO payroll_deductions(item_id,deduction_type,description,amount,source,created_by) VALUES(?,?,?,?, 'auto', ?)");
    $uid = $_SESSION['user_id'] ?? null;

    // ---- Earnings
    $addE->execute([$itemId, 'basic', $basicDesc, $basicPay, $uid]);
    $otHours = (float)$it['ot_hours'];
    if ($otHours > 0 && (int)$sal['ot_eligible'] === 1) {
        $mult = max(1.0, (float)$S['ot_multiplier']);
        $otPay = round($otHours * $hourly * $mult, 2);
        $addE->execute([$itemId, 'overtime', 'Overtime (' . rtrim(rtrim(number_format($otHours, 2, '.', ''), '0'), '.') . ' hrs x ' . $mult . ')', $otPay, $uid]);
    }
    $rec = $db->prepare("SELECT * FROM employee_recurring_items WHERE employee_id=? AND is_active=1 AND effective_from<=? AND (effective_to IS NULL OR effective_to>=?) ORDER BY id");
    $rec->execute([$it['employee_id'], $period['end_date'], $period['start_date']]);
    foreach ($rec->fetchAll() as $ri) {
        if ($ri['kind'] === 'earning') $addE->execute([$itemId, 'allowance', $ri['item_name'], round((float)$ri['amount'], 2), $uid]);
        else $addD->execute([$itemId, 'other', $ri['item_name'] . ' (authorized)', round((float)$ri['amount'], 2), $uid]);
    }

    // ---- Attendance-based deductions (only from validated/confirmed values)
    if ($sal['salary_type'] === 'monthly') {
        $unpaidDays = (float)$it['absent_days'] + (float)$it['unpaid_leave_days'];
        if ($unpaidDays > 0) {
            $addD->execute([$itemId, 'absence', 'Unpaid absence/leave (' . rtrim(rtrim(number_format($unpaidDays, 2, '.', ''), '0'), '.') . ' day/s)', round($daily * $unpaidDays, 2), $uid]);
        }
    }
    if ((int)$it['late_minutes'] > 0) {
        $addD->execute([$itemId, 'late', 'Late (' . (int)$it['late_minutes'] . ' min)', round(((int)$it['late_minutes'] / 60) * $hourly, 2), $uid]);
    }
    if ((int)$it['undertime_minutes'] > 0) {
        $addD->execute([$itemId, 'undertime', 'Undertime (' . (int)$it['undertime_minutes'] . ' min)', round(((int)$it['undertime_minutes'] / 60) * $hourly, 2), $uid]);
    }

    // ---- Government contributions + withholding tax (configurable, effective-dated rules)
    $asOf = $period['end_date'];
    $contribMonthly = 0.0;
    foreach (['sss' => 'SSS', 'philhealth' => 'PhilHealth', 'pagibig' => 'Pag-IBIG'] as $type => $label) {
        if (!(int)$sal['applies_' . $type]) continue;
        $m = payroll_contribution_monthly(payroll_rule_for($db, $type, $asOf), $monthly);
        if ($m <= 0) continue;
        $contribMonthly += $m;
        $addD->execute([$itemId, $type, $label . ' contribution', round($m / $ppm, 2), $uid]);
    }
    if ((int)$sal['applies_tax']) {
        $taxableMonthly = max(0.0, $monthly - $contribMonthly);
        $taxM = payroll_tax_monthly(payroll_tax_brackets($db, $asOf), $taxableMonthly);
        if ($taxM > 0) $addD->execute([$itemId, 'tax', 'Withholding tax', round($taxM / $ppm, 2), $uid]);
    }

    $db->prepare("UPDATE payroll_items SET monthly_basic=?, daily_equiv=?, hourly_equiv=?, basic_pay=?, calculated_at=NOW() WHERE id=?")
       ->execute([round($monthly, 2), round($daily, 4), round($hourly, 4), $basicPay, $itemId]);
    payroll_recalc_item_totals($db, $itemId);
}

// What blocks a run from being submitted for review?
function payroll_submit_problems(PDO $db, int $runId): array {
    $problems = [];
    $total = (int)$db->query("SELECT COUNT(*) FROM payroll_items WHERE run_id=" . (int)$runId)->fetchColumn();
    if ($total === 0) return ['No employees in this payroll yet. Run "Collect time records" first.'];
    $unval = (int)$db->query("SELECT COUNT(*) FROM payroll_items WHERE run_id=" . (int)$runId . " AND validated=0")->fetchColumn();
    if ($unval > 0) $problems[] = "$unval employee record(s) still need validation.";
    $uncalc = (int)$db->query("SELECT COUNT(*) FROM payroll_items WHERE run_id=" . (int)$runId . " AND calculated_at IS NULL")->fetchColumn();
    if ($uncalc > 0) $problems[] = "$uncalc employee record(s) have not been calculated (or were edited after calculation). Run \"Calculate payroll\".";
    $neg = (int)$db->query("SELECT COUNT(*) FROM payroll_items WHERE run_id=" . (int)$runId . " AND net_pay<0")->fetchColumn();
    if ($neg > 0) $problems[] = "$neg employee record(s) have a negative net pay. Review the deductions.";
    return $problems;
}

// ------------------------------------------------------------------
// Segregation of duties
// ------------------------------------------------------------------
// The preparer should not approve their own payroll, unless nobody else is able to.
function payroll_can_approve_run(PDO $db, array $run): array {
    $uid = (int)($_SESSION['user_id'] ?? 0);
    if ((int)$run['prepared_by'] !== $uid) return [true, ''];
    if (count(payroll_users_with_permission($db, 'approve_payroll', $uid)) === 0) {
        return [true, 'You prepared this payroll and no other approver exists, so self-approval is allowed and logged.'];
    }
    return [false, 'You prepared this payroll, so another authorized approver must approve it.'];
}

// ------------------------------------------------------------------
// Payments + payslips
// ------------------------------------------------------------------
function payroll_refresh_payment_status(PDO $db, int $itemId): void {
    $paid = $db->prepare("SELECT COALESCE(SUM(amount),0) FROM payroll_payments WHERE item_id=?");
    $paid->execute([$itemId]);
    $amountPaid = round((float)$paid->fetchColumn(), 2);
    $n = $db->prepare("SELECT net_pay, run_id FROM payroll_items WHERE id=?");
    $n->execute([$itemId]);
    $row = $n->fetch();
    $net = (float)$row['net_pay'];
    if ($net <= 0.004 || $amountPaid >= $net - 0.004) $status = 'paid';
    elseif ($amountPaid > 0) $status = 'partial';
    else $status = 'unpaid';
    $db->prepare("UPDATE payroll_items SET amount_paid=?, payment_status=? WHERE id=?")->execute([$amountPaid, $status, $itemId]);
    payroll_refresh_run_status($db, (int)$row['run_id']);
}

function payroll_refresh_run_status(PDO $db, int $runId): void {
    $r = $db->prepare("SELECT status FROM payroll_runs WHERE id=?");
    $r->execute([$runId]);
    $cur = $r->fetchColumn();
    if (!in_array($cur, ['finalized', 'partially_paid', 'paid'], true)) return;
    $s = $db->prepare("SELECT COUNT(*) c, COALESCE(SUM(payment_status='paid'),0) p, COALESCE(SUM(amount_paid>0),0) a FROM payroll_items WHERE run_id=?");
    $s->execute([$runId]);
    $x = $s->fetch();
    if ((int)$x['c'] > 0 && (int)$x['p'] === (int)$x['c']) $new = 'paid';
    elseif ((int)$x['a'] > 0) $new = 'partially_paid';
    else $new = 'finalized';
    if ($new !== $cur) {
        $db->prepare("UPDATE payroll_runs SET status=? WHERE id=?")->execute([$new, $runId]);
        payroll_log_approval($db, $runId, 'payment_status', $cur, $new, 'Automatic, based on recorded payments');
    }
}

// Each call is its own transaction and is safe to repeat: the idempotency key
// makes a double-click or a re-submitted form record the payment only once.
function payroll_record_payment(PDO $db, int $itemId, float $amount, string $method, string $paidDate, ?string $ref, ?string $notes, ?string $idemKey): array {
    $db->beginTransaction();
    try {
        $q = $db->prepare("SELECT i.*, r.status AS run_status FROM payroll_items i JOIN payroll_runs r ON r.id=i.run_id WHERE i.id=? FOR UPDATE");
        $q->execute([$itemId]);
        $it = $q->fetch();
        if (!$it) throw new Exception('Payroll item not found.');
        if (!in_array($it['run_status'], ['finalized', 'partially_paid', 'paid'], true)) throw new Exception('Payroll must be finalized before payments can be recorded.');

        if ($idemKey !== null) {
            $dup = $db->prepare("SELECT id FROM payroll_payments WHERE idem_key=?");
            $dup->execute([$idemKey]);
            if ($dup->fetchColumn()) {
                $db->rollBack();
                return ['ok' => true, 'duplicate' => true, 'message' => 'Payment was already recorded.'];
            }
        }
        $balance = round((float)$it['net_pay'] - (float)$it['amount_paid'], 2);
        if ($amount <= 0 || $amount > $balance + 0.004) throw new Exception('Payment amount must be more than 0 and not more than the remaining balance (' . payroll_money($balance) . ').');

        $db->prepare("INSERT INTO payroll_payments(run_id,item_id,amount,payment_method,reference_no,paid_date,notes,idem_key,recorded_by) VALUES(?,?,?,?,?,?,?,?,?)")
           ->execute([$it['run_id'], $itemId, round($amount, 2), $method, $ref, $paidDate, $notes, $idemKey, $_SESSION['user_id'] ?? null]);
        payroll_refresh_payment_status($db, $itemId);
        $db->commit();
        return ['ok' => true, 'duplicate' => false, 'message' => 'Payment recorded.'];
    } catch (Throwable $e) {
        if ($db->inTransaction()) $db->rollBack();
        return ['ok' => false, 'duplicate' => false, 'message' => $e->getMessage()];
    }
}

function payroll_generate_payslips(PDO $db, int $runId): int {
    $p = $db->prepare("SELECT pr.pay_date FROM payroll_runs r JOIN payroll_periods pr ON pr.id=r.period_id WHERE r.id=?");
    $p->execute([$runId]);
    $payDate = $p->fetchColumn();
    $items = $db->prepare("SELECT id, employee_id FROM payroll_items WHERE run_id=?");
    $items->execute([$runId]);
    $ins = $db->prepare("INSERT IGNORE INTO payslips(item_id,run_id,employee_id,reference_no,generated_by) VALUES(?,?,?,?,?)");
    $n = 0;
    foreach ($items->fetchAll() as $it) {
        $ref = sprintf('PS-%s-%04d-%05d', date('Ym', strtotime($payDate)), $runId, $it['id']);
        $ins->execute([$it['id'], $runId, $it['employee_id'], $ref, $_SESSION['user_id'] ?? null]);
        $n += $ins->rowCount();
    }
    return $n;
}

// ------------------------------------------------------------------
// Email log (SMTP delivery status + retry)
// ------------------------------------------------------------------
function payroll_portal_url(string $path): string {
    if (defined('APP_URL')) {
        $base = rtrim(APP_URL, '/') . '/';
    } else {
        $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $base = $scheme . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . BASE_URL;
    }
    return $base . ltrim($path, '/');
}

function payroll_email_html(string $heading, array $paragraphs, ?string $linkUrl = null, string $linkLabel = 'Open in the portal'): string {
    $html = '<div style="font-family:Arial,sans-serif;max-width:560px"><h2>' . h($heading) . '</h2>';
    foreach ($paragraphs as $p) $html .= '<p>' . h($p) . '</p>';
    if ($linkUrl) $html .= '<p><a href="' . h($linkUrl) . '">' . h($linkLabel) . '</a> (you will be asked to log in)</p>';
    return $html . '<p style="color:#888;font-size:12px">This is an automated message. It never contains passwords or salary figures.</p></div>';
}

function payroll_queue_email(PDO $db, string $to, string $subject, string $html, string $event, ?string $refTable = null, ?int $refId = null): int {
    $db->prepare("INSERT INTO email_logs(recipient,subject,body,event_type,ref_table,ref_id,status) VALUES(?,?,?,?,?,?, 'pending')")
       ->execute([$to, $subject, $html, $event, $refTable, $refId]);
    return (int)$db->lastInsertId();
}

function payroll_dispatch_email(PDO $db, int $logId): bool {
    $q = $db->prepare("SELECT * FROM email_logs WHERE id=?");
    $q->execute([$logId]);
    $row = $q->fetch();
    if (!$row) return false;
    if ($row['status'] === 'sent') return true;
    $res = send_hr_email_raw($row['recipient'], $row['subject'], (string)$row['body']);
    $ok = !empty($res['ok']);
    $db->prepare("UPDATE email_logs SET status=?, error_message=?, attempts=attempts+1, last_attempt_at=NOW() WHERE id=?")
       ->execute([$ok ? 'sent' : 'failed', $ok ? null : substr((string)($res['message'] ?? 'Unknown error'), 0, 255), $logId]);
    if ($row['ref_table'] === 'payslips' && $row['ref_id']) {
        $db->prepare("UPDATE payslips SET email_status=?, emailed_at=CASE WHEN ?=1 THEN NOW() ELSE emailed_at END WHERE id=?")
           ->execute([$ok ? 'sent' : 'failed', $ok ? 1 : 0, $row['ref_id']]);
    }
    return $ok;
}

// Send pending/failed emails. Stops after 3 failures in a row so a down SMTP server
// cannot make a page hang; the rest stay queued and can be retried from the Email Log.
function payroll_dispatch_pending(PDO $db, int $limit = 25): array {
    $ids = $db->query("SELECT id FROM email_logs WHERE status IN ('pending','failed') ORDER BY id ASC LIMIT " . (int)$limit)->fetchAll(PDO::FETCH_COLUMN);
    $sent = 0; $failed = 0; $streak = 0;
    foreach ($ids as $id) {
        if (payroll_dispatch_email($db, (int)$id)) { $sent++; $streak = 0; }
        else { $failed++; $streak++; if ($streak >= 3) break; }
    }
    return ['sent' => $sent, 'failed' => $failed];
}

// Employee email: employee profile first, then the linked user account.
function payroll_employee_contact(PDO $db, int $employeeId): ?array {
    $q = $db->prepare("SELECT e.id, e.first_name, e.last_name, e.user_id, COALESCE(NULLIF(e.email,''), u.email) AS email
                       FROM employees e LEFT JOIN users u ON u.id=e.user_id WHERE e.id=?");
    $q->execute([$employeeId]);
    $row = $q->fetch();
    return $row ?: null;
}

// ------------------------------------------------------------------
// Dashboard widget data (Current / Pending / Last payroll + my latest payslip)
// ------------------------------------------------------------------
function payroll_dashboard_data(PDO $db): array {
    $out = ['staff' => false, 'current' => null, 'actions' => [], 'last_paid' => null, 'unpaid_balance' => 0.0,
            'next_pay' => null, 'adj_pending' => 0, 'mail_issues' => 0, 'mine' => null, 'can_process' => false];
    try {
        $isStaff = hasPermission('view_payroll');
        if ($isStaff) {
            payroll_ensure_schema($db);
            $out['staff'] = true;
            $out['can_process'] = hasPermission('process_payroll');
        } elseif (!$db->query("SHOW TABLES LIKE 'payslips'")->fetchColumn()) {
            return $out;
        }

        if ($isStaff) {
            $cur = $db->query("SELECT r.id, r.status, r.total_net, p.period_name, p.start_date, p.end_date, p.pay_date,
                    (SELECT COUNT(*) FROM payroll_items i WHERE i.run_id=r.id) AS emp_count,
                    (SELECT COUNT(*) FROM payroll_items i WHERE i.run_id=r.id AND i.payment_status='paid') AS paid_count
                FROM payroll_runs r JOIN payroll_periods p ON p.id=r.period_id
                WHERE r.status<>'cancelled' ORDER BY p.start_date DESC, r.id DESC LIMIT 1")->fetch();
            $out['current'] = $cur ?: null;

            $cnt = $db->query("SELECT status, COUNT(*) FROM payroll_runs WHERE status IN ('draft','for_review','for_approval','approved','finalized','partially_paid') GROUP BY status")->fetchAll(PDO::FETCH_KEY_PAIR);
            $map = [
                ['draft', 'process_payroll', 'Draft payroll to prepare', ''],
                ['for_review', 'review_payroll', 'Waiting for review', 'warn'],
                ['for_approval', 'approve_payroll', 'Waiting for approval', 'warn'],
                ['approved', 'approve_payroll', 'Approved - ready to finalize', ''],
                ['finalized', 'record_payroll_payments', 'Finalized - payments to record', ''],
                ['partially_paid', 'record_payroll_payments', 'Partially paid - balance to record', 'warn'],
            ];
            $one = $db->prepare("SELECT id FROM payroll_runs WHERE status=? ORDER BY id DESC LIMIT 1");
            foreach ($map as [$st, $perm, $label, $tone]) {
                if (empty($cnt[$st]) || !hasPermission($perm)) continue;
                $url = BASE_PATH . 'modules/payroll/periods.php';
                if ((int)$cnt[$st] === 1) {
                    $one->execute([$st]);
                    $rid = (int)$one->fetchColumn();
                    if ($rid) $url = BASE_PATH . 'modules/payroll/run.php?id=' . $rid;
                }
                $out['actions'][] = ['label' => $label, 'count' => (int)$cnt[$st], 'tone' => $tone, 'url' => $url];
            }

            $lp = $db->query("SELECT r.id, r.total_net, p.period_name, p.pay_date FROM payroll_runs r JOIN payroll_periods p ON p.id=r.period_id WHERE r.status='paid' ORDER BY p.pay_date DESC, r.id DESC LIMIT 1")->fetch();
            $out['last_paid'] = $lp ?: null;
            $out['unpaid_balance'] = (float)$db->query("SELECT COALESCE(SUM(i.net_pay - i.amount_paid),0) FROM payroll_items i JOIN payroll_runs r ON r.id=i.run_id WHERE r.status IN ('finalized','partially_paid') AND i.net_pay > i.amount_paid")->fetchColumn();
            $np = $db->query("SELECT p.period_name, p.pay_date FROM payroll_periods p WHERE p.pay_date>=CURDATE() AND NOT EXISTS (SELECT 1 FROM payroll_runs r WHERE r.period_id=p.id AND r.status='paid') ORDER BY p.pay_date ASC LIMIT 1")->fetch();
            $out['next_pay'] = $np ?: null;
            if (hasPermission('approve_payroll')) $out['adj_pending'] = (int)$db->query("SELECT COUNT(*) FROM payroll_adjustments WHERE status='pending'")->fetchColumn();
            if ($out['can_process']) $out['mail_issues'] = (int)$db->query("SELECT COUNT(*) FROM email_logs WHERE status='failed'")->fetchColumn();
        }

        $me = payroll_current_employee($db);
        if ($me) {
            $q = $db->prepare("SELECT s.id, p.period_name, p.pay_date, i.net_pay, i.payment_status
                FROM payslips s JOIN payroll_items i ON i.id=s.item_id JOIN payroll_runs r ON r.id=s.run_id JOIN payroll_periods p ON p.id=r.period_id
                WHERE s.employee_id=? AND r.status IN ('finalized','partially_paid','paid') ORDER BY p.pay_date DESC, s.id DESC LIMIT 1");
            $q->execute([$me['id']]);
            $out['mine'] = $q->fetch() ?: null;
        }
    } catch (Throwable $e) {
        error_log('payroll_dashboard_data error: ' . $e->getMessage());
    }
    return $out;
}
