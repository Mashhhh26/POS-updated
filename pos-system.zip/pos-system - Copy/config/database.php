<?php
// ============================================
// DATABASE CONFIGURATION
// ============================================
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'pos_system');

// ============================================
// BASE PATH CONFIGURATION - AUTO DETECT
// ============================================
$base_path = '';
$script_name = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');

// How many folders deep is this script? Any page inside a module sub-folder
// (modules/hrm, modules/payroll, modules/supplier_portal, ...) is two levels below the
// project root, a page directly in modules/ is one level, everything else is the root.
if (preg_match('#/modules/[^/]+/[^/]+$#', $script_name)) {
    $base_path = '../../';
} elseif (strpos($script_name, '/modules/') !== false) {
    $base_path = '../';
} else {
    $base_path = '';
}

define('BASE_PATH', $base_path);
define('BASE_URL', '/pos-system/');

// ============================================
// DATABASE FUNCTIONS
// ============================================
function getDB() {
    try {
        $conn = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4", DB_USER, DB_PASS, [PDO::ATTR_EMULATE_PREPARES=>false]);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
    } catch(PDOException $e) {
        die("Connection failed: " . $e->getMessage());
    }
}

function sanitize($input) {
    return htmlspecialchars(strip_tags(trim($input)));
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function hasPermission($permission) {
    if ((int)($_SESSION['role_id'] ?? 0) === 1 || (($_SESSION['role'] ?? '') === 'Admin')) return true;
    return isset($_SESSION['permissions']) && is_array($_SESSION['permissions']) && in_array($permission, $_SESSION['permissions'], true);
}

function hasRole($role_name) {
    if (!isset($_SESSION['role'])) return false;
    return $_SESSION['role'] === $role_name;
}

function logActivity($action) {
    if (!isset($_SESSION['user_id'])) return;
    
    $db = getDB();
    $user_id = $_SESSION['user_id'];
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    
    try {
        $stmt = $db->prepare("INSERT INTO activity_logs (user_id, action, ip_address) VALUES (?, ?, ?)");
        $stmt->execute([$user_id, $action, $ip]);
    } catch(Exception $e) {
        // Silent fail for logs
    }
}

function redirect($path) {
    header('Location: ' . BASE_PATH . $path);
    exit();
}

// ============================================
// INTERNAL NOTIFICATION CENTER (bell icon)
// Dual channel: this writes the in-app notification; callers that also want
// an email should additionally call send_hr_email() (config/mail.php).
// ============================================
function ensure_notifications_table(PDO $db) {
    static $checked = false;
    if ($checked) return;
    $db->exec("CREATE TABLE IF NOT EXISTS notifications(
        id INT NOT NULL AUTO_INCREMENT,
        user_id INT NOT NULL,
        title VARCHAR(150) NOT NULL,
        message VARCHAR(500) NOT NULL,
        link VARCHAR(255) NULL,
        is_read TINYINT(1) NOT NULL DEFAULT 0,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY(id), KEY user_id(user_id), KEY is_read(is_read)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $checked = true;
}

// Links are saved from whatever page triggered the event, where BASE_PATH is a
// page-relative prefix like "../../". Store them site-absolute so they still
// work when clicked from a different folder.
function notify_normalize_link(?string $link): ?string {
    if ($link === null || $link === '') return null;
    if (preg_match('#^(https?:)?//#i', $link) || $link[0] === '/') return $link;
    return BASE_URL . ltrim(preg_replace('#^(\.\./)+#', '', $link), '/');
}

function notify_user(int $userId, string $title, string $message, ?string $link = null): void {
    if ($userId <= 0) return;
    $link = notify_normalize_link($link);
    try {
        $db = getDB();
        ensure_notifications_table($db);
        $db->prepare("INSERT INTO notifications(user_id,title,message,link) VALUES(?,?,?,?)")
           ->execute([$userId, $title, $message, $link]);
    } catch (Throwable $e) {
        error_log('notify_user error: ' . $e->getMessage());
    }
}

// Notify every active user who holds the given role name.
function notify_role(string $roleName, string $title, string $message, ?string $link = null): void {
    $link = notify_normalize_link($link);
    try {
        $db = getDB();
        ensure_notifications_table($db);
        $users = $db->prepare("SELECT u.id FROM users u JOIN roles r ON r.id=u.role_id WHERE r.role_name=? AND u.is_active=1");
        $users->execute([$roleName]);
        $stmt = $db->prepare("INSERT INTO notifications(user_id,title,message,link) VALUES(?,?,?,?)");
        foreach ($users->fetchAll(PDO::FETCH_COLUMN) as $uid) {
            $stmt->execute([$uid, $title, $message, $link]);
        }
    } catch (Throwable $e) {
        error_log('notify_role error: ' . $e->getMessage());
    }
}

// Call right after a stock-decreasing event (sale, approved stock-out). Only
// fires once per crossing (previous qty above threshold, new qty at/below),
// so routine sales on an already-low item don't spam the bell/inbox.
function check_low_stock_alert(PDO $db, int $productId, int $previousQty): void {
    try {
        $p = $db->prepare("SELECT product_name, product_code, stock_quantity, low_stock_threshold FROM products WHERE id=?");
        $p->execute([$productId]);
        $product = $p->fetch();
        if (!$product) return;
        $threshold = (int)($product['low_stock_threshold'] ?? 5);
        $newQty = (int)$product['stock_quantity'];
        if ($previousQty > $threshold && $newQty <= $threshold) {
            $level = $newQty <= 0 ? 'Out of Stock' : 'Low Stock';
            $msg = $product['product_name'] . ' (' . $product['product_code'] . ') is now at ' . $newQty . ' units (threshold: ' . $threshold . ').';
            notify_role('Inventory', $level . ' Alert', $msg, BASE_PATH . 'modules/inventory/stock_movement.php');
            notify_role('Admin', $level . ' Alert', $msg, BASE_PATH . 'modules/inventory/stock_movement.php');
            if (function_exists('send_hr_email')) {
                $recipients = $db->query("SELECT u.email,u.full_name FROM users u JOIN roles r ON r.id=u.role_id WHERE r.role_name IN ('Inventory','Admin') AND u.is_active=1")->fetchAll();
                foreach ($recipients as $r) {
                    if (filter_var($r['email'] ?? '', FILTER_VALIDATE_EMAIL)) {
                        send_hr_email($r['email'], 'POS System: ' . $level . ' - ' . $product['product_name'], '<h2>' . h($level) . ' Alert</h2><p>' . h($msg) . '</p>');
                    }
                }
            }
        }
    } catch (Throwable $e) {
        error_log('check_low_stock_alert error: ' . $e->getMessage());
    }
}

require_once __DIR__.'/security.php';


// Supplier accounts are isolated: they may only reach the supplier portal, login/logout,
// their own notifications and the set-password page. Everything else (POS, inventory,
// payroll, HR, admin...) redirects them back to the portal.
if (!empty($_SESSION['user_id']) && (($_SESSION['role'] ?? '') === 'Supplier')) {
    $__sp_script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
    $__sp_ok = strpos($__sp_script, '/modules/supplier_portal/') !== false
        || in_array(basename($__sp_script), ['login.php', 'logout.php', 'notifications_api.php', 'set_password.php'], true);
    if (!$__sp_ok) {
        header('Location: ' . BASE_URL . 'modules/supplier_portal/index.php');
        exit();
    }
}
