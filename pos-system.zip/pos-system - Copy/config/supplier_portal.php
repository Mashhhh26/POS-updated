<?php
/**
 * NEXCORE Supplier Portal helpers (schema bootstrap, supplier scoping, events,
 * notifications, invite/reset tokens).
 *
 * Isolation rule: a portal user is tied to ONE supplier through supplier_accounts.
 * The supplier id always comes from that link, never from the request, and
 * config/database.php confines the Supplier role to /modules/supplier_portal/.
 */
if (!defined('BASE_PATH')) {
    require_once __DIR__ . '/database.php';
}
require_once __DIR__ . '/mail.php';

function sp_ensure_schema(PDO $db): void {
    static $done = false;
    if ($done) return;
    $done = true;
    try {
        // Fast path: everything already in place (the common case on normal page loads).
        $fast = $db->query("SHOW TABLES LIKE 'receiving_discrepancies'")->fetchColumn()
            && $db->query("SHOW COLUMNS FROM gr_items LIKE 'missing_quantity'")->fetch()
            && $db->query("SHOW COLUMNS FROM purchase_orders LIKE 'revision_no'")->fetch()
            && strpos((string)($db->query("SHOW COLUMNS FROM purchase_orders LIKE 'status'")->fetch()['Type'] ?? ''), "'rejected'") !== false
            && (int)$db->query("SELECT COUNT(*) FROM permissions WHERE permission_name='access_supplier_portal'")->fetchColumn() > 0;
        if ($fast) return;
        $db->exec("CREATE TABLE IF NOT EXISTS supplier_accounts (
            id INT NOT NULL AUTO_INCREMENT,
            user_id INT NOT NULL,
            supplier_id INT NOT NULL,
            created_by INT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uniq_user (user_id),
            KEY supplier_id (supplier_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $db->exec("CREATE TABLE IF NOT EXISTS supplier_po_events (
            id INT NOT NULL AUTO_INCREMENT,
            po_id INT NOT NULL,
            supplier_id INT NULL,
            actor_user_id INT NULL,
            actor_type ENUM('supplier','procurement','system') NOT NULL DEFAULT 'system',
            event_type VARCHAR(40) NOT NULL,
            note VARCHAR(500) NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY po_id (po_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $db->exec("CREATE TABLE IF NOT EXISTS password_tokens (
            id INT NOT NULL AUTO_INCREMENT,
            user_id INT NOT NULL,
            token_hash CHAR(64) NOT NULL,
            purpose ENUM('activate','reset') NOT NULL DEFAULT 'activate',
            expires_at DATETIME NOT NULL,
            used_at DATETIME NULL,
            created_by INT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uniq_hash (token_hash),
            KEY user_id (user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Columns the portal needs on purchase_orders (also repairs DBs that never ran the V4.6 migration)
        $have = $db->query("SHOW COLUMNS FROM purchase_orders")->fetchAll(PDO::FETCH_COLUMN);
        $add = [
            'acknowledged_at'        => 'TIMESTAMP NULL DEFAULT NULL',
            'acknowledgement_note'   => 'VARCHAR(255) NULL DEFAULT NULL',
            'supplier_response'      => "ENUM('pending','confirmed','rejected') NOT NULL DEFAULT 'pending'",
            'supplier_remarks'       => 'VARCHAR(500) NULL DEFAULT NULL',
            'supplier_responded_at'  => 'DATETIME NULL DEFAULT NULL',
            'expected_delivery_date' => 'DATE NULL DEFAULT NULL',
            'delivery_status'        => "ENUM('not_started','preparing','shipped','delivered') NOT NULL DEFAULT 'not_started'",
            'delivery_note'          => 'VARCHAR(255) NULL DEFAULT NULL',
            'delivery_updated_at'    => 'DATETIME NULL DEFAULT NULL',
        ];
        foreach ($add as $col => $ddl) {
            if (!in_array($col, $have, true)) $db->exec("ALTER TABLE purchase_orders ADD COLUMN $col $ddl");
        }
        $st = $db->query("SHOW COLUMNS FROM purchase_orders LIKE 'status'")->fetch();
        $type = (string)($st['Type'] ?? '');
        if (strpos($type, "'rejected'") === false || strpos($type, "'partially_received'") === false) {
            $db->exec("ALTER TABLE purchase_orders MODIFY status ENUM('draft','pending_approval','approved','sent','acknowledged','partially_received','fulfilled','closed','cancelled','rejected') DEFAULT 'draft'");
        }

        // ---- V5.2: RFQ/quotation, change requests, revisions, shipments, documents, discrepancies
        sp_add_columns($db, 'purchase_orders', ['revision_no' => 'INT NOT NULL DEFAULT 0']);
        sp_add_columns($db, 'quotations', [
            'warranty' => 'VARCHAR(150) NULL', 'submitted_via' => "ENUM('internal','portal') NOT NULL DEFAULT 'internal'",
            'revision_no' => 'INT NOT NULL DEFAULT 0', 'updated_at' => 'DATETIME NULL DEFAULT NULL', 'submitted_by' => 'INT NULL']);
        sp_add_columns($db, 'quotation_items', ['available_quantity' => 'INT NULL', 'rfq_item_id' => 'INT NULL']);
        sp_add_columns($db, 'rfqs', [
            'selected_quotation_id' => 'INT NULL', 'selected_supplier_id' => 'INT NULL', 'selection_reason' => 'VARCHAR(500) NULL',
            'selected_by' => 'INT NULL', 'selected_at' => 'DATETIME NULL DEFAULT NULL']);
        sp_add_columns($db, 'gr_items', ['damaged_quantity' => 'INT NOT NULL DEFAULT 0', 'missing_quantity' => 'INT NOT NULL DEFAULT 0']);
        $db->exec("CREATE TABLE IF NOT EXISTS po_change_requests (
            id INT NOT NULL AUTO_INCREMENT, po_id INT NOT NULL, supplier_id INT NOT NULL, requested_by INT NULL,
            new_delivery_date DATE NULL, new_payment_terms VARCHAR(50) NULL, items_json TEXT NULL,
            reason VARCHAR(500) NOT NULL, status ENUM('pending','approved','rejected','withdrawn') NOT NULL DEFAULT 'pending',
            decided_by INT NULL, decided_at DATETIME NULL, decision_note VARCHAR(500) NULL, revision_no INT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id), KEY po_id (po_id), KEY status (status)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $db->exec("CREATE TABLE IF NOT EXISTS po_revisions (
            id INT NOT NULL AUTO_INCREMENT, po_id INT NOT NULL, revision_no INT NOT NULL, change_request_id INT NULL,
            before_json MEDIUMTEXT NULL, after_json MEDIUMTEXT NULL, summary VARCHAR(600) NULL, approved_by INT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id), KEY po_id (po_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $db->exec("CREATE TABLE IF NOT EXISTS po_shipments (
            id INT NOT NULL AUTO_INCREMENT, po_id INT NOT NULL, supplier_id INT NOT NULL, carrier VARCHAR(100) NOT NULL,
            tracking_no VARCHAR(100) NULL, ship_date DATE NOT NULL, expected_arrival DATE NULL, remarks VARCHAR(255) NULL,
            created_by INT NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id), KEY po_id (po_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $db->exec("CREATE TABLE IF NOT EXISTS supplier_documents (
            id INT NOT NULL AUTO_INCREMENT, supplier_id INT NOT NULL, po_id INT NULL, rfq_id INT NULL, discrepancy_id INT NULL,
            doc_type VARCHAR(30) NOT NULL DEFAULT 'other', original_name VARCHAR(190) NOT NULL, stored_name VARCHAR(80) NOT NULL,
            mime VARCHAR(100) NULL, size_bytes INT NOT NULL DEFAULT 0, uploaded_by INT NULL,
            uploaded_by_type ENUM('supplier','internal') NOT NULL DEFAULT 'supplier', note VARCHAR(255) NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id), UNIQUE KEY uniq_stored (stored_name), KEY supplier_id (supplier_id), KEY po_id (po_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $db->exec("CREATE TABLE IF NOT EXISTS receiving_discrepancies (
            id INT NOT NULL AUTO_INCREMENT, po_id INT NOT NULL, po_item_id INT NULL, grn_id INT NULL, supplier_id INT NOT NULL,
            disc_type ENUM('rejected','damaged','missing') NOT NULL, quantity INT NOT NULL, description VARCHAR(500) NOT NULL,
            status ENUM('open','supplier_notified','awaiting_replacement','resolved') NOT NULL DEFAULT 'open',
            resolution ENUM('replacement','credit_note','refund','return_to_supplier','short_close') NULL,
            resolution_amount DECIMAL(12,2) NULL, resolution_note VARCHAR(500) NULL,
            supplier_response VARCHAR(500) NULL, supplier_responded_at DATETIME NULL,
            created_by INT NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, notified_at DATETIME NULL,
            resolved_by INT NULL, resolved_at DATETIME NULL,
            PRIMARY KEY (id), KEY po_id (po_id), KEY status (status), KEY supplier_id (supplier_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Supplier role + permissions (seeded once)
        $has = (int)$db->query("SELECT COUNT(*) FROM permissions WHERE permission_name='access_supplier_portal'")->fetchColumn();
        if ($has === 0) {
            $db->exec("INSERT INTO roles(role_name,description) SELECT 'Supplier','External supplier - portal access only' FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM roles WHERE role_name='Supplier')");
            $ins = $db->prepare("INSERT IGNORE INTO permissions(permission_name,module,description) VALUES(?,?,?)");
            $ins->execute(['access_supplier_portal', 'supplier_portal', 'Use the supplier portal (suppliers only)']);
            $ins->execute(['manage_supplier_accounts', 'procurement', 'Create and manage supplier portal accounts']);
            $g = $db->prepare("INSERT INTO role_permissions(role_id,permission_id) SELECT r.id,p.id FROM roles r JOIN permissions p ON p.permission_name=? WHERE r.role_name=? AND NOT EXISTS (SELECT 1 FROM role_permissions x WHERE x.role_id=r.id AND x.permission_id=p.id)");
            $g->execute(['access_supplier_portal', 'Supplier']);
            $g->execute(['manage_supplier_accounts', 'Procurement']);
            $g->execute(['manage_supplier_accounts', 'Admin']);
        }
    } catch (Throwable $e) {
        error_log('sp_ensure_schema error: ' . $e->getMessage());
    }
}

// ------------------------------------------------------------------ supplier scoping
function sp_current_supplier(PDO $db): ?array {
    if (empty($_SESSION['user_id'])) return null;
    $q = $db->prepare("SELECT s.* FROM supplier_accounts a JOIN suppliers s ON s.id=a.supplier_id WHERE a.user_id=? AND s.is_active=1");
    $q->execute([$_SESSION['user_id']]);
    $row = $q->fetch();
    return $row ?: null;
}

function sp_fail(string $msg): void {
    http_response_code(403);
    echo '<!DOCTYPE html><html><head><meta charset="utf-8"><title>Supplier Portal</title><link rel="stylesheet" href="' . h(BASE_PATH) . 'assets/vendor/bootstrap/bootstrap.min.css"><link rel="stylesheet" href="' . h(BASE_PATH) . 'assets/css/custom.css"></head><body><main class="container py-5" style="max-width:560px"><div class="card"><div class="card-body text-center p-4"><h5>Supplier Portal</h5><p class="text-muted">' . h($msg) . '</p><a class="btn btn-primary" href="' . h(BASE_PATH) . 'logout.php">Log out</a></div></div></main></body></html>';
    exit();
}

// Every portal page starts here: must be logged in, allowed, and linked to an active supplier.
function sp_require_supplier(PDO $db): array {
    if (empty($_SESSION['user_id'])) {
        header('Location: ' . BASE_PATH . 'login.php');
        exit();
    }
    sp_ensure_schema($db);
    if (!hasPermission('access_supplier_portal')) {
        header('Location: ' . BASE_PATH . 'index.php?error=access_denied');
        exit();
    }
    $sup = sp_current_supplier($db);
    if (!$sup) sp_fail('Your login is not linked to an active supplier record. Please contact the procurement team.');
    return $sup;
}

// POs a supplier may see: only ones actually issued to them.
function sp_visible_sql(): string {
    return "po.supplier_id=? AND (po.status IN ('sent','acknowledged','partially_received','fulfilled','closed','rejected') OR (po.status='cancelled' AND po.sent_at IS NOT NULL))";
}

function sp_load_po(PDO $db, int $poId, int $supplierId): ?array {
    $q = $db->prepare("SELECT po.* FROM purchase_orders po WHERE po.id=? AND " . sp_visible_sql());
    $q->execute([$poId, $supplierId]);
    $row = $q->fetch();
    return $row ?: null;
}

// ------------------------------------------------------------------ labels
function sp_stage(array $po): array {
    $dl = $po['delivery_status'] ?? 'not_started';
    switch ($po['status']) {
        case 'sent':               return ['New - awaiting your response', 'warning'];
        case 'acknowledged':
            if ($dl === 'delivered') return ['Delivered - awaiting receiving', 'primary'];
            if ($dl === 'shipped')   return ['Shipped - for delivery', 'primary'];
            if ($dl === 'preparing') return ['Preparing order', 'info'];
            return ['Confirmed', 'info'];
        case 'partially_received': return ['Partially received', 'primary'];
        case 'fulfilled':          return ['Received', 'success'];
        case 'closed':             return ['Completed', 'success'];
        case 'rejected':           return ['Rejected', 'danger'];
        case 'cancelled':          return ['Cancelled', 'secondary'];
    }
    return [ucfirst(str_replace('_', ' ', (string)$po['status'])), 'secondary'];
}

function sp_stage_badge(array $po): string {
    $s = sp_stage($po);
    $tx = in_array($s[1], ['warning', 'info'], true) ? ' text-dark' : '';
    return '<span class="badge bg-' . $s[1] . $tx . '">' . h($s[0]) . '</span>';
}

function sp_delivery_label(string $d): string {
    $map = ['not_started' => 'Not started', 'preparing' => 'Preparing', 'shipped' => 'Shipped', 'delivered' => 'Delivered'];
    return $map[$d] ?? $d;
}

// One-line summary for the internal (procurement) screens.
function sp_internal_info(array $po): string {
    if (!array_key_exists('supplier_response', $po)) return '';
    $parts = [];
    if ($po['supplier_response'] === 'confirmed') $parts[] = 'Supplier confirmed';
    elseif ($po['supplier_response'] === 'rejected') $parts[] = 'Supplier rejected';
    elseif ($po['status'] === 'sent') $parts[] = 'Awaiting supplier';
    if (!empty($po['expected_delivery_date'])) $parts[] = 'ETA ' . date('M d', strtotime($po['expected_delivery_date']));
    if (!empty($po['delivery_status']) && $po['delivery_status'] !== 'not_started') $parts[] = sp_delivery_label($po['delivery_status']);
    return implode(' · ', $parts);
}

// ------------------------------------------------------------------ events + notifications
function sp_log_event(PDO $db, int $poId, ?int $supplierId, string $actorType, string $type, ?string $note = null): void {
    $db->prepare("INSERT INTO supplier_po_events(po_id,supplier_id,actor_user_id,actor_type,event_type,note) VALUES(?,?,?,?,?,?)")
       ->execute([$poId, $supplierId, $_SESSION['user_id'] ?? null, $actorType, $type, $note !== null ? substr($note, 0, 500) : null]);
}

function sp_users_with_permission(PDO $db, string $perm): array {
    $q = $db->prepare("SELECT u.id, u.full_name, u.email FROM users u
        WHERE u.is_active=1 AND (u.role_id=1 OR EXISTS (SELECT 1 FROM role_permissions rp JOIN permissions p ON p.id=rp.permission_id WHERE rp.role_id=u.role_id AND p.permission_name=?))");
    $q->execute([$perm]);
    return $q->fetchAll();
}

function sp_supplier_users(PDO $db, int $supplierId): array {
    $q = $db->prepare("SELECT u.id, u.full_name, u.email FROM supplier_accounts a JOIN users u ON u.id=a.user_id WHERE a.supplier_id=? AND u.is_active=1");
    $q->execute([$supplierId]);
    return $q->fetchAll();
}

function sp_portal_url(string $path): string {
    if (defined('APP_URL')) return rtrim(APP_URL, '/') . '/' . ltrim($path, '/');
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    return $scheme . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . BASE_URL . ltrim($path, '/');
}

function sp_email_html(string $heading, array $paragraphs, ?string $url = null, string $label = 'Open the portal'): string {
    $html = '<div style="font-family:Arial,sans-serif;max-width:560px"><h2>' . h($heading) . '</h2>';
    foreach ($paragraphs as $p) $html .= '<p>' . h($p) . '</p>';
    if ($url) $html .= '<p><a href="' . h($url) . '">' . h($label) . '</a> (you will be asked to log in)</p>';
    return $html . '<p style="color:#888;font-size:12px">Automated message. It never contains passwords.</p></div>';
}

// Bell for every portal user of the supplier; email to the supplier contact + portal users when $subject is given.
function sp_notify_supplier(PDO $db, int $supplierId, string $title, string $msg, string $path, ?string $subject = null, array $paras = []): void {
    try {
        $emails = [];
        $s = $db->prepare("SELECT email FROM suppliers WHERE id=?");
        $s->execute([$supplierId]);
        $se = $s->fetchColumn();
        if ($se) $emails[strtolower($se)] = $se;
        foreach (sp_supplier_users($db, $supplierId) as $u) {
            notify_user((int)$u['id'], $title, $msg, BASE_PATH . $path);
            if (!empty($u['email'])) $emails[strtolower($u['email'])] = $u['email'];
        }
        if ($subject) {
            foreach ($emails as $e) {
                if (filter_var($e, FILTER_VALIDATE_EMAIL)) send_hr_email($e, $subject, sp_email_html($title, $paras ?: [$msg], sp_portal_url($path), 'Open the supplier portal'));
            }
        }
    } catch (Throwable $e) {
        error_log('sp_notify_supplier error: ' . $e->getMessage());
    }
}

// Bell (and optional email) for procurement staff who manage POs.
function sp_notify_staff(PDO $db, string $title, string $msg, string $path, ?string $subject = null): void {
    try {
        foreach (sp_users_with_permission($db, 'manage_pos') as $u) {
            notify_user((int)$u['id'], $title, $msg, BASE_PATH . $path);
            if ($subject && filter_var($u['email'] ?? '', FILTER_VALIDATE_EMAIL)) {
                send_hr_email($u['email'], $subject, sp_email_html($title, [$msg], sp_portal_url($path), 'Open the purchase order'));
            }
        }
    } catch (Throwable $e) {
        error_log('sp_notify_staff error: ' . $e->getMessage());
    }
}

// ------------------------------------------------------------------ invite / reset tokens
function sp_create_token(PDO $db, int $userId, string $purpose, ?int $createdBy, int $hours = 72): string {
    $db->prepare("UPDATE password_tokens SET used_at=NOW() WHERE user_id=? AND used_at IS NULL")->execute([$userId]);
    $raw = bin2hex(random_bytes(32));
    $db->prepare("INSERT INTO password_tokens(user_id,token_hash,purpose,expires_at,created_by) VALUES(?,?,?,DATE_ADD(NOW(), INTERVAL " . (int)$hours . " HOUR),?)")
       ->execute([$userId, hash('sha256', $raw), $purpose, $createdBy]);
    return $raw;
}

function sp_find_token(PDO $db, string $raw): ?array {
    if (!preg_match('/^[a-f0-9]{64}$/', $raw)) return null;
    $q = $db->prepare("SELECT t.*, u.username, u.full_name, u.email FROM password_tokens t JOIN users u ON u.id=t.user_id WHERE t.token_hash=? AND t.used_at IS NULL AND t.expires_at>NOW() AND u.is_active=1");
    $q->execute([hash('sha256', $raw)]);
    $row = $q->fetch();
    return $row ?: null;
}

function sp_valid_password(string $p): ?string {
    if (strlen($p) < 10) return 'Password must be at least 10 characters.';
    if (!preg_match('/[A-Za-z]/', $p) || !preg_match('/\d/', $p)) return 'Password must contain both letters and numbers.';
    return null;
}

function sp_is_date($s): bool {
    if (!is_string($s) || !preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $s, $m)) return false;
    return checkdate((int)$m[2], (int)$m[3], (int)$m[1]);
}
function sp_fmt_date(?string $d): string {
    return ($d && $d !== '0000-00-00') ? date('M d, Y', strtotime($d)) : '—';
}
function sp_money($v): string {
    return '₱' . number_format((float)$v, 2);
}

// ==================================================================
// V5.2 helpers: schema, uploads, RFQ items, PO snapshots/revisions
// ==================================================================
function sp_add_columns(PDO $db, string $table, array $cols): void {
    $have = $db->query("SHOW COLUMNS FROM `$table`")->fetchAll(PDO::FETCH_COLUMN);
    foreach ($cols as $col => $ddl) {
        if (!in_array($col, $have, true)) $db->exec("ALTER TABLE `$table` ADD COLUMN `$col` $ddl");
    }
}

function sp_fmt_size(int $b): string {
    if ($b >= 1048576) return number_format($b / 1048576, 1) . ' MB';
    return max(1, (int)round($b / 1024)) . ' KB';
}

function sp_doc_types(): array {
    return ['delivery_receipt' => 'Delivery receipt', 'packing_list' => 'Packing list', 'invoice' => 'Invoice copy', 'certificate' => 'Certificate / warranty',
            'quotation_attachment' => 'Quotation attachment', 'discrepancy_evidence' => 'Discrepancy evidence', 'other' => 'Other'];
}

// Documents live in uploads/supplier_docs (web access denied) and are served only by
// modules/supplier_portal/download.php after an ownership/permission check.
function sp_upload_dir(): string {
    $dir = dirname(__DIR__) . '/uploads/supplier_docs';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    $ht = $dir . '/.htaccess';
    if (!is_file($ht)) {
        @file_put_contents($ht, "<IfModule mod_authz_core.c>\n    Require all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n    Order allow,deny\n    Deny from all\n</IfModule>\n");
    }
    return $dir;
}

function sp_allowed_upload_types(): array {
    return [
        'pdf'  => ['application/pdf'],
        'jpg'  => ['image/jpeg'], 'jpeg' => ['image/jpeg'], 'png' => ['image/png'],
        'doc'  => ['application/msword', 'application/octet-stream', 'application/vnd.ms-office'],
        'docx' => ['application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/zip', 'application/octet-stream'],
        'xls'  => ['application/vnd.ms-excel', 'application/octet-stream', 'application/vnd.ms-office'],
        'xlsx' => ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/zip', 'application/octet-stream'],
    ];
}

// Validates and stores one uploaded file; returns the new supplier_documents id. Throws on any problem.
function sp_store_upload(PDO $db, array $file, array $meta): int {
    if (empty($file) || !isset($file['error']) || $file['error'] === UPLOAD_ERR_NO_FILE) throw new Exception('Choose a file to upload.');
    if ($file['error'] !== UPLOAD_ERR_OK) throw new Exception('The upload failed (error code ' . (int)$file['error'] . '). The file may be too large.');
    if (!is_uploaded_file($file['tmp_name'])) throw new Exception('Invalid upload.');
    $size = (int)$file['size'];
    if ($size <= 0 || $size > 5 * 1024 * 1024) throw new Exception('Files must be between 1 byte and 5 MB.');
    $orig = preg_replace('/[\x00-\x1F\x7F\\\\\/:*?"<>|]+/', '_', basename((string)$file['name']));
    $orig = substr($orig, 0, 190);
    $ext = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
    $allowed = sp_allowed_upload_types();
    if (!isset($allowed[$ext])) throw new Exception('Allowed file types: PDF, JPG, PNG, DOC(X), XLS(X).');
    $mime = '';
    if (function_exists('finfo_open')) {
        $fi = finfo_open(FILEINFO_MIME_TYPE);
        $mime = (string)finfo_file($fi, $file['tmp_name']);
        finfo_close($fi);
    }
    if ($mime !== '' && !in_array($mime, $allowed[$ext], true)) throw new Exception('The file content does not match its extension (' . $mime . ').');
    if (in_array($ext, ['jpg', 'jpeg', 'png'], true) && @getimagesize($file['tmp_name']) === false) throw new Exception('That image file is not valid.');
    $type = $meta['doc_type'] ?? 'other';
    if (!isset(sp_doc_types()[$type])) $type = 'other';
    $stored = bin2hex(random_bytes(16)) . '.' . $ext;
    $dest = sp_upload_dir() . '/' . $stored;
    if (!move_uploaded_file($file['tmp_name'], $dest)) throw new Exception('Could not save the file on the server.');
    @chmod($dest, 0644);
    $db->prepare("INSERT INTO supplier_documents(supplier_id,po_id,rfq_id,discrepancy_id,doc_type,original_name,stored_name,mime,size_bytes,uploaded_by,uploaded_by_type,note) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)")
       ->execute([(int)$meta['supplier_id'], $meta['po_id'] ?? null, $meta['rfq_id'] ?? null, $meta['discrepancy_id'] ?? null, $type, $orig, $stored,
                  $mime !== '' ? $mime : null, $size, $_SESSION['user_id'] ?? null, $meta['by'] ?? 'supplier', isset($meta['note']) ? substr((string)$meta['note'], 0, 255) : null]);
    return (int)$db->lastInsertId();
}

function sp_doc_can_access(PDO $db, array $doc): bool {
    $sup = sp_current_supplier($db);
    if ($sup) return (int)$doc['supplier_id'] === (int)$sup['id'];      // a supplier: only their own company's files
    return hasPermission('view_pos') || hasPermission('view_rfqs') || hasPermission('receive_goods');
}

function sp_rfq_items(PDO $db, ?int $requisitionId): array {
    if (!$requisitionId) return [];
    $q = $db->prepare("SELECT id, item_description, quantity, unit, specifications FROM requisition_items WHERE requisition_id=? ORDER BY id");
    $q->execute([$requisitionId]);
    return $q->fetchAll();
}

function sp_rfq_open(array $rfq): bool {
    if (($rfq['status'] ?? '') !== 'sent') return false;
    return empty($rfq['submission_deadline']) || strtotime($rfq['submission_deadline']) >= time();
}

// ---- PO snapshots, totals and revision history
function sp_snapshot_po(PDO $db, int $poId): array {
    $p = $db->prepare("SELECT id, po_number, status, total_amount, tax, shipping_cost, grand_total, payment_terms, delivery_date, expected_delivery_date, revision_no FROM purchase_orders WHERE id=?");
    $p->execute([$poId]);
    $i = $db->prepare("SELECT id, item_description, quantity, unit_price, total, received_quantity FROM po_items WHERE po_id=? ORDER BY id");
    $i->execute([$poId]);
    return ['po' => $p->fetch() ?: [], 'items' => $i->fetchAll()];
}

function sp_recalc_po_totals(PDO $db, int $poId): void {
    $db->prepare("UPDATE po_items SET total=ROUND(quantity*unit_price,2) WHERE po_id=?")->execute([$poId]);
    $s = $db->prepare("SELECT COALESCE(SUM(total),0) FROM po_items WHERE po_id=?");
    $s->execute([$poId]);
    $sub = round((float)$s->fetchColumn(), 2);
    $t = $db->prepare("SELECT COALESCE(tax,0) AS tax, COALESCE(shipping_cost,0) AS ship FROM purchase_orders WHERE id=?");
    $t->execute([$poId]);
    $row = $t->fetch();
    $db->prepare("UPDATE purchase_orders SET total_amount=?, grand_total=? WHERE id=?")->execute([$sub, round($sub + (float)$row['tax'] + (float)$row['ship'], 2), $poId]);
}

function sp_record_revision(PDO $db, int $poId, array $before, string $summary, ?int $changeRequestId): int {
    $rev = (int)($before['po']['revision_no'] ?? 0) + 1;
    $db->prepare("UPDATE purchase_orders SET revision_no=? WHERE id=?")->execute([$rev, $poId]);
    $after = sp_snapshot_po($db, $poId);
    $db->prepare("INSERT INTO po_revisions(po_id,revision_no,change_request_id,before_json,after_json,summary,approved_by) VALUES(?,?,?,?,?,?,?)")
       ->execute([$poId, $rev, $changeRequestId, json_encode($before), json_encode($after), substr($summary, 0, 600), $_SESSION['user_id'] ?? null]);
    return $rev;
}

// After quantities change (short-close / revision), move the PO to the right receiving status.
function sp_reeval_po_status(PDO $db, int $poId): ?string {
    $st = $db->prepare("SELECT status FROM purchase_orders WHERE id=?");
    $st->execute([$poId]);
    $cur = $st->fetchColumn();
    if (!in_array($cur, ['acknowledged', 'partially_received'], true)) return null;
    $c = $db->prepare("SELECT COUNT(*) FROM po_items WHERE po_id=? AND received_quantity<quantity");
    $c->execute([$poId]);
    $r = $db->prepare("SELECT COALESCE(SUM(received_quantity),0) FROM po_items WHERE po_id=?");
    $r->execute([$poId]);
    if ((int)$c->fetchColumn() === 0 && (int)$r->fetchColumn() > 0) {
        $db->prepare("UPDATE purchase_orders SET status='fulfilled', delivery_status='delivered' WHERE id=?")->execute([$poId]);
        return 'fulfilled';
    }
    return null;
}

function sp_disc_type_label(string $t): string {
    $m = ['rejected' => 'Rejected (failed inspection)', 'damaged' => 'Damaged on arrival', 'missing' => 'Missing / short'];
    return $m[$t] ?? $t;
}
function sp_disc_status_badge(string $s): string {
    $m = ['open' => ['Open', 'danger'], 'supplier_notified' => ['Supplier notified', 'warning'], 'awaiting_replacement' => ['Awaiting replacement', 'info'], 'resolved' => ['Resolved', 'success']];
    $x = $m[$s] ?? [$s, 'secondary'];
    return '<span class="badge bg-' . $x[1] . '">' . h($x[0]) . '</span>';
}
